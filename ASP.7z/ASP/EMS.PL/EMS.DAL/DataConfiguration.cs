﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EMS.DAL
{
    public class DataConfiguration
    {
        public static SqlCommand CreateCommand()
        {
            SqlConnection con = null;
            SqlCommand cmd = null;

            try 
            {
                con = new SqlConnection();
                con.ConnectionString = ConfigurationManager.ConnectionStrings["TrainingCon"].ConnectionString;

                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cmd;
        }
    }
}
