﻿namespace EmpMngSys
{
    partial class EmployeeActivityForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabPgTimeSheet = new System.Windows.Forms.TabPage();
            this.lblShiftId = new System.Windows.Forms.Label();
            this.lblShiftName = new System.Windows.Forms.Label();
            this.lblTymIn = new System.Windows.Forms.Label();
            this.lblTymOut = new System.Windows.Forms.Label();
            this.txtShiftId = new System.Windows.Forms.TextBox();
            this.txtShiftName = new System.Windows.Forms.TextBox();
            this.txtTymIn = new System.Windows.Forms.TextBox();
            this.txtTymOut = new System.Windows.Forms.TextBox();
            this.lblWkHrs = new System.Windows.Forms.Label();
            this.txtWkHrs = new System.Windows.Forms.TextBox();
            this.btnSubmitTymSheet = new System.Windows.Forms.Button();
            this.btnUpdateTymSheet = new System.Windows.Forms.Button();
            this.tabPgProject = new System.Windows.Forms.TabPage();
            this.lblProjId = new System.Windows.Forms.Label();
            this.txtProjId = new System.Windows.Forms.TextBox();
            this.lblEmpld = new System.Windows.Forms.Label();
            this.txtEmployId = new System.Windows.Forms.TextBox();
            this.dgvProject = new System.Windows.Forms.DataGridView();
            this.btnViewProj = new System.Windows.Forms.Button();
            this.tabPgViewProfile = new System.Windows.Forms.TabPage();
            this.llbhome2 = new System.Windows.Forms.LinkLabel();
            this.lblFrstName = new System.Windows.Forms.Label();
            this.lblLstName = new System.Windows.Forms.Label();
            this.lblDOB = new System.Windows.Forms.Label();
            this.lblDOJ = new System.Windows.Forms.Label();
            this.lblgender = new System.Windows.Forms.Label();
            this.lblAddrs = new System.Windows.Forms.Label();
            this.lblMStatus = new System.Windows.Forms.Label();
            this.lblSal = new System.Windows.Forms.Label();
            this.lblPhnNo = new System.Windows.Forms.Label();
            this.lblDesg = new System.Windows.Forms.Label();
            this.lblDpt = new System.Windows.Forms.Label();
            this.lblMgrId = new System.Windows.Forms.Label();
            this.lblGrdCode = new System.Windows.Forms.Label();
            this.txtLstnme = new System.Windows.Forms.TextBox();
            this.txtaddrss = new System.Windows.Forms.TextBox();
            this.txtsal = new System.Windows.Forms.TextBox();
            this.txtphnnumbr = new System.Windows.Forms.TextBox();
            this.txtmgr = new System.Windows.Forms.TextBox();
            this.txtFrstnme = new System.Windows.Forms.TextBox();
            this.dtpDOB = new System.Windows.Forms.DateTimePicker();
            this.dtpDOJ = new System.Windows.Forms.DateTimePicker();
            this.cmbgender = new System.Windows.Forms.ComboBox();
            this.cmbMStuts = new System.Windows.Forms.ComboBox();
            this.cmbdesg = new System.Windows.Forms.ComboBox();
            this.cmbdept = new System.Windows.Forms.ComboBox();
            this.cmbgrade = new System.Windows.Forms.ComboBox();
            this.btnView = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.lblEmplyID = new System.Windows.Forms.Label();
            this.txtemplyid = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPgSearchEmp = new System.Windows.Forms.TabPage();
            this.txtEID = new System.Windows.Forms.TextBox();
            this.lbEId = new System.Windows.Forms.Label();
            this.txtEmpName = new System.Windows.Forms.TextBox();
            this.lblEmpname = new System.Windows.Forms.Label();
            this.cmbDep = new System.Windows.Forms.ComboBox();
            this.cmbDesig = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lblDesig = new System.Windows.Forms.Label();
            this.btnViewEmp = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPgTimeSheet.SuspendLayout();
            this.tabPgProject.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProject)).BeginInit();
            this.tabPgViewProfile.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPgSearchEmp.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPgTimeSheet
            // 
            this.tabPgTimeSheet.Controls.Add(this.btnUpdateTymSheet);
            this.tabPgTimeSheet.Controls.Add(this.btnSubmitTymSheet);
            this.tabPgTimeSheet.Controls.Add(this.txtWkHrs);
            this.tabPgTimeSheet.Controls.Add(this.txtTymOut);
            this.tabPgTimeSheet.Controls.Add(this.txtTymIn);
            this.tabPgTimeSheet.Controls.Add(this.txtShiftName);
            this.tabPgTimeSheet.Controls.Add(this.txtShiftId);
            this.tabPgTimeSheet.Controls.Add(this.lblWkHrs);
            this.tabPgTimeSheet.Controls.Add(this.lblTymOut);
            this.tabPgTimeSheet.Controls.Add(this.lblTymIn);
            this.tabPgTimeSheet.Controls.Add(this.lblShiftName);
            this.tabPgTimeSheet.Controls.Add(this.lblShiftId);
            this.tabPgTimeSheet.Location = new System.Drawing.Point(4, 24);
            this.tabPgTimeSheet.Name = "tabPgTimeSheet";
            this.tabPgTimeSheet.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgTimeSheet.Size = new System.Drawing.Size(963, 708);
            this.tabPgTimeSheet.TabIndex = 4;
            this.tabPgTimeSheet.Text = "Time Sheet Management";
            this.tabPgTimeSheet.UseVisualStyleBackColor = true;
            this.tabPgTimeSheet.Click += new System.EventHandler(this.tabPgTimeSheet_Click);
            // 
            // lblShiftId
            // 
            this.lblShiftId.AutoSize = true;
            this.lblShiftId.Location = new System.Drawing.Point(158, 93);
            this.lblShiftId.Name = "lblShiftId";
            this.lblShiftId.Size = new System.Drawing.Size(71, 19);
            this.lblShiftId.TabIndex = 29;
            this.lblShiftId.Text = "Shift ID :";
            this.lblShiftId.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblShiftName
            // 
            this.lblShiftName.AutoSize = true;
            this.lblShiftName.Location = new System.Drawing.Point(158, 135);
            this.lblShiftName.Name = "lblShiftName";
            this.lblShiftName.Size = new System.Drawing.Size(93, 19);
            this.lblShiftName.TabIndex = 30;
            this.lblShiftName.Text = "Shift Name :";
            this.lblShiftName.Click += new System.EventHandler(this.lblProjName_Click);
            // 
            // lblTymIn
            // 
            this.lblTymIn.AutoSize = true;
            this.lblTymIn.Location = new System.Drawing.Point(158, 173);
            this.lblTymIn.Name = "lblTymIn";
            this.lblTymIn.Size = new System.Drawing.Size(74, 19);
            this.lblTymIn.TabIndex = 31;
            this.lblTymIn.Text = "Time IN :";
            this.lblTymIn.Click += new System.EventHandler(this.lblClientCode_Click);
            // 
            // lblTymOut
            // 
            this.lblTymOut.AutoSize = true;
            this.lblTymOut.Location = new System.Drawing.Point(158, 211);
            this.lblTymOut.Name = "lblTymOut";
            this.lblTymOut.Size = new System.Drawing.Size(81, 19);
            this.lblTymOut.TabIndex = 32;
            this.lblTymOut.Text = "Time Out :";
            this.lblTymOut.Click += new System.EventHandler(this.lblMgrCode_Click);
            // 
            // txtShiftId
            // 
            this.txtShiftId.Location = new System.Drawing.Point(325, 93);
            this.txtShiftId.Name = "txtShiftId";
            this.txtShiftId.Size = new System.Drawing.Size(266, 26);
            this.txtShiftId.TabIndex = 33;
            this.txtShiftId.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // txtShiftName
            // 
            this.txtShiftName.Location = new System.Drawing.Point(325, 135);
            this.txtShiftName.Name = "txtShiftName";
            this.txtShiftName.Size = new System.Drawing.Size(266, 26);
            this.txtShiftName.TabIndex = 34;
            this.txtShiftName.TextChanged += new System.EventHandler(this.txtProjName_TextChanged);
            // 
            // txtTymIn
            // 
            this.txtTymIn.Location = new System.Drawing.Point(325, 173);
            this.txtTymIn.Name = "txtTymIn";
            this.txtTymIn.Size = new System.Drawing.Size(266, 26);
            this.txtTymIn.TabIndex = 35;
            this.txtTymIn.TextChanged += new System.EventHandler(this.txtClientCode_TextChanged);
            // 
            // txtTymOut
            // 
            this.txtTymOut.Location = new System.Drawing.Point(325, 211);
            this.txtTymOut.Name = "txtTymOut";
            this.txtTymOut.Size = new System.Drawing.Size(266, 26);
            this.txtTymOut.TabIndex = 36;
            this.txtTymOut.TextChanged += new System.EventHandler(this.txtMgrCode_TextChanged);
            // 
            // lblWkHrs
            // 
            this.lblWkHrs.AutoSize = true;
            this.lblWkHrs.Location = new System.Drawing.Point(158, 256);
            this.lblWkHrs.Name = "lblWkHrs";
            this.lblWkHrs.Size = new System.Drawing.Size(96, 19);
            this.lblWkHrs.TabIndex = 37;
            this.lblWkHrs.Text = "Worked Hrs:";
            this.lblWkHrs.Click += new System.EventHandler(this.label3_Click);
            // 
            // txtWkHrs
            // 
            this.txtWkHrs.Location = new System.Drawing.Point(325, 256);
            this.txtWkHrs.Name = "txtWkHrs";
            this.txtWkHrs.Size = new System.Drawing.Size(266, 26);
            this.txtWkHrs.TabIndex = 38;
            this.txtWkHrs.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // btnSubmitTymSheet
            // 
            this.btnSubmitTymSheet.Location = new System.Drawing.Point(123, 387);
            this.btnSubmitTymSheet.Name = "btnSubmitTymSheet";
            this.btnSubmitTymSheet.Size = new System.Drawing.Size(163, 38);
            this.btnSubmitTymSheet.TabIndex = 39;
            this.btnSubmitTymSheet.Text = "Submit";
            this.btnSubmitTymSheet.UseVisualStyleBackColor = true;
            this.btnSubmitTymSheet.Click += new System.EventHandler(this.btnAddProj_Click);
            // 
            // btnUpdateTymSheet
            // 
            this.btnUpdateTymSheet.Location = new System.Drawing.Point(384, 387);
            this.btnUpdateTymSheet.Name = "btnUpdateTymSheet";
            this.btnUpdateTymSheet.Size = new System.Drawing.Size(163, 38);
            this.btnUpdateTymSheet.TabIndex = 40;
            this.btnUpdateTymSheet.Text = "Update";
            this.btnUpdateTymSheet.UseVisualStyleBackColor = true;
            this.btnUpdateTymSheet.Click += new System.EventHandler(this.button4_Click);
            // 
            // tabPgProject
            // 
            this.tabPgProject.Controls.Add(this.btnViewProj);
            this.tabPgProject.Controls.Add(this.dgvProject);
            this.tabPgProject.Controls.Add(this.txtEmployId);
            this.tabPgProject.Controls.Add(this.txtProjId);
            this.tabPgProject.Controls.Add(this.lblEmpld);
            this.tabPgProject.Controls.Add(this.lblProjId);
            this.tabPgProject.Location = new System.Drawing.Point(4, 24);
            this.tabPgProject.Name = "tabPgProject";
            this.tabPgProject.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgProject.Size = new System.Drawing.Size(963, 708);
            this.tabPgProject.TabIndex = 2;
            this.tabPgProject.Text = "Project Details";
            this.tabPgProject.UseVisualStyleBackColor = true;
            // 
            // lblProjId
            // 
            this.lblProjId.AutoSize = true;
            this.lblProjId.Location = new System.Drawing.Point(165, 80);
            this.lblProjId.Name = "lblProjId";
            this.lblProjId.Size = new System.Drawing.Size(87, 19);
            this.lblProjId.TabIndex = 26;
            this.lblProjId.Text = "Project ID :";
            // 
            // txtProjId
            // 
            this.txtProjId.Location = new System.Drawing.Point(332, 73);
            this.txtProjId.Name = "txtProjId";
            this.txtProjId.Size = new System.Drawing.Size(266, 26);
            this.txtProjId.TabIndex = 27;
            // 
            // lblEmpld
            // 
            this.lblEmpld.AutoSize = true;
            this.lblEmpld.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmpld.Location = new System.Drawing.Point(164, 130);
            this.lblEmpld.Name = "lblEmpld";
            this.lblEmpld.Size = new System.Drawing.Size(106, 19);
            this.lblEmpld.TabIndex = 28;
            this.lblEmpld.Text = "Employee ID :";
            // 
            // txtEmployId
            // 
            this.txtEmployId.Location = new System.Drawing.Point(332, 123);
            this.txtEmployId.Name = "txtEmployId";
            this.txtEmployId.Size = new System.Drawing.Size(266, 26);
            this.txtEmployId.TabIndex = 29;
            this.txtEmployId.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // dgvProject
            // 
            this.dgvProject.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProject.Location = new System.Drawing.Point(22, 174);
            this.dgvProject.Name = "dgvProject";
            this.dgvProject.Size = new System.Drawing.Size(781, 364);
            this.dgvProject.TabIndex = 31;
            // 
            // btnViewProj
            // 
            this.btnViewProj.Location = new System.Drawing.Point(285, 571);
            this.btnViewProj.Name = "btnViewProj";
            this.btnViewProj.Size = new System.Drawing.Size(163, 38);
            this.btnViewProj.TabIndex = 32;
            this.btnViewProj.Text = "View Project Details";
            this.btnViewProj.UseVisualStyleBackColor = true;
            this.btnViewProj.Click += new System.EventHandler(this.button3_Click);
            // 
            // tabPgViewProfile
            // 
            this.tabPgViewProfile.Controls.Add(this.label1);
            this.tabPgViewProfile.Controls.Add(this.txtemplyid);
            this.tabPgViewProfile.Controls.Add(this.txtFrstnme);
            this.tabPgViewProfile.Controls.Add(this.txtmgr);
            this.tabPgViewProfile.Controls.Add(this.txtphnnumbr);
            this.tabPgViewProfile.Controls.Add(this.txtsal);
            this.tabPgViewProfile.Controls.Add(this.txtaddrss);
            this.tabPgViewProfile.Controls.Add(this.txtLstnme);
            this.tabPgViewProfile.Controls.Add(this.lblEmplyID);
            this.tabPgViewProfile.Controls.Add(this.btnUpdate);
            this.tabPgViewProfile.Controls.Add(this.btnView);
            this.tabPgViewProfile.Controls.Add(this.cmbgrade);
            this.tabPgViewProfile.Controls.Add(this.cmbdept);
            this.tabPgViewProfile.Controls.Add(this.cmbdesg);
            this.tabPgViewProfile.Controls.Add(this.cmbMStuts);
            this.tabPgViewProfile.Controls.Add(this.cmbgender);
            this.tabPgViewProfile.Controls.Add(this.dtpDOJ);
            this.tabPgViewProfile.Controls.Add(this.dtpDOB);
            this.tabPgViewProfile.Controls.Add(this.lblGrdCode);
            this.tabPgViewProfile.Controls.Add(this.lblMgrId);
            this.tabPgViewProfile.Controls.Add(this.lblDpt);
            this.tabPgViewProfile.Controls.Add(this.lblDesg);
            this.tabPgViewProfile.Controls.Add(this.lblPhnNo);
            this.tabPgViewProfile.Controls.Add(this.lblSal);
            this.tabPgViewProfile.Controls.Add(this.lblMStatus);
            this.tabPgViewProfile.Controls.Add(this.lblAddrs);
            this.tabPgViewProfile.Controls.Add(this.lblgender);
            this.tabPgViewProfile.Controls.Add(this.lblDOJ);
            this.tabPgViewProfile.Controls.Add(this.lblDOB);
            this.tabPgViewProfile.Controls.Add(this.lblLstName);
            this.tabPgViewProfile.Controls.Add(this.lblFrstName);
            this.tabPgViewProfile.Controls.Add(this.llbhome2);
            this.tabPgViewProfile.Location = new System.Drawing.Point(4, 24);
            this.tabPgViewProfile.Name = "tabPgViewProfile";
            this.tabPgViewProfile.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgViewProfile.Size = new System.Drawing.Size(963, 708);
            this.tabPgViewProfile.TabIndex = 0;
            this.tabPgViewProfile.Text = "My Profile";
            this.tabPgViewProfile.UseVisualStyleBackColor = true;
            // 
            // llbhome2
            // 
            this.llbhome2.AutoSize = true;
            this.llbhome2.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbhome2.Location = new System.Drawing.Point(827, -20);
            this.llbhome2.Name = "llbhome2";
            this.llbhome2.Size = new System.Drawing.Size(53, 19);
            this.llbhome2.TabIndex = 56;
            this.llbhome2.TabStop = true;
            this.llbhome2.Text = "Home";
            // 
            // lblFrstName
            // 
            this.lblFrstName.AutoSize = true;
            this.lblFrstName.Location = new System.Drawing.Point(35, 224);
            this.lblFrstName.Name = "lblFrstName";
            this.lblFrstName.Size = new System.Drawing.Size(93, 19);
            this.lblFrstName.TabIndex = 63;
            this.lblFrstName.Text = "First Name :";
            // 
            // lblLstName
            // 
            this.lblLstName.AutoSize = true;
            this.lblLstName.Location = new System.Drawing.Point(497, 224);
            this.lblLstName.Name = "lblLstName";
            this.lblLstName.Size = new System.Drawing.Size(92, 19);
            this.lblLstName.TabIndex = 64;
            this.lblLstName.Text = "Last Name :";
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.Location = new System.Drawing.Point(35, 274);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(110, 19);
            this.lblDOB.TabIndex = 65;
            this.lblDOB.Text = "Date Of Birth :";
            // 
            // lblDOJ
            // 
            this.lblDOJ.AutoSize = true;
            this.lblDOJ.Location = new System.Drawing.Point(498, 272);
            this.lblDOJ.Name = "lblDOJ";
            this.lblDOJ.Size = new System.Drawing.Size(124, 19);
            this.lblDOJ.TabIndex = 66;
            this.lblDOJ.Text = "Date Of Joining :";
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.Location = new System.Drawing.Point(497, 437);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(68, 19);
            this.lblgender.TabIndex = 67;
            this.lblgender.Text = "Gender :";
            // 
            // lblAddrs
            // 
            this.lblAddrs.AutoSize = true;
            this.lblAddrs.Location = new System.Drawing.Point(35, 326);
            this.lblAddrs.Name = "lblAddrs";
            this.lblAddrs.Size = new System.Drawing.Size(73, 19);
            this.lblAddrs.TabIndex = 68;
            this.lblAddrs.Text = "Address :";
            // 
            // lblMStatus
            // 
            this.lblMStatus.AutoSize = true;
            this.lblMStatus.Location = new System.Drawing.Point(498, 391);
            this.lblMStatus.Name = "lblMStatus";
            this.lblMStatus.Size = new System.Drawing.Size(115, 19);
            this.lblMStatus.TabIndex = 69;
            this.lblMStatus.Text = "Marital Status :";
            // 
            // lblSal
            // 
            this.lblSal.AutoSize = true;
            this.lblSal.Location = new System.Drawing.Point(498, 486);
            this.lblSal.Name = "lblSal";
            this.lblSal.Size = new System.Drawing.Size(61, 19);
            this.lblSal.TabIndex = 70;
            this.lblSal.Text = "Salary :";
            // 
            // lblPhnNo
            // 
            this.lblPhnNo.AutoSize = true;
            this.lblPhnNo.Location = new System.Drawing.Point(497, 326);
            this.lblPhnNo.Name = "lblPhnNo";
            this.lblPhnNo.Size = new System.Drawing.Size(117, 19);
            this.lblPhnNo.TabIndex = 71;
            this.lblPhnNo.Text = "Phone Number :";
            // 
            // lblDesg
            // 
            this.lblDesg.AutoSize = true;
            this.lblDesg.Location = new System.Drawing.Point(35, 417);
            this.lblDesg.Name = "lblDesg";
            this.lblDesg.Size = new System.Drawing.Size(98, 19);
            this.lblDesg.TabIndex = 72;
            this.lblDesg.Text = "Designation :";
            // 
            // lblDpt
            // 
            this.lblDpt.AutoSize = true;
            this.lblDpt.Location = new System.Drawing.Point(35, 468);
            this.lblDpt.Name = "lblDpt";
            this.lblDpt.Size = new System.Drawing.Size(102, 19);
            this.lblDpt.TabIndex = 73;
            this.lblDpt.Text = "Department  :";
            // 
            // lblMgrId
            // 
            this.lblMgrId.AutoSize = true;
            this.lblMgrId.Location = new System.Drawing.Point(35, 532);
            this.lblMgrId.Name = "lblMgrId";
            this.lblMgrId.Size = new System.Drawing.Size(119, 19);
            this.lblMgrId.TabIndex = 74;
            this.lblMgrId.Text = "Manager Code :";
            // 
            // lblGrdCode
            // 
            this.lblGrdCode.AutoSize = true;
            this.lblGrdCode.Location = new System.Drawing.Point(497, 532);
            this.lblGrdCode.Name = "lblGrdCode";
            this.lblGrdCode.Size = new System.Drawing.Size(99, 19);
            this.lblGrdCode.TabIndex = 75;
            this.lblGrdCode.Text = "Grade Code :";
            // 
            // txtLstnme
            // 
            this.txtLstnme.Location = new System.Drawing.Point(649, 216);
            this.txtLstnme.Name = "txtLstnme";
            this.txtLstnme.Size = new System.Drawing.Size(200, 26);
            this.txtLstnme.TabIndex = 49;
            // 
            // txtaddrss
            // 
            this.txtaddrss.Location = new System.Drawing.Point(176, 323);
            this.txtaddrss.Multiline = true;
            this.txtaddrss.Name = "txtaddrss";
            this.txtaddrss.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtaddrss.Size = new System.Drawing.Size(200, 58);
            this.txtaddrss.TabIndex = 52;
            // 
            // txtsal
            // 
            this.txtsal.Location = new System.Drawing.Point(649, 478);
            this.txtsal.Name = "txtsal";
            this.txtsal.Size = new System.Drawing.Size(148, 26);
            this.txtsal.TabIndex = 61;
            // 
            // txtphnnumbr
            // 
            this.txtphnnumbr.Location = new System.Drawing.Point(649, 318);
            this.txtphnnumbr.Name = "txtphnnumbr";
            this.txtphnnumbr.Size = new System.Drawing.Size(200, 26);
            this.txtphnnumbr.TabIndex = 53;
            // 
            // txtmgr
            // 
            this.txtmgr.Location = new System.Drawing.Point(176, 524);
            this.txtmgr.Name = "txtmgr";
            this.txtmgr.Size = new System.Drawing.Size(200, 26);
            this.txtmgr.TabIndex = 60;
            // 
            // txtFrstnme
            // 
            this.txtFrstnme.Location = new System.Drawing.Point(176, 216);
            this.txtFrstnme.Name = "txtFrstnme";
            this.txtFrstnme.Size = new System.Drawing.Size(200, 26);
            this.txtFrstnme.TabIndex = 47;
            // 
            // dtpDOB
            // 
            this.dtpDOB.Location = new System.Drawing.Point(176, 272);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(200, 26);
            this.dtpDOB.TabIndex = 50;
            // 
            // dtpDOJ
            // 
            this.dtpDOJ.Location = new System.Drawing.Point(649, 266);
            this.dtpDOJ.Name = "dtpDOJ";
            this.dtpDOJ.Size = new System.Drawing.Size(200, 26);
            this.dtpDOJ.TabIndex = 51;
            // 
            // cmbgender
            // 
            this.cmbgender.FormattingEnabled = true;
            this.cmbgender.Location = new System.Drawing.Point(649, 429);
            this.cmbgender.Name = "cmbgender";
            this.cmbgender.Size = new System.Drawing.Size(148, 27);
            this.cmbgender.TabIndex = 59;
            // 
            // cmbMStuts
            // 
            this.cmbMStuts.FormattingEnabled = true;
            this.cmbMStuts.Location = new System.Drawing.Point(649, 383);
            this.cmbMStuts.Name = "cmbMStuts";
            this.cmbMStuts.Size = new System.Drawing.Size(148, 27);
            this.cmbMStuts.TabIndex = 55;
            // 
            // cmbdesg
            // 
            this.cmbdesg.FormattingEnabled = true;
            this.cmbdesg.Location = new System.Drawing.Point(176, 406);
            this.cmbdesg.Name = "cmbdesg";
            this.cmbdesg.Size = new System.Drawing.Size(200, 27);
            this.cmbdesg.TabIndex = 54;
            // 
            // cmbdept
            // 
            this.cmbdept.FormattingEnabled = true;
            this.cmbdept.Location = new System.Drawing.Point(176, 465);
            this.cmbdept.Name = "cmbdept";
            this.cmbdept.Size = new System.Drawing.Size(200, 27);
            this.cmbdept.TabIndex = 57;
            // 
            // cmbgrade
            // 
            this.cmbgrade.FormattingEnabled = true;
            this.cmbgrade.Location = new System.Drawing.Point(649, 524);
            this.cmbgrade.Name = "cmbgrade";
            this.cmbgrade.Size = new System.Drawing.Size(148, 27);
            this.cmbgrade.TabIndex = 62;
            // 
            // btnView
            // 
            this.btnView.Location = new System.Drawing.Point(157, 593);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(170, 40);
            this.btnView.TabIndex = 76;
            this.btnView.Text = "View Details";
            this.btnView.UseVisualStyleBackColor = true;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(443, 593);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(170, 40);
            this.btnUpdate.TabIndex = 77;
            this.btnUpdate.Text = "Update Details";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdateEmp_Click);
            // 
            // lblEmplyID
            // 
            this.lblEmplyID.AutoSize = true;
            this.lblEmplyID.Location = new System.Drawing.Point(314, 158);
            this.lblEmplyID.Name = "lblEmplyID";
            this.lblEmplyID.Size = new System.Drawing.Size(106, 19);
            this.lblEmplyID.TabIndex = 48;
            this.lblEmplyID.Text = "Employee ID :";
            // 
            // txtemplyid
            // 
            this.txtemplyid.Location = new System.Drawing.Point(436, 155);
            this.txtemplyid.Name = "txtemplyid";
            this.txtemplyid.Size = new System.Drawing.Size(176, 26);
            this.txtemplyid.TabIndex = 79;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPgViewProfile);
            this.tabControl1.Controls.Add(this.tabPgProject);
            this.tabControl1.Controls.Add(this.tabPgTimeSheet);
            this.tabControl1.Controls.Add(this.tabPgSearchEmp);
            this.tabControl1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ItemSize = new System.Drawing.Size(84, 20);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(971, 736);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPgSearchEmp
            // 
            this.tabPgSearchEmp.Controls.Add(this.btnViewEmp);
            this.tabPgSearchEmp.Controls.Add(this.cmbDep);
            this.tabPgSearchEmp.Controls.Add(this.cmbDesig);
            this.tabPgSearchEmp.Controls.Add(this.label6);
            this.tabPgSearchEmp.Controls.Add(this.lblDesig);
            this.tabPgSearchEmp.Controls.Add(this.txtEmpName);
            this.tabPgSearchEmp.Controls.Add(this.lblEmpname);
            this.tabPgSearchEmp.Controls.Add(this.txtEID);
            this.tabPgSearchEmp.Controls.Add(this.lbEId);
            this.tabPgSearchEmp.Location = new System.Drawing.Point(4, 24);
            this.tabPgSearchEmp.Name = "tabPgSearchEmp";
            this.tabPgSearchEmp.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgSearchEmp.Size = new System.Drawing.Size(963, 708);
            this.tabPgSearchEmp.TabIndex = 5;
            this.tabPgSearchEmp.Text = "Search  Employee";
            this.tabPgSearchEmp.UseVisualStyleBackColor = true;
            this.tabPgSearchEmp.Click += new System.EventHandler(this.tabPgSearchEmp_Click);
            // 
            // txtEID
            // 
            this.txtEID.Location = new System.Drawing.Point(355, 124);
            this.txtEID.Name = "txtEID";
            this.txtEID.Size = new System.Drawing.Size(200, 26);
            this.txtEID.TabIndex = 81;
            this.txtEID.TextChanged += new System.EventHandler(this.txtEID_TextChanged);
            // 
            // lbEId
            // 
            this.lbEId.AutoSize = true;
            this.lbEId.Location = new System.Drawing.Point(205, 127);
            this.lbEId.Name = "lbEId";
            this.lbEId.Size = new System.Drawing.Size(106, 19);
            this.lbEId.TabIndex = 80;
            this.lbEId.Text = "Employee ID :";
            this.lbEId.Click += new System.EventHandler(this.label4_Click_1);
            // 
            // txtEmpName
            // 
            this.txtEmpName.Location = new System.Drawing.Point(355, 179);
            this.txtEmpName.Name = "txtEmpName";
            this.txtEmpName.Size = new System.Drawing.Size(200, 26);
            this.txtEmpName.TabIndex = 83;
            this.txtEmpName.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // lblEmpname
            // 
            this.lblEmpname.AutoSize = true;
            this.lblEmpname.Location = new System.Drawing.Point(205, 182);
            this.lblEmpname.Name = "lblEmpname";
            this.lblEmpname.Size = new System.Drawing.Size(128, 19);
            this.lblEmpname.TabIndex = 82;
            this.lblEmpname.Text = "Employee Name :";
            this.lblEmpname.Click += new System.EventHandler(this.label5_Click);
            // 
            // cmbDep
            // 
            this.cmbDep.FormattingEnabled = true;
            this.cmbDep.Location = new System.Drawing.Point(355, 279);
            this.cmbDep.Name = "cmbDep";
            this.cmbDep.Size = new System.Drawing.Size(200, 27);
            this.cmbDep.TabIndex = 85;
            this.cmbDep.SelectedIndexChanged += new System.EventHandler(this.cmbDep_SelectedIndexChanged);
            // 
            // cmbDesig
            // 
            this.cmbDesig.FormattingEnabled = true;
            this.cmbDesig.Location = new System.Drawing.Point(355, 220);
            this.cmbDesig.Name = "cmbDesig";
            this.cmbDesig.Size = new System.Drawing.Size(200, 27);
            this.cmbDesig.TabIndex = 84;
            this.cmbDesig.SelectedIndexChanged += new System.EventHandler(this.cmbDesig_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(201, 282);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 19);
            this.label6.TabIndex = 87;
            this.label6.Text = "Department  :";
            // 
            // lblDesig
            // 
            this.lblDesig.AutoSize = true;
            this.lblDesig.Location = new System.Drawing.Point(201, 231);
            this.lblDesig.Name = "lblDesig";
            this.lblDesig.Size = new System.Drawing.Size(98, 19);
            this.lblDesig.TabIndex = 86;
            this.lblDesig.Text = "Designation :";
            // 
            // btnViewEmp
            // 
            this.btnViewEmp.Location = new System.Drawing.Point(261, 398);
            this.btnViewEmp.Name = "btnViewEmp";
            this.btnViewEmp.Size = new System.Drawing.Size(197, 38);
            this.btnViewEmp.TabIndex = 88;
            this.btnViewEmp.Text = "View Employee Details";
            this.btnViewEmp.UseVisualStyleBackColor = true;
            this.btnViewEmp.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(645, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 19);
            this.label1.TabIndex = 80;
            // 
            // EmployeeActivityForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(864, 712);
            this.Controls.Add(this.tabControl1);
            this.Name = "EmployeeActivityForm";
            this.Text = "EmployeeActivityForm";
            this.tabPgTimeSheet.ResumeLayout(false);
            this.tabPgTimeSheet.PerformLayout();
            this.tabPgProject.ResumeLayout(false);
            this.tabPgProject.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProject)).EndInit();
            this.tabPgViewProfile.ResumeLayout(false);
            this.tabPgViewProfile.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPgSearchEmp.ResumeLayout(false);
            this.tabPgSearchEmp.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPgTimeSheet;
        private System.Windows.Forms.Button btnUpdateTymSheet;
        private System.Windows.Forms.Button btnSubmitTymSheet;
        private System.Windows.Forms.TextBox txtWkHrs;
        private System.Windows.Forms.TextBox txtTymOut;
        private System.Windows.Forms.TextBox txtTymIn;
        private System.Windows.Forms.TextBox txtShiftName;
        private System.Windows.Forms.TextBox txtShiftId;
        private System.Windows.Forms.Label lblWkHrs;
        private System.Windows.Forms.Label lblTymOut;
        private System.Windows.Forms.Label lblTymIn;
        private System.Windows.Forms.Label lblShiftName;
        private System.Windows.Forms.Label lblShiftId;
        private System.Windows.Forms.TabPage tabPgProject;
        private System.Windows.Forms.Button btnViewProj;
        private System.Windows.Forms.DataGridView dgvProject;
        private System.Windows.Forms.TextBox txtEmployId;
        private System.Windows.Forms.TextBox txtProjId;
        private System.Windows.Forms.Label lblEmpld;
        private System.Windows.Forms.Label lblProjId;
        private System.Windows.Forms.TabPage tabPgViewProfile;
        private System.Windows.Forms.TextBox txtemplyid;
        private System.Windows.Forms.TextBox txtFrstnme;
        private System.Windows.Forms.TextBox txtmgr;
        private System.Windows.Forms.TextBox txtphnnumbr;
        private System.Windows.Forms.TextBox txtsal;
        private System.Windows.Forms.TextBox txtaddrss;
        private System.Windows.Forms.TextBox txtLstnme;
        private System.Windows.Forms.Label lblEmplyID;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.ComboBox cmbgrade;
        private System.Windows.Forms.ComboBox cmbdept;
        private System.Windows.Forms.ComboBox cmbdesg;
        private System.Windows.Forms.ComboBox cmbMStuts;
        private System.Windows.Forms.ComboBox cmbgender;
        private System.Windows.Forms.DateTimePicker dtpDOJ;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.Label lblGrdCode;
        private System.Windows.Forms.Label lblMgrId;
        private System.Windows.Forms.Label lblDpt;
        private System.Windows.Forms.Label lblDesg;
        private System.Windows.Forms.Label lblPhnNo;
        private System.Windows.Forms.Label lblSal;
        private System.Windows.Forms.Label lblMStatus;
        private System.Windows.Forms.Label lblAddrs;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.Label lblDOJ;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.Label lblLstName;
        private System.Windows.Forms.Label lblFrstName;
        private System.Windows.Forms.LinkLabel llbhome2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPgSearchEmp;
        private System.Windows.Forms.TextBox txtEmpName;
        private System.Windows.Forms.Label lblEmpname;
        private System.Windows.Forms.TextBox txtEID;
        private System.Windows.Forms.Label lbEId;
        private System.Windows.Forms.ComboBox cmbDep;
        private System.Windows.Forms.ComboBox cmbDesig;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblDesig;
        private System.Windows.Forms.Button btnViewEmp;
        private System.Windows.Forms.Label label1;

    }
}