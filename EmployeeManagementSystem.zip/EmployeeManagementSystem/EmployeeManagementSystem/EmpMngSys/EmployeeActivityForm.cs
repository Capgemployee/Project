﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpMngSys
{
    public partial class EmployeeActivityForm : Form
    {
        public EmployeeActivityForm()
        {
            InitializeComponent();
        }

        private void tabPgSalary_Click(object sender, EventArgs e)
        {

        }

        private void txtempid_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnDeptDisplay_Click(object sender, EventArgs e)
        {

        }

        private void tabPgDepartment_Click(object sender, EventArgs e)
        {

        }

        private void lblDeptId_Click(object sender, EventArgs e)
        {

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtMgrCode_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtProjName_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblMgrCode_Click(object sender, EventArgs e)
        {

        }

        private void lblClientCode_Click(object sender, EventArgs e)
        {

        }

        private void lblProjName_Click(object sender, EventArgs e)
        {

        }

        private void txtClientCode_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPgTimeSheet_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnAddProj_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnUpdateEmp_Click(object sender, EventArgs e)
        {

        }

        private void tabPgSearchEmp_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click_1(object sender, EventArgs e)
        {

        }

        private void cmbDesig_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbDep_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtEID_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
