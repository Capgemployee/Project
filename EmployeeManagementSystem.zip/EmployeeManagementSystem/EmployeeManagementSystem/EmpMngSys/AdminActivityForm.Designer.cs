﻿namespace EmpMngSys
{
    partial class AdminActivityForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminActivityForm));
            this.tabPgTimeSheet = new System.Windows.Forms.TabPage();
            this.btnDisplayTymSheet = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.txtTymEmpid = new System.Windows.Forms.TextBox();
            this.lblTymEmpId = new System.Windows.Forms.Label();
            this.dgvTymSheet = new System.Windows.Forms.DataGridView();
            this.btnlogoff5 = new System.Windows.Forms.Button();
            this.pichome5 = new System.Windows.Forms.PictureBox();
            this.llbhome5 = new System.Windows.Forms.LinkLabel();
            this.tabPgProj = new System.Windows.Forms.TabPage();
            this.btnDeleteProj = new System.Windows.Forms.Button();
            this.btnAddProj = new System.Windows.Forms.Button();
            this.btnViewProj = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.txtMgrCode = new System.Windows.Forms.TextBox();
            this.txtClientCode = new System.Windows.Forms.TextBox();
            this.txtProjName = new System.Windows.Forms.TextBox();
            this.txtProjId = new System.Windows.Forms.TextBox();
            this.lblMgrCode = new System.Windows.Forms.Label();
            this.lblClientCode = new System.Windows.Forms.Label();
            this.lblProjName = new System.Windows.Forms.Label();
            this.lblProjId = new System.Windows.Forms.Label();
            this.btnlogoff4 = new System.Windows.Forms.Button();
            this.pichome4 = new System.Windows.Forms.PictureBox();
            this.llbhome4 = new System.Windows.Forms.LinkLabel();
            this.tabPgdept = new System.Windows.Forms.TabPage();
            this.btnDeptDelete = new System.Windows.Forms.Button();
            this.btnDeptAdd = new System.Windows.Forms.Button();
            this.btnDeptDisplay = new System.Windows.Forms.Button();
            this.btnhome3 = new System.Windows.Forms.Button();
            this.pichome3 = new System.Windows.Forms.PictureBox();
            this.llbhome3 = new System.Windows.Forms.LinkLabel();
            this.dgvDeptDetails = new System.Windows.Forms.DataGridView();
            this.txtDeptName = new System.Windows.Forms.TextBox();
            this.txtDeptId = new System.Windows.Forms.TextBox();
            this.lblDeptName = new System.Windows.Forms.Label();
            this.lblDeptId = new System.Windows.Forms.Label();
            this.tabPgAddEmp = new System.Windows.Forms.TabPage();
            this.btnlogoff2 = new System.Windows.Forms.Button();
            this.pichome2 = new System.Windows.Forms.PictureBox();
            this.llbhome2 = new System.Windows.Forms.LinkLabel();
            this.tabPgViewEmp = new System.Windows.Forms.TabPage();
            this.btnlogoff1 = new System.Windows.Forms.Button();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.pichome1 = new System.Windows.Forms.PictureBox();
            this.llbhome1 = new System.Windows.Forms.LinkLabel();
            this.dgvEmpDetails = new System.Windows.Forms.DataGridView();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtempid = new System.Windows.Forms.TextBox();
            this.lblEmpId = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPgTimeSheet.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTymSheet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pichome5)).BeginInit();
            this.tabPgProj.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pichome4)).BeginInit();
            this.tabPgdept.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pichome3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeptDetails)).BeginInit();
            this.tabPgAddEmp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pichome2)).BeginInit();
            this.tabPgViewEmp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pichome1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpDetails)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPgTimeSheet
            // 
            this.tabPgTimeSheet.Controls.Add(this.btnDisplayTymSheet);
            this.tabPgTimeSheet.Controls.Add(this.button1);
            this.tabPgTimeSheet.Controls.Add(this.txtTymEmpid);
            this.tabPgTimeSheet.Controls.Add(this.lblTymEmpId);
            this.tabPgTimeSheet.Controls.Add(this.dgvTymSheet);
            this.tabPgTimeSheet.Controls.Add(this.btnlogoff5);
            this.tabPgTimeSheet.Controls.Add(this.pichome5);
            this.tabPgTimeSheet.Controls.Add(this.llbhome5);
            this.tabPgTimeSheet.Location = new System.Drawing.Point(4, 24);
            this.tabPgTimeSheet.Name = "tabPgTimeSheet";
            this.tabPgTimeSheet.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgTimeSheet.Size = new System.Drawing.Size(963, 708);
            this.tabPgTimeSheet.TabIndex = 5;
            this.tabPgTimeSheet.Text = "Time Sheet Management";
            this.tabPgTimeSheet.UseVisualStyleBackColor = true;
            // 
            // btnDisplayTymSheet
            // 
            this.btnDisplayTymSheet.Location = new System.Drawing.Point(40, 78);
            this.btnDisplayTymSheet.Name = "btnDisplayTymSheet";
            this.btnDisplayTymSheet.Size = new System.Drawing.Size(291, 26);
            this.btnDisplayTymSheet.TabIndex = 36;
            this.btnDisplayTymSheet.Text = "Display Time Sheet";
            this.btnDisplayTymSheet.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Location = new System.Drawing.Point(856, 74);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(34, 36);
            this.button1.TabIndex = 35;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // txtTymEmpid
            // 
            this.txtTymEmpid.Location = new System.Drawing.Point(634, 78);
            this.txtTymEmpid.Name = "txtTymEmpid";
            this.txtTymEmpid.Size = new System.Drawing.Size(216, 26);
            this.txtTymEmpid.TabIndex = 34;
            // 
            // lblTymEmpId
            // 
            this.lblTymEmpId.AutoSize = true;
            this.lblTymEmpId.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTymEmpId.Location = new System.Drawing.Point(522, 81);
            this.lblTymEmpId.Name = "lblTymEmpId";
            this.lblTymEmpId.Size = new System.Drawing.Size(106, 19);
            this.lblTymEmpId.TabIndex = 33;
            this.lblTymEmpId.Text = "Employee ID :";
            // 
            // dgvTymSheet
            // 
            this.dgvTymSheet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTymSheet.Location = new System.Drawing.Point(40, 137);
            this.dgvTymSheet.Name = "dgvTymSheet";
            this.dgvTymSheet.Size = new System.Drawing.Size(850, 507);
            this.dgvTymSheet.TabIndex = 31;
            // 
            // btnlogoff5
            // 
            this.btnlogoff5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnlogoff5.BackgroundImage")));
            this.btnlogoff5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnlogoff5.Location = new System.Drawing.Point(899, 658);
            this.btnlogoff5.Name = "btnlogoff5";
            this.btnlogoff5.Size = new System.Drawing.Size(35, 33);
            this.btnlogoff5.TabIndex = 20;
            this.btnlogoff5.UseVisualStyleBackColor = true;
            // 
            // pichome5
            // 
            this.pichome5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pichome5.BackgroundImage")));
            this.pichome5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pichome5.Location = new System.Drawing.Point(854, 23);
            this.pichome5.Name = "pichome5";
            this.pichome5.Size = new System.Drawing.Size(35, 35);
            this.pichome5.TabIndex = 19;
            this.pichome5.TabStop = false;
            // 
            // llbhome5
            // 
            this.llbhome5.AutoSize = true;
            this.llbhome5.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbhome5.Location = new System.Drawing.Point(895, 23);
            this.llbhome5.Name = "llbhome5";
            this.llbhome5.Size = new System.Drawing.Size(53, 19);
            this.llbhome5.TabIndex = 18;
            this.llbhome5.TabStop = true;
            this.llbhome5.Text = "Home";
            // 
            // tabPgProj
            // 
            this.tabPgProj.Controls.Add(this.btnDeleteProj);
            this.tabPgProj.Controls.Add(this.btnAddProj);
            this.tabPgProj.Controls.Add(this.btnViewProj);
            this.tabPgProj.Controls.Add(this.dataGridView2);
            this.tabPgProj.Controls.Add(this.txtMgrCode);
            this.tabPgProj.Controls.Add(this.txtClientCode);
            this.tabPgProj.Controls.Add(this.txtProjName);
            this.tabPgProj.Controls.Add(this.txtProjId);
            this.tabPgProj.Controls.Add(this.lblMgrCode);
            this.tabPgProj.Controls.Add(this.lblClientCode);
            this.tabPgProj.Controls.Add(this.lblProjName);
            this.tabPgProj.Controls.Add(this.lblProjId);
            this.tabPgProj.Controls.Add(this.btnlogoff4);
            this.tabPgProj.Controls.Add(this.pichome4);
            this.tabPgProj.Controls.Add(this.llbhome4);
            this.tabPgProj.Location = new System.Drawing.Point(4, 24);
            this.tabPgProj.Name = "tabPgProj";
            this.tabPgProj.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgProj.Size = new System.Drawing.Size(963, 708);
            this.tabPgProj.TabIndex = 4;
            this.tabPgProj.Text = "Project Details";
            this.tabPgProj.UseVisualStyleBackColor = true;
            this.tabPgProj.Click += new System.EventHandler(this.tabPgProj_Click);
            // 
            // btnDeleteProj
            // 
            this.btnDeleteProj.Location = new System.Drawing.Point(697, 624);
            this.btnDeleteProj.Name = "btnDeleteProj";
            this.btnDeleteProj.Size = new System.Drawing.Size(163, 38);
            this.btnDeleteProj.TabIndex = 32;
            this.btnDeleteProj.Text = "Delete Project";
            this.btnDeleteProj.UseVisualStyleBackColor = true;
            // 
            // btnAddProj
            // 
            this.btnAddProj.Location = new System.Drawing.Point(384, 624);
            this.btnAddProj.Name = "btnAddProj";
            this.btnAddProj.Size = new System.Drawing.Size(163, 38);
            this.btnAddProj.TabIndex = 31;
            this.btnAddProj.Text = "Add Project";
            this.btnAddProj.UseVisualStyleBackColor = true;
            // 
            // btnViewProj
            // 
            this.btnViewProj.Location = new System.Drawing.Point(68, 624);
            this.btnViewProj.Name = "btnViewProj";
            this.btnViewProj.Size = new System.Drawing.Size(163, 38);
            this.btnViewProj.TabIndex = 30;
            this.btnViewProj.Text = "View Project Details";
            this.btnViewProj.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(64, 227);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(796, 376);
            this.dataGridView2.TabIndex = 29;
            // 
            // txtMgrCode
            // 
            this.txtMgrCode.Location = new System.Drawing.Point(408, 183);
            this.txtMgrCode.Name = "txtMgrCode";
            this.txtMgrCode.Size = new System.Drawing.Size(266, 26);
            this.txtMgrCode.TabIndex = 28;
            // 
            // txtClientCode
            // 
            this.txtClientCode.Location = new System.Drawing.Point(408, 145);
            this.txtClientCode.Name = "txtClientCode";
            this.txtClientCode.Size = new System.Drawing.Size(266, 26);
            this.txtClientCode.TabIndex = 27;
            // 
            // txtProjName
            // 
            this.txtProjName.Location = new System.Drawing.Point(408, 107);
            this.txtProjName.Name = "txtProjName";
            this.txtProjName.Size = new System.Drawing.Size(266, 26);
            this.txtProjName.TabIndex = 26;
            // 
            // txtProjId
            // 
            this.txtProjId.Location = new System.Drawing.Point(408, 65);
            this.txtProjId.Name = "txtProjId";
            this.txtProjId.Size = new System.Drawing.Size(266, 26);
            this.txtProjId.TabIndex = 25;
            // 
            // lblMgrCode
            // 
            this.lblMgrCode.AutoSize = true;
            this.lblMgrCode.Location = new System.Drawing.Point(241, 183);
            this.lblMgrCode.Name = "lblMgrCode";
            this.lblMgrCode.Size = new System.Drawing.Size(119, 19);
            this.lblMgrCode.TabIndex = 24;
            this.lblMgrCode.Text = "Manager Code :";
            // 
            // lblClientCode
            // 
            this.lblClientCode.AutoSize = true;
            this.lblClientCode.Location = new System.Drawing.Point(241, 145);
            this.lblClientCode.Name = "lblClientCode";
            this.lblClientCode.Size = new System.Drawing.Size(97, 19);
            this.lblClientCode.TabIndex = 23;
            this.lblClientCode.Text = "Client Code :";
            // 
            // lblProjName
            // 
            this.lblProjName.AutoSize = true;
            this.lblProjName.Location = new System.Drawing.Point(241, 107);
            this.lblProjName.Name = "lblProjName";
            this.lblProjName.Size = new System.Drawing.Size(109, 19);
            this.lblProjName.TabIndex = 22;
            this.lblProjName.Text = "Project Name :";
            // 
            // lblProjId
            // 
            this.lblProjId.AutoSize = true;
            this.lblProjId.Location = new System.Drawing.Point(241, 65);
            this.lblProjId.Name = "lblProjId";
            this.lblProjId.Size = new System.Drawing.Size(87, 19);
            this.lblProjId.TabIndex = 21;
            this.lblProjId.Text = "Project ID :";
            // 
            // btnlogoff4
            // 
            this.btnlogoff4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnlogoff4.BackgroundImage")));
            this.btnlogoff4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnlogoff4.Location = new System.Drawing.Point(900, 662);
            this.btnlogoff4.Name = "btnlogoff4";
            this.btnlogoff4.Size = new System.Drawing.Size(35, 33);
            this.btnlogoff4.TabIndex = 20;
            this.btnlogoff4.UseVisualStyleBackColor = true;
            // 
            // pichome4
            // 
            this.pichome4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pichome4.BackgroundImage")));
            this.pichome4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pichome4.Location = new System.Drawing.Point(841, 23);
            this.pichome4.Name = "pichome4";
            this.pichome4.Size = new System.Drawing.Size(35, 35);
            this.pichome4.TabIndex = 19;
            this.pichome4.TabStop = false;
            // 
            // llbhome4
            // 
            this.llbhome4.AutoSize = true;
            this.llbhome4.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbhome4.Location = new System.Drawing.Point(882, 23);
            this.llbhome4.Name = "llbhome4";
            this.llbhome4.Size = new System.Drawing.Size(53, 19);
            this.llbhome4.TabIndex = 18;
            this.llbhome4.TabStop = true;
            this.llbhome4.Text = "Home";
            // 
            // tabPgdept
            // 
            this.tabPgdept.Controls.Add(this.btnDeptDelete);
            this.tabPgdept.Controls.Add(this.btnDeptAdd);
            this.tabPgdept.Controls.Add(this.btnDeptDisplay);
            this.tabPgdept.Controls.Add(this.btnhome3);
            this.tabPgdept.Controls.Add(this.pichome3);
            this.tabPgdept.Controls.Add(this.llbhome3);
            this.tabPgdept.Controls.Add(this.dgvDeptDetails);
            this.tabPgdept.Controls.Add(this.txtDeptName);
            this.tabPgdept.Controls.Add(this.txtDeptId);
            this.tabPgdept.Controls.Add(this.lblDeptName);
            this.tabPgdept.Controls.Add(this.lblDeptId);
            this.tabPgdept.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPgdept.Location = new System.Drawing.Point(4, 24);
            this.tabPgdept.Name = "tabPgdept";
            this.tabPgdept.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgdept.Size = new System.Drawing.Size(963, 708);
            this.tabPgdept.TabIndex = 2;
            this.tabPgdept.Text = "Department";
            this.tabPgdept.UseVisualStyleBackColor = true;
            // 
            // btnDeptDelete
            // 
            this.btnDeptDelete.Location = new System.Drawing.Point(708, 587);
            this.btnDeptDelete.Name = "btnDeptDelete";
            this.btnDeptDelete.Size = new System.Drawing.Size(163, 38);
            this.btnDeptDelete.TabIndex = 17;
            this.btnDeptDelete.Text = "Delete Department";
            this.btnDeptDelete.UseVisualStyleBackColor = true;
            // 
            // btnDeptAdd
            // 
            this.btnDeptAdd.Location = new System.Drawing.Point(395, 587);
            this.btnDeptAdd.Name = "btnDeptAdd";
            this.btnDeptAdd.Size = new System.Drawing.Size(163, 38);
            this.btnDeptAdd.TabIndex = 16;
            this.btnDeptAdd.Text = "Add Department";
            this.btnDeptAdd.UseVisualStyleBackColor = true;
            // 
            // btnDeptDisplay
            // 
            this.btnDeptDisplay.Location = new System.Drawing.Point(79, 587);
            this.btnDeptDisplay.Name = "btnDeptDisplay";
            this.btnDeptDisplay.Size = new System.Drawing.Size(163, 38);
            this.btnDeptDisplay.TabIndex = 15;
            this.btnDeptDisplay.Text = "View Departments";
            this.btnDeptDisplay.UseVisualStyleBackColor = true;
            // 
            // btnhome3
            // 
            this.btnhome3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnhome3.BackgroundImage")));
            this.btnhome3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnhome3.Location = new System.Drawing.Point(911, 654);
            this.btnhome3.Name = "btnhome3";
            this.btnhome3.Size = new System.Drawing.Size(35, 32);
            this.btnhome3.TabIndex = 14;
            this.btnhome3.UseVisualStyleBackColor = true;
            // 
            // pichome3
            // 
            this.pichome3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pichome3.BackgroundImage")));
            this.pichome3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pichome3.Location = new System.Drawing.Point(852, 19);
            this.pichome3.Name = "pichome3";
            this.pichome3.Size = new System.Drawing.Size(35, 35);
            this.pichome3.TabIndex = 13;
            this.pichome3.TabStop = false;
            // 
            // llbhome3
            // 
            this.llbhome3.AutoSize = true;
            this.llbhome3.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbhome3.Location = new System.Drawing.Point(893, 19);
            this.llbhome3.Name = "llbhome3";
            this.llbhome3.Size = new System.Drawing.Size(53, 19);
            this.llbhome3.TabIndex = 12;
            this.llbhome3.TabStop = true;
            this.llbhome3.Text = "Home";
            // 
            // dgvDeptDetails
            // 
            this.dgvDeptDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDeptDetails.Location = new System.Drawing.Point(79, 147);
            this.dgvDeptDetails.Name = "dgvDeptDetails";
            this.dgvDeptDetails.Size = new System.Drawing.Size(792, 411);
            this.dgvDeptDetails.TabIndex = 4;
            // 
            // txtDeptName
            // 
            this.txtDeptName.Location = new System.Drawing.Point(489, 101);
            this.txtDeptName.Name = "txtDeptName";
            this.txtDeptName.Size = new System.Drawing.Size(164, 26);
            this.txtDeptName.TabIndex = 3;
            // 
            // txtDeptId
            // 
            this.txtDeptId.Location = new System.Drawing.Point(489, 65);
            this.txtDeptId.Name = "txtDeptId";
            this.txtDeptId.Size = new System.Drawing.Size(164, 26);
            this.txtDeptId.TabIndex = 2;
            // 
            // lblDeptName
            // 
            this.lblDeptName.AutoSize = true;
            this.lblDeptName.Location = new System.Drawing.Point(325, 108);
            this.lblDeptName.Name = "lblDeptName";
            this.lblDeptName.Size = new System.Drawing.Size(142, 19);
            this.lblDeptName.TabIndex = 1;
            this.lblDeptName.Text = "Department Name :";
            // 
            // lblDeptId
            // 
            this.lblDeptId.AutoSize = true;
            this.lblDeptId.Location = new System.Drawing.Point(325, 68);
            this.lblDeptId.Name = "lblDeptId";
            this.lblDeptId.Size = new System.Drawing.Size(120, 19);
            this.lblDeptId.TabIndex = 0;
            this.lblDeptId.Text = "Department ID :";
            // 
            // tabPgAddEmp
            // 
            this.tabPgAddEmp.Controls.Add(this.btnlogoff2);
            this.tabPgAddEmp.Controls.Add(this.pichome2);
            this.tabPgAddEmp.Controls.Add(this.llbhome2);
            this.tabPgAddEmp.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPgAddEmp.Location = new System.Drawing.Point(4, 24);
            this.tabPgAddEmp.Name = "tabPgAddEmp";
            this.tabPgAddEmp.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgAddEmp.Size = new System.Drawing.Size(963, 708);
            this.tabPgAddEmp.TabIndex = 1;
            this.tabPgAddEmp.Text = "Add Employee";
            this.tabPgAddEmp.UseVisualStyleBackColor = true;
            // 
            // btnlogoff2
            // 
            this.btnlogoff2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnlogoff2.BackgroundImage")));
            this.btnlogoff2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnlogoff2.Location = new System.Drawing.Point(912, 652);
            this.btnlogoff2.Name = "btnlogoff2";
            this.btnlogoff2.Size = new System.Drawing.Size(35, 32);
            this.btnlogoff2.TabIndex = 11;
            this.btnlogoff2.UseVisualStyleBackColor = true;
            // 
            // pichome2
            // 
            this.pichome2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pichome2.BackgroundImage")));
            this.pichome2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pichome2.Location = new System.Drawing.Point(853, 17);
            this.pichome2.Name = "pichome2";
            this.pichome2.Size = new System.Drawing.Size(35, 35);
            this.pichome2.TabIndex = 9;
            this.pichome2.TabStop = false;
            // 
            // llbhome2
            // 
            this.llbhome2.AutoSize = true;
            this.llbhome2.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbhome2.Location = new System.Drawing.Point(894, 17);
            this.llbhome2.Name = "llbhome2";
            this.llbhome2.Size = new System.Drawing.Size(53, 19);
            this.llbhome2.TabIndex = 8;
            this.llbhome2.TabStop = true;
            this.llbhome2.Text = "Home";
            // 
            // tabPgViewEmp
            // 
            this.tabPgViewEmp.Controls.Add(this.btnlogoff1);
            this.tabPgViewEmp.Controls.Add(this.btnDisplay);
            this.tabPgViewEmp.Controls.Add(this.pichome1);
            this.tabPgViewEmp.Controls.Add(this.llbhome1);
            this.tabPgViewEmp.Controls.Add(this.dgvEmpDetails);
            this.tabPgViewEmp.Controls.Add(this.btnSearch);
            this.tabPgViewEmp.Controls.Add(this.txtempid);
            this.tabPgViewEmp.Controls.Add(this.lblEmpId);
            this.tabPgViewEmp.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPgViewEmp.Location = new System.Drawing.Point(4, 24);
            this.tabPgViewEmp.Name = "tabPgViewEmp";
            this.tabPgViewEmp.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgViewEmp.Size = new System.Drawing.Size(963, 708);
            this.tabPgViewEmp.TabIndex = 0;
            this.tabPgViewEmp.Text = "View Employee";
            this.tabPgViewEmp.UseVisualStyleBackColor = true;
            this.tabPgViewEmp.Click += new System.EventHandler(this.tabPgViewEmp_Click);
            // 
            // btnlogoff1
            // 
            this.btnlogoff1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnlogoff1.BackgroundImage")));
            this.btnlogoff1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnlogoff1.Location = new System.Drawing.Point(905, 663);
            this.btnlogoff1.Name = "btnlogoff1";
            this.btnlogoff1.Size = new System.Drawing.Size(34, 28);
            this.btnlogoff1.TabIndex = 10;
            this.btnlogoff1.UseVisualStyleBackColor = true;
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(8, 52);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(212, 33);
            this.btnDisplay.TabIndex = 9;
            this.btnDisplay.Text = "Display Employee";
            this.btnDisplay.UseVisualStyleBackColor = true;
            // 
            // pichome1
            // 
            this.pichome1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pichome1.BackgroundImage")));
            this.pichome1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pichome1.Location = new System.Drawing.Point(843, 16);
            this.pichome1.Name = "pichome1";
            this.pichome1.Size = new System.Drawing.Size(34, 35);
            this.pichome1.TabIndex = 7;
            this.pichome1.TabStop = false;
            // 
            // llbhome1
            // 
            this.llbhome1.AutoSize = true;
            this.llbhome1.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Bold);
            this.llbhome1.Location = new System.Drawing.Point(883, 18);
            this.llbhome1.Name = "llbhome1";
            this.llbhome1.Size = new System.Drawing.Size(56, 20);
            this.llbhome1.TabIndex = 6;
            this.llbhome1.TabStop = true;
            this.llbhome1.Text = "Home";
            // 
            // dgvEmpDetails
            // 
            this.dgvEmpDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmpDetails.Location = new System.Drawing.Point(8, 97);
            this.dgvEmpDetails.Name = "dgvEmpDetails";
            this.dgvEmpDetails.Size = new System.Drawing.Size(931, 560);
            this.dgvEmpDetails.TabIndex = 3;
            // 
            // btnSearch
            // 
            this.btnSearch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSearch.BackgroundImage")));
            this.btnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSearch.Location = new System.Drawing.Point(905, 55);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(34, 36);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // txtempid
            // 
            this.txtempid.Location = new System.Drawing.Point(683, 57);
            this.txtempid.Name = "txtempid";
            this.txtempid.Size = new System.Drawing.Size(216, 29);
            this.txtempid.TabIndex = 1;
            // 
            // lblEmpId
            // 
            this.lblEmpId.AutoSize = true;
            this.lblEmpId.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmpId.Location = new System.Drawing.Point(571, 62);
            this.lblEmpId.Name = "lblEmpId";
            this.lblEmpId.Size = new System.Drawing.Size(106, 19);
            this.lblEmpId.TabIndex = 0;
            this.lblEmpId.Text = "Employee ID :";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPgViewEmp);
            this.tabControl1.Controls.Add(this.tabPgAddEmp);
            this.tabControl1.Controls.Add(this.tabPgdept);
            this.tabControl1.Controls.Add(this.tabPgProj);
            this.tabControl1.Controls.Add(this.tabPgTimeSheet);
            this.tabControl1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ItemSize = new System.Drawing.Size(84, 20);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(971, 736);
            this.tabControl1.TabIndex = 0;
            // 
            // AdminActivityForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(994, 748);
            this.Controls.Add(this.tabControl1);
            this.Name = "AdminActivityForm";
            this.Text = "AdminActivityForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.AdminActivityForm_Load);
            this.tabPgTimeSheet.ResumeLayout(false);
            this.tabPgTimeSheet.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTymSheet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pichome5)).EndInit();
            this.tabPgProj.ResumeLayout(false);
            this.tabPgProj.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pichome4)).EndInit();
            this.tabPgdept.ResumeLayout(false);
            this.tabPgdept.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pichome3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeptDetails)).EndInit();
            this.tabPgAddEmp.ResumeLayout(false);
            this.tabPgAddEmp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pichome2)).EndInit();
            this.tabPgViewEmp.ResumeLayout(false);
            this.tabPgViewEmp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pichome1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpDetails)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPgTimeSheet;
        private System.Windows.Forms.Button btnlogoff5;
        private System.Windows.Forms.PictureBox pichome5;
        private System.Windows.Forms.LinkLabel llbhome5;
        private System.Windows.Forms.TabPage tabPgProj;
        private System.Windows.Forms.Button btnlogoff4;
        private System.Windows.Forms.PictureBox pichome4;
        private System.Windows.Forms.LinkLabel llbhome4;
        private System.Windows.Forms.TabPage tabPgdept;
        private System.Windows.Forms.Button btnhome3;
        private System.Windows.Forms.PictureBox pichome3;
        private System.Windows.Forms.LinkLabel llbhome3;
        private System.Windows.Forms.DataGridView dgvDeptDetails;
        private System.Windows.Forms.TextBox txtDeptName;
        private System.Windows.Forms.TextBox txtDeptId;
        private System.Windows.Forms.Label lblDeptName;
        private System.Windows.Forms.Label lblDeptId;
        private System.Windows.Forms.TabPage tabPgAddEmp;
        private System.Windows.Forms.Button btnlogoff2;
        private System.Windows.Forms.PictureBox pichome2;
        private System.Windows.Forms.LinkLabel llbhome2;
        private System.Windows.Forms.TabPage tabPgViewEmp;
        private System.Windows.Forms.Button btnlogoff1;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.PictureBox pichome1;
        private System.Windows.Forms.LinkLabel llbhome1;
        private System.Windows.Forms.DataGridView dgvEmpDetails;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtempid;
        private System.Windows.Forms.Label lblEmpId;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Button btnDeleteProj;
        private System.Windows.Forms.Button btnAddProj;
        private System.Windows.Forms.Button btnViewProj;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox txtMgrCode;
        private System.Windows.Forms.TextBox txtClientCode;
        private System.Windows.Forms.TextBox txtProjName;
        private System.Windows.Forms.TextBox txtProjId;
        private System.Windows.Forms.Label lblMgrCode;
        private System.Windows.Forms.Label lblClientCode;
        private System.Windows.Forms.Label lblProjName;
        private System.Windows.Forms.Label lblProjId;
        private System.Windows.Forms.Button btnDeptDelete;
        private System.Windows.Forms.Button btnDeptAdd;
        private System.Windows.Forms.Button btnDeptDisplay;
        private System.Windows.Forms.Button btnDisplayTymSheet;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtTymEmpid;
        private System.Windows.Forms.Label lblTymEmpId;
        private System.Windows.Forms.DataGridView dgvTymSheet;





    }
}