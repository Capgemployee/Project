﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpMngSys
{
    public partial class AdminActivityForm : Form
    {
        public AdminActivityForm()
        {
            InitializeComponent();
        }

        private void AdminActivityForm_Load(object sender, EventArgs e)
        {
            tabControl1.Height = this.Height;
            tabControl1.Width = this.Width;
        }

        private void tabPgViewEmp_Click(object sender, EventArgs e)
        {

        }

        private void tabPgProj_Click(object sender, EventArgs e)
        {

        }
    }
}
