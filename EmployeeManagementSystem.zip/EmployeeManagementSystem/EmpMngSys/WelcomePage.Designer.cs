﻿namespace EmpMngSys
{
    partial class WelcomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WelcomePage));
            this.btnAdmLgn = new System.Windows.Forms.Button();
            this.btnEmpLgn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAdmLgn
            // 
            this.btnAdmLgn.AutoSize = true;
            this.btnAdmLgn.BackColor = System.Drawing.Color.AliceBlue;
            this.btnAdmLgn.FlatAppearance.BorderColor = System.Drawing.Color.AliceBlue;
            this.btnAdmLgn.FlatAppearance.BorderSize = 0;
            this.btnAdmLgn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdmLgn.ForeColor = System.Drawing.Color.Black;
            this.btnAdmLgn.Image = ((System.Drawing.Image)(resources.GetObject("btnAdmLgn.Image")));
            this.btnAdmLgn.Location = new System.Drawing.Point(759, 150);
            this.btnAdmLgn.Name = "btnAdmLgn";
            this.btnAdmLgn.Size = new System.Drawing.Size(127, 137);
            this.btnAdmLgn.TabIndex = 3;
            this.btnAdmLgn.Text = "ADMIN ";
            this.btnAdmLgn.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnAdmLgn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAdmLgn.UseVisualStyleBackColor = false;
            this.btnAdmLgn.Click += new System.EventHandler(this.btnAdmLgn_Click);
            // 
            // btnEmpLgn
            // 
            this.btnEmpLgn.AutoSize = true;
            this.btnEmpLgn.BackColor = System.Drawing.Color.AliceBlue;
            this.btnEmpLgn.FlatAppearance.BorderColor = System.Drawing.Color.AliceBlue;
            this.btnEmpLgn.FlatAppearance.BorderSize = 0;
            this.btnEmpLgn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmpLgn.ForeColor = System.Drawing.Color.Black;
            this.btnEmpLgn.Image = ((System.Drawing.Image)(resources.GetObject("btnEmpLgn.Image")));
            this.btnEmpLgn.Location = new System.Drawing.Point(759, 334);
            this.btnEmpLgn.Name = "btnEmpLgn";
            this.btnEmpLgn.Size = new System.Drawing.Size(125, 137);
            this.btnEmpLgn.TabIndex = 5;
            this.btnEmpLgn.Text = "Employee";
            this.btnEmpLgn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEmpLgn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnEmpLgn.UseVisualStyleBackColor = false;
            this.btnEmpLgn.Click += new System.EventHandler(this.btnEmpLgn_Click);
            // 
            // WelcomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 641);
            this.Controls.Add(this.btnEmpLgn);
            this.Controls.Add(this.btnAdmLgn);
            this.Name = "WelcomePage";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAdmLgn;
        private System.Windows.Forms.Button btnEmpLgn;
    }
}

