﻿namespace EmpMngSys
{
    partial class AdminActivityForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminActivityForm));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPgViewEmp = new System.Windows.Forms.TabPage();
            this.tabPgAddEmp = new System.Windows.Forms.TabPage();
            this.tabPgdept = new System.Windows.Forms.TabPage();
            this.tabPgSal = new System.Windows.Forms.TabPage();
            this.lblEmpId = new System.Windows.Forms.Label();
            this.txtempid = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dgvEmpDetails = new System.Windows.Forms.DataGridView();
            this.llbhome1 = new System.Windows.Forms.LinkLabel();
            this.pichome1 = new System.Windows.Forms.PictureBox();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.lblDeptId = new System.Windows.Forms.Label();
            this.lblDeptName = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.pichome2 = new System.Windows.Forms.PictureBox();
            this.llbhome2 = new System.Windows.Forms.LinkLabel();
            this.btnlogoff1 = new System.Windows.Forms.Button();
            this.btnlogoff2 = new System.Windows.Forms.Button();
            this.btnhome3 = new System.Windows.Forms.Button();
            this.pichome3 = new System.Windows.Forms.PictureBox();
            this.llbhome3 = new System.Windows.Forms.LinkLabel();
            this.btnhome4 = new System.Windows.Forms.Button();
            this.pichome4 = new System.Windows.Forms.PictureBox();
            this.llbhome4 = new System.Windows.Forms.LinkLabel();
            this.tabPgProj = new System.Windows.Forms.TabPage();
            this.tabPgTimeSheet = new System.Windows.Forms.TabPage();
            this.btnlogoff5 = new System.Windows.Forms.Button();
            this.pichome5 = new System.Windows.Forms.PictureBox();
            this.llbhome5 = new System.Windows.Forms.LinkLabel();
            this.tabControl1.SuspendLayout();
            this.tabPgViewEmp.SuspendLayout();
            this.tabPgAddEmp.SuspendLayout();
            this.tabPgdept.SuspendLayout();
            this.tabPgSal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pichome1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pichome2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pichome3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pichome4)).BeginInit();
            this.tabPgProj.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pichome5)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPgViewEmp);
            this.tabControl1.Controls.Add(this.tabPgAddEmp);
            this.tabControl1.Controls.Add(this.tabPgdept);
            this.tabControl1.Controls.Add(this.tabPgSal);
            this.tabControl1.Controls.Add(this.tabPgProj);
            this.tabControl1.Controls.Add(this.tabPgTimeSheet);
            this.tabControl1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ItemSize = new System.Drawing.Size(84, 20);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(971, 736);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPgViewEmp
            // 
            this.tabPgViewEmp.Controls.Add(this.btnlogoff1);
            this.tabPgViewEmp.Controls.Add(this.btnDisplay);
            this.tabPgViewEmp.Controls.Add(this.pichome1);
            this.tabPgViewEmp.Controls.Add(this.llbhome1);
            this.tabPgViewEmp.Controls.Add(this.dgvEmpDetails);
            this.tabPgViewEmp.Controls.Add(this.btnSearch);
            this.tabPgViewEmp.Controls.Add(this.txtempid);
            this.tabPgViewEmp.Controls.Add(this.lblEmpId);
            this.tabPgViewEmp.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPgViewEmp.Location = new System.Drawing.Point(4, 24);
            this.tabPgViewEmp.Name = "tabPgViewEmp";
            this.tabPgViewEmp.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgViewEmp.Size = new System.Drawing.Size(963, 708);
            this.tabPgViewEmp.TabIndex = 0;
            this.tabPgViewEmp.Text = "View Employee";
            this.tabPgViewEmp.UseVisualStyleBackColor = true;
            // 
            // tabPgAddEmp
            // 
            this.tabPgAddEmp.Controls.Add(this.btnlogoff2);
            this.tabPgAddEmp.Controls.Add(this.pichome2);
            this.tabPgAddEmp.Controls.Add(this.llbhome2);
            this.tabPgAddEmp.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPgAddEmp.Location = new System.Drawing.Point(4, 24);
            this.tabPgAddEmp.Name = "tabPgAddEmp";
            this.tabPgAddEmp.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgAddEmp.Size = new System.Drawing.Size(963, 708);
            this.tabPgAddEmp.TabIndex = 1;
            this.tabPgAddEmp.Text = "Add Employee";
            this.tabPgAddEmp.UseVisualStyleBackColor = true;
            // 
            // tabPgdept
            // 
            this.tabPgdept.Controls.Add(this.btnhome3);
            this.tabPgdept.Controls.Add(this.pichome3);
            this.tabPgdept.Controls.Add(this.llbhome3);
            this.tabPgdept.Controls.Add(this.dataGridView1);
            this.tabPgdept.Controls.Add(this.textBox2);
            this.tabPgdept.Controls.Add(this.textBox1);
            this.tabPgdept.Controls.Add(this.lblDeptName);
            this.tabPgdept.Controls.Add(this.lblDeptId);
            this.tabPgdept.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPgdept.Location = new System.Drawing.Point(4, 24);
            this.tabPgdept.Name = "tabPgdept";
            this.tabPgdept.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgdept.Size = new System.Drawing.Size(963, 708);
            this.tabPgdept.TabIndex = 2;
            this.tabPgdept.Text = "Department";
            this.tabPgdept.UseVisualStyleBackColor = true;
            // 
            // tabPgSal
            // 
            this.tabPgSal.Controls.Add(this.btnhome4);
            this.tabPgSal.Controls.Add(this.pichome4);
            this.tabPgSal.Controls.Add(this.llbhome4);
            this.tabPgSal.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPgSal.Location = new System.Drawing.Point(4, 24);
            this.tabPgSal.Name = "tabPgSal";
            this.tabPgSal.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgSal.Size = new System.Drawing.Size(963, 708);
            this.tabPgSal.TabIndex = 3;
            this.tabPgSal.Text = "Salary Management";
            this.tabPgSal.UseVisualStyleBackColor = true;
            // 
            // lblEmpId
            // 
            this.lblEmpId.AutoSize = true;
            this.lblEmpId.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmpId.Location = new System.Drawing.Point(571, 62);
            this.lblEmpId.Name = "lblEmpId";
            this.lblEmpId.Size = new System.Drawing.Size(106, 19);
            this.lblEmpId.TabIndex = 0;
            this.lblEmpId.Text = "Employee ID :";
            // 
            // txtempid
            // 
            this.txtempid.Location = new System.Drawing.Point(683, 57);
            this.txtempid.Name = "txtempid";
            this.txtempid.Size = new System.Drawing.Size(216, 29);
            this.txtempid.TabIndex = 1;
            // 
            // btnSearch
            // 
            this.btnSearch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSearch.BackgroundImage")));
            this.btnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSearch.Location = new System.Drawing.Point(905, 55);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(34, 36);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // dgvEmpDetails
            // 
            this.dgvEmpDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmpDetails.Location = new System.Drawing.Point(8, 97);
            this.dgvEmpDetails.Name = "dgvEmpDetails";
            this.dgvEmpDetails.Size = new System.Drawing.Size(931, 560);
            this.dgvEmpDetails.TabIndex = 3;
            // 
            // llbhome1
            // 
            this.llbhome1.AutoSize = true;
            this.llbhome1.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Bold);
            this.llbhome1.Location = new System.Drawing.Point(883, 18);
            this.llbhome1.Name = "llbhome1";
            this.llbhome1.Size = new System.Drawing.Size(56, 20);
            this.llbhome1.TabIndex = 6;
            this.llbhome1.TabStop = true;
            this.llbhome1.Text = "Home";
            // 
            // pichome1
            // 
            this.pichome1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pichome1.BackgroundImage")));
            this.pichome1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pichome1.Location = new System.Drawing.Point(843, 16);
            this.pichome1.Name = "pichome1";
            this.pichome1.Size = new System.Drawing.Size(34, 35);
            this.pichome1.TabIndex = 7;
            this.pichome1.TabStop = false;
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(8, 52);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(212, 33);
            this.btnDisplay.TabIndex = 9;
            this.btnDisplay.Text = "Display Employee";
            this.btnDisplay.UseVisualStyleBackColor = true;
            // 
            // lblDeptId
            // 
            this.lblDeptId.AutoSize = true;
            this.lblDeptId.Location = new System.Drawing.Point(19, 57);
            this.lblDeptId.Name = "lblDeptId";
            this.lblDeptId.Size = new System.Drawing.Size(120, 19);
            this.lblDeptId.TabIndex = 0;
            this.lblDeptId.Text = "Department ID :";
            // 
            // lblDeptName
            // 
            this.lblDeptName.AutoSize = true;
            this.lblDeptName.Location = new System.Drawing.Point(19, 97);
            this.lblDeptName.Name = "lblDeptName";
            this.lblDeptName.Size = new System.Drawing.Size(142, 19);
            this.lblDeptName.TabIndex = 1;
            this.lblDeptName.Text = "Department Name :";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(183, 54);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(164, 26);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(183, 90);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(164, 26);
            this.textBox2.TabIndex = 3;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(8, 346);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(493, 150);
            this.dataGridView1.TabIndex = 4;
            // 
            // pichome2
            // 
            this.pichome2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pichome2.BackgroundImage")));
            this.pichome2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pichome2.Location = new System.Drawing.Point(853, 17);
            this.pichome2.Name = "pichome2";
            this.pichome2.Size = new System.Drawing.Size(35, 35);
            this.pichome2.TabIndex = 9;
            this.pichome2.TabStop = false;
            // 
            // llbhome2
            // 
            this.llbhome2.AutoSize = true;
            this.llbhome2.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbhome2.Location = new System.Drawing.Point(894, 17);
            this.llbhome2.Name = "llbhome2";
            this.llbhome2.Size = new System.Drawing.Size(53, 19);
            this.llbhome2.TabIndex = 8;
            this.llbhome2.TabStop = true;
            this.llbhome2.Text = "Home";
            // 
            // btnlogoff1
            // 
            this.btnlogoff1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnlogoff1.BackgroundImage")));
            this.btnlogoff1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnlogoff1.Location = new System.Drawing.Point(905, 663);
            this.btnlogoff1.Name = "btnlogoff1";
            this.btnlogoff1.Size = new System.Drawing.Size(34, 28);
            this.btnlogoff1.TabIndex = 10;
            this.btnlogoff1.UseVisualStyleBackColor = true;
            // 
            // btnlogoff2
            // 
            this.btnlogoff2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnlogoff2.BackgroundImage")));
            this.btnlogoff2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnlogoff2.Location = new System.Drawing.Point(912, 652);
            this.btnlogoff2.Name = "btnlogoff2";
            this.btnlogoff2.Size = new System.Drawing.Size(35, 32);
            this.btnlogoff2.TabIndex = 11;
            this.btnlogoff2.UseVisualStyleBackColor = true;
            // 
            // btnhome3
            // 
            this.btnhome3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnhome3.BackgroundImage")));
            this.btnhome3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnhome3.Location = new System.Drawing.Point(911, 654);
            this.btnhome3.Name = "btnhome3";
            this.btnhome3.Size = new System.Drawing.Size(35, 32);
            this.btnhome3.TabIndex = 14;
            this.btnhome3.UseVisualStyleBackColor = true;
            // 
            // pichome3
            // 
            this.pichome3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pichome3.BackgroundImage")));
            this.pichome3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pichome3.Location = new System.Drawing.Point(852, 19);
            this.pichome3.Name = "pichome3";
            this.pichome3.Size = new System.Drawing.Size(35, 35);
            this.pichome3.TabIndex = 13;
            this.pichome3.TabStop = false;
            // 
            // llbhome3
            // 
            this.llbhome3.AutoSize = true;
            this.llbhome3.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbhome3.Location = new System.Drawing.Point(893, 19);
            this.llbhome3.Name = "llbhome3";
            this.llbhome3.Size = new System.Drawing.Size(53, 19);
            this.llbhome3.TabIndex = 12;
            this.llbhome3.TabStop = true;
            this.llbhome3.Text = "Home";
            // 
            // btnhome4
            // 
            this.btnhome4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnhome4.BackgroundImage")));
            this.btnhome4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnhome4.Location = new System.Drawing.Point(910, 657);
            this.btnhome4.Name = "btnhome4";
            this.btnhome4.Size = new System.Drawing.Size(35, 33);
            this.btnhome4.TabIndex = 17;
            this.btnhome4.UseVisualStyleBackColor = true;
            // 
            // pichome4
            // 
            this.pichome4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pichome4.BackgroundImage")));
            this.pichome4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pichome4.Location = new System.Drawing.Point(851, 18);
            this.pichome4.Name = "pichome4";
            this.pichome4.Size = new System.Drawing.Size(35, 35);
            this.pichome4.TabIndex = 16;
            this.pichome4.TabStop = false;
            // 
            // llbhome4
            // 
            this.llbhome4.AutoSize = true;
            this.llbhome4.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbhome4.Location = new System.Drawing.Point(892, 18);
            this.llbhome4.Name = "llbhome4";
            this.llbhome4.Size = new System.Drawing.Size(53, 19);
            this.llbhome4.TabIndex = 15;
            this.llbhome4.TabStop = true;
            this.llbhome4.Text = "Home";
            // 
            // tabPgProj
            // 
            this.tabPgProj.Controls.Add(this.btnlogoff5);
            this.tabPgProj.Controls.Add(this.pichome5);
            this.tabPgProj.Controls.Add(this.llbhome5);
            this.tabPgProj.Location = new System.Drawing.Point(4, 24);
            this.tabPgProj.Name = "tabPgProj";
            this.tabPgProj.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgProj.Size = new System.Drawing.Size(963, 708);
            this.tabPgProj.TabIndex = 4;
            this.tabPgProj.Text = "Project Details";
            this.tabPgProj.UseVisualStyleBackColor = true;
            // 
            // tabPgTimeSheet
            // 
            this.tabPgTimeSheet.Location = new System.Drawing.Point(4, 24);
            this.tabPgTimeSheet.Name = "tabPgTimeSheet";
            this.tabPgTimeSheet.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgTimeSheet.Size = new System.Drawing.Size(963, 708);
            this.tabPgTimeSheet.TabIndex = 5;
            this.tabPgTimeSheet.Text = "Time Sheet Management";
            this.tabPgTimeSheet.UseVisualStyleBackColor = true;
            // 
            // btnlogoff5
            // 
            this.btnlogoff5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnlogoff5.BackgroundImage")));
            this.btnlogoff5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnlogoff5.Location = new System.Drawing.Point(917, 663);
            this.btnlogoff5.Name = "btnlogoff5";
            this.btnlogoff5.Size = new System.Drawing.Size(35, 33);
            this.btnlogoff5.TabIndex = 20;
            this.btnlogoff5.UseVisualStyleBackColor = true;
            // 
            // pichome5
            // 
            this.pichome5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pichome5.BackgroundImage")));
            this.pichome5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pichome5.Location = new System.Drawing.Point(858, 24);
            this.pichome5.Name = "pichome5";
            this.pichome5.Size = new System.Drawing.Size(35, 35);
            this.pichome5.TabIndex = 19;
            this.pichome5.TabStop = false;
            // 
            // llbhome5
            // 
            this.llbhome5.AutoSize = true;
            this.llbhome5.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbhome5.Location = new System.Drawing.Point(899, 24);
            this.llbhome5.Name = "llbhome5";
            this.llbhome5.Size = new System.Drawing.Size(53, 19);
            this.llbhome5.TabIndex = 18;
            this.llbhome5.TabStop = true;
            this.llbhome5.Text = "Home";
            // 
            // AdminActivityForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(994, 748);
            this.Controls.Add(this.tabControl1);
            this.Name = "AdminActivityForm";
            this.Text = "AdminActivityForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tabControl1.ResumeLayout(false);
            this.tabPgViewEmp.ResumeLayout(false);
            this.tabPgViewEmp.PerformLayout();
            this.tabPgAddEmp.ResumeLayout(false);
            this.tabPgAddEmp.PerformLayout();
            this.tabPgdept.ResumeLayout(false);
            this.tabPgdept.PerformLayout();
            this.tabPgSal.ResumeLayout(false);
            this.tabPgSal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pichome1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pichome2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pichome3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pichome4)).EndInit();
            this.tabPgProj.ResumeLayout(false);
            this.tabPgProj.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pichome5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPgViewEmp;
        private System.Windows.Forms.TabPage tabPgAddEmp;
        private System.Windows.Forms.TabPage tabPgdept;
        private System.Windows.Forms.TabPage tabPgSal;
        private System.Windows.Forms.LinkLabel llbhome1;
        private System.Windows.Forms.DataGridView dgvEmpDetails;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtempid;
        private System.Windows.Forms.Label lblEmpId;
        private System.Windows.Forms.PictureBox pichome1;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.PictureBox pichome2;
        private System.Windows.Forms.LinkLabel llbhome2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblDeptName;
        private System.Windows.Forms.Label lblDeptId;
        private System.Windows.Forms.Button btnlogoff1;
        private System.Windows.Forms.Button btnlogoff2;
        private System.Windows.Forms.Button btnhome3;
        private System.Windows.Forms.PictureBox pichome3;
        private System.Windows.Forms.LinkLabel llbhome3;
        private System.Windows.Forms.Button btnhome4;
        private System.Windows.Forms.PictureBox pichome4;
        private System.Windows.Forms.LinkLabel llbhome4;
        private System.Windows.Forms.TabPage tabPgProj;
        private System.Windows.Forms.Button btnlogoff5;
        private System.Windows.Forms.PictureBox pichome5;
        private System.Windows.Forms.LinkLabel llbhome5;
        private System.Windows.Forms.TabPage tabPgTimeSheet;




    }
}