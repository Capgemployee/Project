﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpMngSys
{
    public partial class WelcomePage : Form
    {
        public WelcomePage()
        {
            InitializeComponent();
        }

        private void btnAdmLgn_Click(object sender, EventArgs e)
        {
            this.Hide();
            var AdmLogPg = new AdminLogin();
            AdmLogPg.Show();
        }

        private void btnEmpLgn_Click(object sender, EventArgs e)
        {
            this.Hide();
            var EmpLogPg = new EmployeeLogin();
            EmpLogPg.Show();
        }
    }
}
