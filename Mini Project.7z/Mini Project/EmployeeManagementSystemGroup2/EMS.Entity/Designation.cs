﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    /// <summary>
    /// Author : 
    /// Modification Date :
    /// Change Description : 
    /// </summary>
    public class Designation
    {
        #region Properties

            //To get or set Designation code
            public string DesignationID { get; set; }

            //To get or set Designation Name
            public string DesignationName { get; set; }

        #endregion
    }
}
