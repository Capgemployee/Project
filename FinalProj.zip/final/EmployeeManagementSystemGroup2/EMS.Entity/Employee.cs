﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    /// <summary>
    /// Author : 
    /// Modification Date :
    /// Change Description :
    /// </summary>
    public class Employee
    {
        #region Properties

            //Get or Set Employee ID
            public int EmployeeID { get; set; }

            //Get or Set Employee First Name
            public string FirstName { get; set; }

            //Get or Set Employee Last Name
            public string LastName { get; set; }

            //Get or Set Employee Date of birth
            public DateTime DOB { get; set; }

            //Get or Set Employee Date of Joining
            public DateTime DOJ { get; set; }

            //Get or Set Employee Gender
            public string Gender { get; set; }

            //Get or Set Employee Address
            public string Address { get; set; }

            //Get or Set Employee Marital status
            public string MaritalStatus { get; set; }

            //Get or Set Employee salary
            public int Salary { get; set; }

            //To Get or Set Employee phone number
            public long PhoneNo { get; set; }

            //Get or Set Manager ID
            public int ManagerID { get; set; }

            //Get or Set Employee Department ID
            public int DepartmentID { get; set; }

            //Get or Set Employee Designation Code
            public string DesignationID { get; set; }

            //Get or Set Employee Grade code
            public string GradeCode { get; set; }

        #endregion

    }
}
