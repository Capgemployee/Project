﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.Entity;
using EMS.Exception;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;


namespace EMS.DAL
{
    public class EmployeeOperations
    {
        SqlConnection connection;
        SqlDataReader reader;
        SqlCommand cmd = new SqlCommand();


        public EmployeeOperations()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["EMS"].ConnectionString;
            connection = new SqlConnection(connectionString);

        }

       // Admin's Add method
        public bool AddEmployee(Employee emp)
        {
            try
            {
                bool empAdded = false;
                cmd= new SqlCommand("AddEmployee", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmpID", emp.EmployeeID);
                cmd.Parameters.AddWithValue("@FirstName", emp.FirstName);
                cmd.Parameters.AddWithValue("@LastName", emp.LastName);
                cmd.Parameters.AddWithValue("@DateOfBirth", emp.DOB);
                cmd.Parameters.AddWithValue("@DateOfjoining", emp.DOJ);
                cmd.Parameters.AddWithValue("@Gender", emp.Gender);
                cmd.Parameters.AddWithValue("@Address", emp.Address);
                cmd.Parameters.AddWithValue("@MaritalStatus", emp.MaritalStatus);
                cmd.Parameters.AddWithValue("@Salary", emp.Salary);
                cmd.Parameters.AddWithValue("@PhoneNumber", emp.PhoneNo);
                cmd.Parameters.AddWithValue("@DesigCode", emp.DesignationID);
                cmd.Parameters.AddWithValue("@DeptCode", emp.DepartmentID);
                cmd.Parameters.AddWithValue("@MgrCode", emp.ManagerID);
                cmd.Parameters.AddWithValue("@GradeCode", emp.GradeCode);
                connection.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                    empAdded = true;
                return empAdded;
            }
            catch (EmployeeException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        //Admin's display method
        public DataTable DislpayEmployee()
        {
            DataTable table = new DataTable();
            try
            {
                cmd = new SqlCommand("DisplayEmployee", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                connection.Open();
                reader = cmd.ExecuteReader();
                table.Load(reader);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return table;
        }
        
        //Admin's Search Method
        public DataTable SearchEmployee(int ID)
        {
            DataTable table = new DataTable();
            try
            {
                cmd = new SqlCommand("SearchEmployee", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmpID", ID);
                connection.Open();
                reader = cmd.ExecuteReader();
                table.Load(reader);
            }
            catch (EmployeeException)
            {
                throw new EmployeeException("Employee ID does Not Exist");
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return table;
        }

        //Admin's Delete method
        public bool DeleteEmployee(int empID)
        {
            bool empDeleted = false;
            try
            {
                cmd = new SqlCommand("DeleteEmployee", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmpID", empID);
                connection.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    empDeleted = true;
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            finally
            {
                connection.Close();
            }
            return empDeleted;

        }
        //Admin's Update method
        public bool UpdateEmployee(Employee emp)
        {
            bool empUpdated = false;
            try
            {
                cmd = new SqlCommand("UpdateEmployee", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmpID", emp.EmployeeID);
                cmd.Parameters.AddWithValue("@FirstName", emp.FirstName);
                cmd.Parameters.AddWithValue("@LastName", emp.LastName);
                cmd.Parameters.AddWithValue("@DateOfBirth", emp.DOB);
                cmd.Parameters.AddWithValue("@DateOfjoining", emp.DOJ);
                cmd.Parameters.AddWithValue("@Gender", emp.Gender);
                cmd.Parameters.AddWithValue("@Address", emp.Address);
                cmd.Parameters.AddWithValue("@MaritalStatus", emp.MaritalStatus);
                cmd.Parameters.AddWithValue("@Salary", emp.Salary);
                cmd.Parameters.AddWithValue("@PhoneNumber", emp.PhoneNo);
                cmd.Parameters.AddWithValue("@DesigCode", emp.DesignationID);
                cmd.Parameters.AddWithValue("@DeptCode", emp.DepartmentID);
                cmd.Parameters.AddWithValue("@MgrCode", emp.ManagerID);
                cmd.Parameters.AddWithValue("@GradeCode", emp.GradeCode);
                connection.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    empUpdated = true;
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return empUpdated;
        }

        //ADMIN'S DEPARTMENT METHODS

        //1. Add method for Department
         public bool AddDepartment(Department dept)
        {
            try
            {
                bool deptAdded = false;
                cmd= new SqlCommand("AddDepartment", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@DeptID", dept.DepartmentID);
                cmd.Parameters.AddWithValue("@DeptName", dept.DepartmentName);
                connection.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                    deptAdded = true;
                return deptAdded;
            }
            catch (EmployeeException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        //2. Display method for Department
         public DataTable DislpayDepartment()
         {
             DataTable table = new DataTable();
             try
             {
                 cmd = new SqlCommand("DisplayDepartment", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 connection.Open();
                 reader = cmd.ExecuteReader();
                 table.Load(reader);
             }
             catch (EmployeeException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {

                 throw ex;
             }
             finally
             {
                 connection.Close();
             }
             return table;
         }
        
        //3. Update method for Department
         public bool DeleteDepartment(int empID)
         {
             bool deptDeleted = false;
             try
             {
                 cmd = new SqlCommand("DeleteDepartment", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@EmpID", empID);
                 connection.Open();
                 int result = cmd.ExecuteNonQuery();
                 if (result > 0)
                 {
                     deptDeleted = true;
                 }
             }
             catch (EmployeeException ex)
             {

                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }

             finally
             {
                 connection.Close();
             }
             return deptDeleted;

         }

        //ADMIN'S PROJECT METHODS

        //1.Add method for Project
         public bool AddProjectDetails(Project proj)
         {
             try
             {
                 bool projAdded = false;
                 cmd = new SqlCommand("AddProjectDetails", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@ProjectID", proj.ProjectID);
                 cmd.Parameters.AddWithValue("@ProjectName", proj.ProjectName);
                 cmd.Parameters.AddWithValue("@ClientCode", proj.ClientID);
                 cmd.Parameters.AddWithValue("@MgrCode", proj.ManagerID);
                 cmd.Parameters.AddWithValue("@Description", proj.Description);
                 connection.Open();
                 int result = cmd.ExecuteNonQuery();
                 if (result > 0)
                     projAdded = true;
                 return projAdded;
             }
             catch (EmployeeException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (SystemException)
             {
                 throw;
             }
             finally
             {
                 connection.Close();
             }
         }

        //2.Display method for Project
         public DataTable DislpayProjectDetails()
         {
             DataTable table = new DataTable();
             try
             {
                 cmd = new SqlCommand("DisplayProjectDetails", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 connection.Open();
                 reader = cmd.ExecuteReader();
                 table.Load(reader);
             }
             catch (EmployeeException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {

                 throw ex;
             }
             finally
             {
                 connection.Close();
             }
             return table;
         }
        
        //ADMIN'S TIMESHEET METHODS
         public DataTable DislpayTimesheetDetails()
         {
             DataTable table = new DataTable();
             try
             {
                 cmd = new SqlCommand("DisplayTimesheetDetails", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 connection.Open();
                 reader = cmd.ExecuteReader();
                 table.Load(reader);
             }
             catch (EmployeeException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {

                 throw ex;
             }
             finally
             {
                 connection.Close();
             }
             return table;
         }
        
        //Employee Methods
        //1.Update method for Employee
         public bool UpdateEmployeeDetails(Employee emp)
         {
             bool empDetailsUpdated = false;
             try
             {
                 cmd = new SqlCommand("UpdateEmployee", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@FirstName", emp.FirstName);
                 cmd.Parameters.AddWithValue("@LastName", emp.LastName);
                 cmd.Parameters.AddWithValue("@Address", emp.Address);
                 cmd.Parameters.AddWithValue("@MaritalStatus", emp.MaritalStatus);
                 cmd.Parameters.AddWithValue("@PhoneNumber", emp.PhoneNo);
                 connection.Open();
                 int result = cmd.ExecuteNonQuery();
                 if (result > 0)
                 {
                     empDetailsUpdated = true;
                 }
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (EmployeeException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {

                 throw ex;
             }
             finally
             {
                 connection.Close();
             }
             return empDetailsUpdated;
         }

        //search method for Employee
         public DataTable SearchEmployeeDetails(int ID)
         {
             DataTable table = new DataTable();
             try
             {
                 cmd = new SqlCommand("SearchEmployee", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@EmpID", ID);
                 connection.Open();
                 reader = cmd.ExecuteReader();
                 table.Load(reader);
             }
             catch (EmployeeException)
             {
                 throw new EmployeeException("Employee ID does Not Exist");
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {

                 throw ex;
             }
             finally
             {
                 connection.Close();
             }
             return table;
         }

    }
}
