﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.Exception;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using EMS.Entity;


namespace EMS.DAL
{
    public class EmployeeOperations
    {
        SqlConnection connection;
        SqlDataReader reader;
        SqlCommand cmd = new SqlCommand();


        public EmployeeOperations()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["EMS"].ConnectionString;
            connection = new SqlConnection(connectionString);

        }

       // ADMIN METHODS
       // Admin method: to perform employee functionalities
        // 1.method to add employee
        #region Admin
        public bool AddEmployee(Employee emp)
        {
            try
            {
                bool empAdded = false;
                cmd = new SqlCommand("Admin_AddEmployee", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Parameters.AddWithValue("@EmpID", emp.EmployeeID);
                cmd.Parameters.AddWithValue("@FirstName", emp.FirstName);
                cmd.Parameters.AddWithValue("@LastName", emp.LastName);
                cmd.Parameters.AddWithValue("@DateOfBirth", emp.DOB);
                cmd.Parameters.AddWithValue("@DateOfjoining", emp.DOJ);
                cmd.Parameters.AddWithValue("@Gender", emp.Gender);
                cmd.Parameters.AddWithValue("@Address", emp.Address);
                cmd.Parameters.AddWithValue("@MaritalStatus", emp.MaritalStatus);
                cmd.Parameters.AddWithValue("@Salary", emp.Salary);
                cmd.Parameters.AddWithValue("@PhoneNumber", emp.PhoneNo);
                cmd.Parameters.AddWithValue("@DesigCode", emp.DesignationID);
                cmd.Parameters.AddWithValue("@DeptID", emp.DepartmentID);
                cmd.Parameters.AddWithValue("@MgrID", emp.ManagerID);
                cmd.Parameters.AddWithValue("@GradeCode", emp.GradeCode);
                connection.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                    empAdded = true;
                return empAdded;
            }
            catch (EmployeeException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        //2.method to display employee
        public DataTable DisplayEmployee()
        {
            DataTable table = new DataTable();
            try
            {
                cmd = new SqlCommand("Admin_DisplayEmployee", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                connection.Open();
                reader = cmd.ExecuteReader();
                table.Load(reader);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return table;
        }
        
        //3. method to search employee
        public DataTable SearchEmployee(int ID)
        {
            DataTable table = new DataTable();
            try
            {
                cmd = new SqlCommand("Admin_SearchEmployee", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmpID", ID);
                connection.Open();
                reader = cmd.ExecuteReader();
                table.Load(reader);
            }
            catch (EmployeeException)
            {
                throw new EmployeeException("Employee ID does Not Exist");
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return table;
        }

        //4.method to delete employee
        public bool DeleteEmployee(int empID)
        {
            bool empDeleted = false;
            try
            {
                cmd = new SqlCommand("Admin_DeleteEmployee", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmpID", empID);
                connection.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    empDeleted = true;
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            finally
            {
                connection.Close();
            }
            return empDeleted;

        }
        //5.method to update employee
        public bool UpdateEmployee(Employee emp)
        {
            bool empUpdated = false;
            try
            {
                cmd = new SqlCommand("Admin_UpdateEmployee", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmpID", emp.EmployeeID);
                cmd.Parameters.AddWithValue("@FirstName", emp.FirstName);
                cmd.Parameters.AddWithValue("@LastName", emp.LastName);
                cmd.Parameters.AddWithValue("@DateOfBirth", emp.DOB);
                cmd.Parameters.AddWithValue("@DateOfjoining", emp.DOJ);
                cmd.Parameters.AddWithValue("@Gender", emp.Gender);
                cmd.Parameters.AddWithValue("@Address", emp.Address);
                cmd.Parameters.AddWithValue("@MaritalStatus", emp.MaritalStatus);
                cmd.Parameters.AddWithValue("@Salary", emp.Salary);
                cmd.Parameters.AddWithValue("@PhoneNumber", emp.PhoneNo);
                cmd.Parameters.AddWithValue("@DesigCode", emp.DesignationID);
                cmd.Parameters.AddWithValue("@DeptID", emp.DepartmentID);
                cmd.Parameters.AddWithValue("@MgrID", emp.ManagerID);
                cmd.Parameters.AddWithValue("@GradeCode", emp.GradeCode);
                connection.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    empUpdated = true;
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return empUpdated;
        }

        ////6. View Details of Employee
        public DataTable GetEmployeeDetails(int ID)
        {
            DataTable table = new DataTable();
            try
            {
                cmd = new SqlCommand("Admin_SearchEmployee", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmpID", ID);
                connection.Open();
                reader = cmd.ExecuteReader();
                table.Load(reader);
            }
            catch (EmployeeException)
            {
                throw new EmployeeException("Employee ID does Not Exist");
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return table;
        }

        //ADMIN'S DEPARTMENT METHODS

        //1. Add method for Department
         public bool AddDepartment(Department dept)
        {
            try
            {
               
                bool deptAdded = false;
                cmd = new SqlCommand("Admin_AddDepartment1", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@DeptID", dept.DepartmentID);
                cmd.Parameters.AddWithValue("@DeptName", dept.DepartmentName);
                connection.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                    deptAdded = true;
                return deptAdded;
            }
            catch (EmployeeException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        //2. Display method for Department
         public DataTable DislpayDepartment()
         {
             DataTable table = new DataTable();
             try
             {
                 cmd = new SqlCommand("Admin_ViewAllDepartment", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 connection.Open();
                 reader = cmd.ExecuteReader();
                 table.Load(reader);
             }
             catch (EmployeeException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {

                 throw ex;
             }
             finally
             {
                 connection.Close();
             }
             return table;
         }
        
        //3. Delete method for Department
         public bool DeleteDepartment(int deptID)
         {
             bool deptDeleted = false;
             try
             {
                 cmd = new SqlCommand("Admin_DeleteDepartment", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@DeptID", deptID);
                 connection.Open();
                 int result = cmd.ExecuteNonQuery();
                 if (result > 0)
                 {
                     deptDeleted = true;
                 }
             }
             catch (EmployeeException ex)
             {

                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }

             finally
             {
                 connection.Close();
             }
             return deptDeleted;

         }

        //ADMIN'S PROJECT METHODS

        //1.Add method for Project
         public bool AddProjectDetails(Project proj)
         {
             try
             {
                 bool projAdded = false;
                 cmd = new SqlCommand("Admin_AddProject", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@ProjectID", proj.ProjectID);
                 cmd.Parameters.AddWithValue("@ProjectName", proj.ProjectName);
                 cmd.Parameters.AddWithValue("@ClientCode", proj.ClientID);
                 cmd.Parameters.AddWithValue("@MgrID", proj.ManagerID);
                
                 connection.Open();
                 int result = cmd.ExecuteNonQuery();
                 if (result > 0)
                     projAdded = true;
                 return projAdded;
             }
             catch (EmployeeException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (SystemException)
             {
                 throw;
             }
             finally
             {
                 connection.Close();
             }
         }

        //2.Display method for Project
         public DataTable DislpayProjectDetails()
         {
             DataTable table = new DataTable();
             try
             {
                 cmd = new SqlCommand("Admin_DisplayProject", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 connection.Open();
                 reader = cmd.ExecuteReader();
                 table.Load(reader);
             }
             catch (EmployeeException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {

                 throw ex;
             }
             finally
             {
                 connection.Close();
             }
             return table;
         }

        //3.Assignment of Project

         public bool AssignProject(EmployeeProject empProj)
         {
             try
             {
                 bool projAssigned = false;
                 cmd = new SqlCommand("Admin_AssignProject", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@ProjectID", empProj.ProjectID);
                 cmd.Parameters.AddWithValue("@EmpID", empProj.EmployeeID);
                

                 connection.Open();
                 int result = cmd.ExecuteNonQuery();
                 if (result > 0)
                     projAssigned = true;
                 return projAssigned;
             }
             catch (EmployeeException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (SystemException)
             {
                 throw;
             }
             finally
             {
                 connection.Close();
             }
         }
         //ADMIN'S TIMESHEET METHODS

         //1.Assigment of shift

         public bool AssignShift(EmployeeShiftdetails empShift)
         {
             try
             {
                 bool shiftAssigned = false;
                 cmd = new SqlCommand("AssignShiftDetails", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@EmpID", empShift.EmployeeID);
                 cmd.Parameters.AddWithValue("@ShiftID", empShift.ShiftID);


                 connection.Open();
                 int result = cmd.ExecuteNonQuery();
                 if (result > 0)
                     shiftAssigned = true;
                 return shiftAssigned;
             }
             catch (EmployeeException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (SystemException)
             {
                 throw;
             }
             finally
             {
                 connection.Close();
             }



         }
         //2.Update shift

         public bool UpdateShift(EmployeeShiftdetails empShift)
         {
             bool shiftUpdated = false;
             try
             {
                 cmd = new SqlCommand("UpdateShiftDetails", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@ShiftID", empShift.ShiftID);
                 cmd.Parameters.AddWithValue("@EmpID", empShift.EmployeeID);
                 connection.Open();
                 int result = cmd.ExecuteNonQuery();
                 if (result > 0)
                 {
                     shiftUpdated = true;
                 }
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (EmployeeException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {

                 throw ex;
             }
             finally
             {
                 connection.Close();
             }
             return shiftUpdated;
         }

         //3. Display shift details
         public DataTable DislpayTimesheetDetails()
         {
             DataTable table = new DataTable();
             try
             {
                 cmd = new SqlCommand("RetrieveShiftDetails", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 connection.Open();
                 reader = cmd.ExecuteReader();
                 table.Load(reader);
             }
             catch (EmployeeException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {

                 throw ex;
             }
             finally
             {
                 connection.Close();
             }
             return table;
         }

         //4. SEARCH SHIFT 

         public DataTable SearchEmpShift(int ID)
         {
             DataTable table = new DataTable();
             try
             {
                 cmd = new SqlCommand("RetrieveEmpShftInfo", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@EmpID", ID);
                 connection.Open();
                 reader = cmd.ExecuteReader();
                 table.Load(reader);
             }
             catch (EmployeeException)
             {
                 throw new EmployeeException("Employee ID does Not Exist");
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {

                 throw ex;
             }
             finally
             {
                 connection.Close();
             }
             return table;
         }

        //Login Details
        //5.Username and Password
         public bool CreateUsernamePassword(UserMaster user)
         {
             try
             {
                 bool userAdded = false;
                 cmd = new SqlCommand("Admin_CreateUser", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@EmpID", user.EmployeeID);
                 cmd.Parameters.AddWithValue("@Username", user.Username);
                 cmd.Parameters.AddWithValue("@Password", user.Password);

                 connection.Open();
                 int result = cmd.ExecuteNonQuery();
                 if (result > 0)
                     userAdded = true;
                 return userAdded;
             }
             catch (EmployeeException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (SystemException)
             {
                 throw;
             }
             finally
             {
                 connection.Close();
             }
         }
        #endregion

         //Employee Methods
         //1.Update method for Employee
         #region Employee
         public bool UpdateEmployeeDetails(Employee emp)
         {
             bool empDetailsUpdated = false;
             try
             {
                 cmd = new SqlCommand("Employee_UpdateEmployee", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@FirstName", emp.FirstName);
                 cmd.Parameters.AddWithValue("@LastName", emp.LastName);
                 cmd.Parameters.AddWithValue("@Address", emp.Address);
                 cmd.Parameters.AddWithValue("@MaritalStatus", emp.MaritalStatus);
                 cmd.Parameters.AddWithValue("@PhoneNumber", emp.PhoneNo);
                 connection.Open();
                 int result = cmd.ExecuteNonQuery();
                 if (result > 0)
                 {
                     empDetailsUpdated = true;
                 }
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (EmployeeException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {

                 throw ex;
             }
             finally
             {
                 connection.Close();
             }
             return empDetailsUpdated;
         }

        //2. method to search his profile
        //Not written









        //Employee's Timesheet display method
         public DataTable ViewEmpShift(int ID)
         {
             DataTable table = new DataTable();
             try
             {
                 cmd = new SqlCommand("RetrieveEmpShftInfo", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@EmpID", ID);
                 connection.Open();
                 reader = cmd.ExecuteReader();
                 table.Load(reader);
             }
             catch (EmployeeException)
             {
                 throw new EmployeeException("Employee ID does Not Exist");
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {

                 throw ex;
             }
             finally
             {
                 connection.Close();
             }
             return table;
         }

        //Employee method to View Project Details

         public DataTable SearchProjDetails(string projID)
         {
             DataTable table = new DataTable();
             try
             {
                 cmd = new SqlCommand("Employee_DisplayProject", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@ProjectID", projID);
                 connection.Open();
                 reader = cmd.ExecuteReader();
                 table.Load(reader);
             }
             catch (EmployeeException)
             {
                 throw new EmployeeException("Project ID  does Not Exist");
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {

                 throw ex;
             }
             finally
             {
                 connection.Close();
             }
             return table;
         }

         // method to search any employee
         public DataTable SearchEmployeeDetails(int ID)
         {
             DataTable table = new DataTable();
             try
             {
                 cmd = new SqlCommand("Employee_SearchEmployee", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@EmpID", ID);
                 connection.Open();
                 reader = cmd.ExecuteReader();
                 table.Load(reader);
             }
             catch (EmployeeException)
             {
                 throw new EmployeeException("Employee ID does Not Exist");
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {

                 throw ex;
             }
             finally
             {
                 connection.Close();
             }
             return table;
         }

        //Login for Employee Details
         public bool LoginEmployee(UserMaster user)
         {
             try
             {
                 bool empverified = false;
                 SqlCommand cmd = new SqlCommand("Admin_CreateUser", connection);
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@UserName", user.Username);
                 cmd.Parameters.AddWithValue("@Password", user.Password);
                 connection.Open();
                 SqlDataReader reader = cmd.ExecuteReader();
                 reader.Read();

                 if (reader.HasRows)
                     empverified = true;
                 return empverified;
             }
             catch (EmployeeException)
             {
                 throw new EmployeeException("Invalid Data");
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {

                 throw ex;
             }
             finally
             {
                 connection.Close();
             }

         }
    }
}
#endregion