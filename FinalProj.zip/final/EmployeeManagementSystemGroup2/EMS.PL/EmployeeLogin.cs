﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{
    public partial class EmployeeLogin : Form
    {
        public EmployeeLogin()
        {
            InitializeComponent();
        }

        private void btnEmpLogin_Click(object sender, EventArgs e)
        {
            EmployeeValidation Validateemp = new EmployeeValidation();
            try 
            {
                UserMaster user = new UserMaster();
                user.Username = txtUsrNameEmp.Text;
                user.Password = txtPwdEmp.Text;

                bool empverified = Validateemp.LoginEmployee(user);
                if (user.Username == null || user.Password == string.Empty)
                {
                    throw new EmployeeException("User Name/ Password is invalid");
                }
                else
                {
                    this.Hide();
                    var empfrom = new EmployeeActivityForm();
                    empfrom.Show();
                }
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void EmployeeLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
