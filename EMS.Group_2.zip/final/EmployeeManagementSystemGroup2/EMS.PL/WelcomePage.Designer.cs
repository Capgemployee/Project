﻿namespace EMS.PL
{
    partial class WelcomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WelcomePage));
            this.btnAdmLgn = new System.Windows.Forms.Button();
            this.btnEmpLgn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAdmLgn
            // 
            this.btnAdmLgn.AutoSize = true;
            this.btnAdmLgn.BackColor = System.Drawing.Color.AliceBlue;
            this.btnAdmLgn.FlatAppearance.BorderColor = System.Drawing.Color.AliceBlue;
            this.btnAdmLgn.FlatAppearance.BorderSize = 0;
            this.btnAdmLgn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdmLgn.ForeColor = System.Drawing.Color.Black;
            this.btnAdmLgn.Image = ((System.Drawing.Image)(resources.GetObject("btnAdmLgn.Image")));
            this.btnAdmLgn.Location = new System.Drawing.Point(759, 150);
            this.btnAdmLgn.Name = "btnAdmLgn";
            this.btnAdmLgn.Size = new System.Drawing.Size(127, 137);
            this.btnAdmLgn.TabIndex = 3;
            this.btnAdmLgn.Text = "ADMIN ";
            this.btnAdmLgn.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnAdmLgn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAdmLgn.UseVisualStyleBackColor = false;
            this.btnAdmLgn.Click += new System.EventHandler(this.btnAdmLgn_Click);
            // 
            // btnEmpLgn
            // 
            this.btnEmpLgn.AutoSize = true;
            this.btnEmpLgn.BackColor = System.Drawing.Color.AliceBlue;
            this.btnEmpLgn.FlatAppearance.BorderColor = System.Drawing.Color.AliceBlue;
            this.btnEmpLgn.FlatAppearance.BorderSize = 0;
            this.btnEmpLgn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmpLgn.ForeColor = System.Drawing.Color.Black;
            this.btnEmpLgn.Image = ((System.Drawing.Image)(resources.GetObject("btnEmpLgn.Image")));
            this.btnEmpLgn.Location = new System.Drawing.Point(759, 334);
            this.btnEmpLgn.Name = "btnEmpLgn";
            this.btnEmpLgn.Size = new System.Drawing.Size(125, 137);
            this.btnEmpLgn.TabIndex = 5;
            this.btnEmpLgn.Text = "Employee";
            this.btnEmpLgn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEmpLgn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnEmpLgn.UseVisualStyleBackColor = false;
            this.btnEmpLgn.Click += new System.EventHandler(this.btnEmpLgn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(152)))), ((int)(((byte)(24)))));
            this.label1.Location = new System.Drawing.Point(756, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 26);
            this.label1.TabIndex = 6;
            this.label1.Text = "Login Here";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(56, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(634, 316);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Matura MT Script Capitals", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(152)))), ((int)(((byte)(24)))));
            this.label2.Location = new System.Drawing.Point(28, 264);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(725, 64);
            this.label2.TabIndex = 8;
            this.label2.Text = "Employee Management System";
            // 
            // WelcomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(987, 641);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnEmpLgn);
            this.Controls.Add(this.btnAdmLgn);
            this.Name = "WelcomePage";
            this.Text = "Welcome";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.WelcomePage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAdmLgn;
        private System.Windows.Forms.Button btnEmpLgn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
    }
}

