﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;


namespace EMS.PL
{
    public partial class EmployeeActivityForm : Form
    {
        EmployeeValidation validateEmp = new EmployeeValidation();
        public EmployeeActivityForm()
        {
            InitializeComponent();
        }

        private void EmployeeActivityForm_Load(object sender, EventArgs e)
        {
            tabControl1.Height = this.Height;
            tabControl1.Width = this.Width;

            cmbMStuts.Items.Add("Male");
            cmbMStuts.Items.Add("Female");
        }

        private void llbEmpHome4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            WelcomePage welpg = new WelcomePage();
            welpg.Show();
        }

        private void llbEmpHome3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            WelcomePage welpg = new WelcomePage();
            welpg.Show();
        }

        private void llbEmpHome2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            WelcomePage welpg = new WelcomePage();
            welpg.Show();
        }

        private void llbhome1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            WelcomePage welpg = new WelcomePage();
            welpg.Show();
        }

        private void btnlogoff1_Click(object sender, EventArgs e)
        {
            this.Hide();
            EmployeeLogin emplgin = new EmployeeLogin();
            emplgin.Show();
        }

        private void btnLogOff2_Click(object sender, EventArgs e)
        {
            this.Hide();
            EmployeeLogin emplgin = new EmployeeLogin();
            emplgin.Show();
        }

        private void btnLogOff3_Click(object sender, EventArgs e)
        {
            this.Hide();
            EmployeeLogin emplgin = new EmployeeLogin();
            emplgin.Show();
        }

        private void btnLogOff4_Click(object sender, EventArgs e)
        {
            this.Hide();
            EmployeeLogin emplgin = new EmployeeLogin();
            emplgin.Show();
        }

        //-----------------------------Project Details------------------------------------
        //View Project details
        private void btnViewProj_Click(object sender, EventArgs e)
        {

            DataTable projTable = new DataTable();
            string projID = txtProjId.Text;
            projTable = validateEmp.SearchProjDetails(projID);
            dgvProject.DataSource = projTable;

        }
        //------------------------------Employee Profile----------------------------------
        //View Profile
        private void btnView_Click_1(object sender, EventArgs e)
        {
            DataTable tbemp = new DataTable();
            int id = Convert.ToInt32(textEmpID.Text);
            tbemp = validateEmp.viewEmpProfile(id);
            dgvViewDetails.DataSource = tbemp;
        }


        //Update Employee Details
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Employee emp = new Employee();
                bool isNumber;
                long contactNo;

                emp.EmployeeID = Convert.ToInt32(txtViewEmpId.Text);
                emp.FirstName = txtFrstnme.Text;
                emp.LastName = txtLstnme.Text;
                emp.DOB = Convert.ToDateTime(txtDateOB.Text);
                emp.Address = txtaddrss.Text;
                emp.MaritalStatus = cmbMStuts.Text;

                isNumber = long.TryParse(txtphnnumbr.Text, out contactNo);
                if (isNumber)
                    emp.PhoneNo = contactNo;
                else
                {
                    MessageBox.Show("Please enter only numbers in Conatct No field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }


                bool empUpdated = validateEmp.UpdateEmployee(emp);
                if (empUpdated)
                {
                    MessageBox.Show("Employee Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtFrstnme.Clear();
                    txtLstnme.Clear();
                    txtDateOB.Clear();
                    txtaddrss.Clear();

                }
                else
                    MessageBox.Show("Failed to Update Employee record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //----------------------------TimeSheet Management------------------------------------
        //View Tym Shift Details
        private void btnViewTymSheet_Click(object sender, EventArgs e)
        {
            DataTable tbemp = new DataTable();
            int id = Convert.ToInt32(txtEmpTym.Text);
            tbemp = validateEmp.ViewEmpShift(id);

            txtShftID.Text = tbemp.Rows[0]["ShiftID"].ToString();
        }

        //-------------------------------Search Employee------------------------------------
        //View Details of Other Employee
        private void btnViewEmp_Click(object sender, EventArgs e)
        {
            DataTable tbemp = new DataTable();
            int id = Convert.ToInt32(txtEID.Text);
            tbemp = validateEmp.SearchEmployeeDetails(id);

            txtEmpName.Text = tbemp.Rows[0]["FirstName"].ToString();
            textDesig.Text = tbemp.Rows[0]["DesigCode"].ToString();
            textDept.Text = tbemp.Rows[0]["DeptID"].ToString();
            
        }




    }
}
