﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EMS.Exception
{
    public class EmployeeException : ApplicationException
    {
        #region Constructors

            public EmployeeException()
                : base()
            { }

            public EmployeeException(string message)
                : base(message)
            { }

        #endregion
    }
}
