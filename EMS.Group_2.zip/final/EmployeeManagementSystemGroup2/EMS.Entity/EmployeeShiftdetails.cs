﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    /// <summary>
    /// Author : 
    /// Modification Date :
    /// Change Description :
    /// </summary>
    public class EmployeeShiftdetails
    {
        #region Properties

            //Get or Set Employee ID
            public int EmployeeID { get; set; }

            //Get or Set Shift Details
            public string ShiftID { get; set; }

        #endregion
    }
}
