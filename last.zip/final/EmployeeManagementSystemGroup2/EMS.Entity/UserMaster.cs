﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    public class UserMaster
    {
        

        //Get or Set Employee ID
        public int EmployeeID { get; set; }

        //Get or Set Username
        public string Username { get; set; }


        //Get or Set Password
        public string Password { get; set; }
    }
}
