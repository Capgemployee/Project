﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Text.RegularExpressions;
using EMS.Exception;
using EMS.Entity;
using System.Data.SqlClient;
using EMS.DAL;


namespace EMS.BL
{
    public class EmployeeValidation
    {
        EmployeeOperations empOp = new EmployeeOperations();
        //Method to validate Employee data 
        #region Validation Methods
        public static bool ValidateEmployee(Employee emp)
        {
            bool empValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if(emp.FirstName == string.Empty)
                {
                    empValidated = false;
                    message.Append("Employee First Name should be Provided\n");
                }
                else if (!Regex.IsMatch(emp.FirstName, "[A-Z][a-z]+"))
                {
                    message.Append("Employee First Name should have alphabets only and it should start with capital\n");
                    empValidated = false;
                }
                if (emp.LastName == string.Empty)
                {
                    empValidated = false;
                    message.Append("Employee Last Name should be Provided\n");
                }
                else if (!Regex.IsMatch(emp.LastName, "[A-Z][a-z]+"))
                {
                    message.Append("Employee Last Name should have alphabets only and it should start with capital\n");
                    empValidated = false;
                }
                if (emp.PhoneNo.ToString().Length == 0)
                {
                    message.Append("Phone Number should be Provided\n");
                    empValidated = false;
                }
                else if (!Regex.IsMatch(emp.PhoneNo.ToString(),"[7-9][0-9]{9}"))
                {
                    message.Append("Phone Number should have 10 digits exactly and it should start with 7 or 8 or 9\n");
                    empValidated = false;
                }
                if (emp.DOJ == null)
                {
                    message.Append("Date of Joining should be provided\n");
                    empValidated = false;
                }
                else if (emp.DOJ > DateTime.Today)
                {
                    message.Append("Date of Joining should be less than or equal to current date\n");
                    empValidated = false;
                }
                if (emp.DOB == null)
                {
                    message.Append("Date of Birth should be provided\n");
                    empValidated = false;
                }
                else if (emp.DOB > DateTime.Today)
                {
                    message.Append("Date of Birth should be less than current date\n");
                    empValidated = false;
                }
                if (emp.Address == string.Empty)
                {
                    empValidated = false;
                    message.Append("Address should be Provided\n");
                }
                if (emp.MaritalStatus == string.Empty)
                {
                    empValidated = false;
                    message.Append("Marital status should be Provided\n");
                }
                else if (emp.MaritalStatus.ToLower() != "married" && emp.MaritalStatus.ToLower() != "unmarried")
                {
                    empValidated = false;
                    message.Append("Marital status should be either Married or Unmarried");
                }
                if (emp.Salary == null)
                {
                    empValidated = false;
                    message.Append("Salary should be Provided\n");
                }
                if(emp.Gender == string.Empty)
                {
                    empValidated = false;
                    message.Append("Gender should be Provided\n");
                }
                else if (emp.Gender.ToLower() != "male"  && emp.Gender.ToLower() != "female")
                {
                    message.Append("Gender should be either Male or Female \n");
                    empValidated = false;
                }
                if (empValidated == false)
                {
                    throw new EmployeeException(message.ToString());
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empValidated;
        }

        //Method to validate Department data
        public static bool ValidateDepartment(Department dept)
        {
            bool deptValidated = true;
            StringBuilder message1 = new StringBuilder();

            try
            {
                if (dept.DepartmentID.ToString().Length == 0)
                {
                    deptValidated = false;
                    message1.Append("Department ID Should be Provided");
                }
                else if (!Regex.IsMatch(dept.DepartmentID.ToString(), @"^[0-9]+$"))
                {
                    deptValidated = false;
                    message1.Append("Department ID Should contain only numbers");
                }
                if (dept.DepartmentName == string.Empty)
                {
                    deptValidated = false;
                    message1.Append("Department Name should be Provided\n");
                }
               
                else if (!Regex.IsMatch(dept.DepartmentName, @"^[a-zA-Z ]+$"))
                {
                    deptValidated = false;
                    message1.Append("Department Name should only contain characters");
                }
                if (deptValidated == false)
                {
                    throw new EmployeeException(message1.ToString());
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return deptValidated;
        }

        //Method to validate Designation data
        public static bool ValidateDesignation(Designation desgObj)
        {
            bool desgValidated = true;
            StringBuilder message2 = new StringBuilder();

            try
            {
                if (desgObj.DesignationID == string.Empty)
                {
                    desgValidated = false;
                    message2.Append("Designation ID should be Provided\n");
                }
                if (desgValidated == false)
                {
                    throw new EmployeeException(message2.ToString());
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return desgValidated;
        }

        //Method to validate Client data
        public static bool ValidateClient(Client clObj)
        {
            bool clientValidated = true;
            StringBuilder message3 = new StringBuilder();

            try
            {
                if (clObj.ClientID == string.Empty)
                {
                    clientValidated = false;
                    message3.Append("Client ID should be Provided\n");
                }

                else if (!Regex.IsMatch(clObj.ClientID, @"^[a-zA-Z][a-zA-Z0-9]*$"))
                {
                    clientValidated = false;
                    message3.Append("Client ID should contain alphanumeric value\n");
                }
                if (clObj.ClientName == string.Empty)
                {
                    clientValidated = false;
                    message3.Append("Client Name should be Provided\n");
                }

                else if (!Regex.IsMatch(clObj.ClientName, @"^[a-zA-Z ]+$"))
                {
                    clientValidated = false;
                    message3.Append("Client Name should only contain characters");
                }
                if (clientValidated == false)
                {
                    throw new EmployeeException(message3.ToString());
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return clientValidated;
        }

        //Method to validate Project data
        public static bool ValidateProject(Project proj)
        {
            bool projValidated = true;
            StringBuilder message4 = new StringBuilder();

            try
            {
                if (proj.ProjectID == string.Empty)
                {
                    projValidated = false;
                    message4.Append("Project ID should be Provided\n");
                }

                else if (!Regex.IsMatch(proj.ProjectID, @"^[a-zA-Z][a-zA-Z0-9]*$"))
                {
                    projValidated = false;
                    message4.Append("Project ID should contain alphanumeric value\n");
                }
                if (proj.ProjectName == string.Empty)
                {
                    projValidated = false;
                    message4.Append("Project Name should be Provided\n");
                }

                else if (!Regex.IsMatch(proj.ProjectName, @"^[a-zA-Z ]+$"))
                {
                    projValidated = false;
                    message4.Append("Project Name should only contain characters");
                }
                //if (proj.ProjectDetails == string.Empty)
                //{
                //    projValidated = false;
                //    message4.Append("Project Details should be provided\n");
                //}
                //else if (!Regex.IsMatch(projObj.ProjectDetails, @"^[a-zA-Z ]+$"))
                //{
                //    projValidated = false;
                //    message4.Append("Project details should only contain characters");
                //}
                if (proj.ClientID == string.Empty)
                {
                    projValidated = false;
                    message4.Append("Client ID should be Provided\n");
                }

                else if (!Regex.IsMatch(proj.ClientID, @"^[a-zA-Z][a-zA-Z0-9]*$"))
                {
                    projValidated = false;
                    message4.Append("Client ID should contain alphanumeric value\n");
                }
                if (proj.ManagerID < 1000 || proj.ManagerID > 9999)
                {
                    message4.Append("Employee ID should have 4 digits only\n");
                    projValidated = false;
                }
                if (projValidated == false)
                {
                    throw new EmployeeException(message4.ToString());
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return projValidated;
        }

        //Method to validate Shift detail data
        public static bool ValidateShiftDetail(ShiftDetail shift)
        {
            bool shftValidated = true;
            StringBuilder message5 = new StringBuilder();

            try
            {
                if (shftValidated == false)
                {
                    throw new EmployeeException(message5.ToString());
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return shftValidated;
        }

        //Method to validate Employee Project data
        public static bool ValidateEmpProject(EmployeeProject empProj)
        {
            bool emprojValidated = true;
            StringBuilder message6 = new StringBuilder();

            try
            {
                if (emprojValidated == false)
                {
                    throw new EmployeeException(message6.ToString());
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return emprojValidated;
        }

        //Method to validate Employee shift details data
        public static bool ValidateEmpShift(EmployeeShiftdetails empShift)
        {
            bool empshftValidated = true;
            StringBuilder message7 = new StringBuilder();

            try
            {
                if (empshftValidated == false)
                {
                    throw new EmployeeException(message7.ToString());
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return empshftValidated;
        }

        //Method to validate Grade Master data
        public static bool ValidateGradeMaster(GradeMaster gradeObj)
        {
            bool gradeValidated = true;
            StringBuilder message8 = new StringBuilder();

            try
            {
                if (gradeValidated == false)
                {
                    throw new EmployeeException(message8.ToString());
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return gradeValidated;
        }
        // Method to validate user master data
        public static bool ValidateUsermaster(UserMaster user)
        {
            bool userValidated = true;
            StringBuilder message9 = new StringBuilder();
            try
            {
                if (user.Username== string.Empty)
                {
                    userValidated = false;
                    message9.Append("Username should be provided should be Provided\n");
                }
                if (user.Password == string.Empty)
                {
                    userValidated = false;
                    message9.Append("Username should be provided should be Provided\n");
                }
                 if (userValidated == false)
                {
                    throw new EmployeeException(message9.ToString());
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return userValidated;
            
        }
        #endregion
        //ADMIN METHODS
        //Admin methods :To perform employee functionalities
        //1. method to add employee
        #region Admin
        public bool AddEmployee(Employee emp)
        {
            bool empAdded = false;
            try
            {
                if (ValidateEmployee(emp) == true)
                {
                    empAdded = empOp.AddEmployee(emp);
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return empAdded;
        }

        //2. method to display employee
        public DataTable DisplayEmployee()
        {
            DataTable table = new DataTable();
            try
            {
                table = empOp.DisplayEmployee();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return table;
        }

        //3. method to search employee
        public DataTable SearchEmployee(int ID)
        {
            DataTable table = new DataTable();
            try
            {
                table = empOp.SearchEmployee(ID);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return table;
        }

        //4.method to delete employee
        public bool DeleteEmployee(int ID)
        {
            bool empDeleted = false;
            try
            {
                empDeleted = empOp.DeleteEmployee(ID);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return empDeleted;
        }

        //5.method to Update employee
        public bool UpdateEmployee(Employee emp)
        {
            bool empUpdated = false;
            try
            {
                if (ValidateEmployee(emp) == true)
                {
                    empUpdated =empOp.UpdateEmployee(emp);
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return empUpdated;
        }

        //6. View employee details
        public DataTable GetEmployeeDetails(int ID)
        {
            DataTable table = new DataTable();
            try
            {
                table = empOp.SearchEmployeeDetails(ID);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return table;
        }


        // Admin method : to perform operations om department
        //1. method to add department
        public bool AddDepartment(Department dept)
        {
            bool deptAdded = false;
            try
            {
                if (ValidateDepartment(dept) == true)
                {
                    deptAdded = empOp.AddDepartment(dept);
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return deptAdded;
        }

        //2.method to display department
        public DataTable DisplayDepartment()
        {
            DataTable table = new DataTable();
            try
            {
                table = empOp.DislpayDepartment();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return table;
        }

        //3.method to delete department
        public bool DeleteDepartment(int ID)
        {
            bool deptDeleted = false;
            try
            {
               deptDeleted = empOp.DeleteDepartment(ID);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return deptDeleted;
        }

        // Admin methods : to perform operations on project
        //1. method to add project
        public bool AddProjectDetails(Project proj)
        {
            bool projAdded = false;
            try
            {
                if (ValidateProject(proj) == true)
                {
                    projAdded = empOp.AddProjectDetails(proj);
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return projAdded;
        }

        //2. method to display project details
        public DataTable DislpayProjectDetails()
        {
            DataTable table = new DataTable();
            try
            {
                table = empOp.DislpayProjectDetails();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return table;
        }

        //3.method to assign project details
        public bool AssignProject(EmployeeProject empProj)
        {
            bool projAssigned = false;
            try
            {
                if (ValidateEmpProject(empProj) == true)
                {
                    projAssigned = empOp.AssignProject(empProj);
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return projAssigned;
        }

        //Admin method: To perform operations on Timesheet
        //1. method to assign timesheet
        public bool AssignShift(EmployeeShiftdetails empShift)
        {
            bool shiftAssigned = false;
            try
            {
                if (ValidateEmpShift(empShift) == true)
                {
                    shiftAssigned = empOp.AssignShift(empShift);
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return shiftAssigned;
        }

        //2. method to update timesheet
        public bool UpdateShift(EmployeeShiftdetails empShift)
        {
            bool shiftUpdated = false;
            try
            {
                if (ValidateEmpShift(empShift) == true)
                {
                    shiftUpdated = empOp.UpdateShift(empShift);
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return shiftUpdated;
        }

        //3. method to display timesheet
        public DataTable DislpayTimesheetDetails()
        {
            DataTable table = new DataTable();
            try
            {
                table = empOp.DislpayTimesheetDetails();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return table;
        }
        //4. method to search employee's shift
        public DataTable SearchEmpShift(int ID)
        {
            DataTable table = new DataTable();
            try
            {
                table = empOp.SearchEmpShift(ID);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return table;
        }

        //Admin: operation on user master
        // method to add login details
        public bool CreateUsernamePassword(UserMaster user)
        {
            bool userAdded = false;
            try
            {
                if (ValidateUsermaster(user) == true)
                {
                    userAdded = empOp.CreateUsernamePassword(user);
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return userAdded;
        }
        #endregion
        //EMPLOYEE METHODS
        //employee : operations on his own profile
        //1. method to update employee profile
        #region Employee
        public bool UpdateEmployeeDetails(Employee emp)
        {
            bool empUpdated = false;
            try
            {
                if (ValidateEmployee(emp) == true)
                {
                    empUpdated = empOp.UpdateEmployeeDetails(emp);
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return empUpdated;
        }

        //2.method to search employee profile
        //Not written in Dal as well



        //employee: operation on timesheet
        //1. method to view Timesheet
        public DataTable ViewEmpShift(int ID)
        {
            DataTable table = new DataTable();
            try
            {
                table = empOp.ViewEmpShift(ID);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return table;
        }

        //employee: operation on project
        //1. method to view project details
        public DataTable SearchProjDetails(int ID)
        {
            DataTable table = new DataTable();
            try
            {
                table = empOp.SearchProjDetails(ID);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return table;
        }

        //employe: operation to search any employee
        // method to search any employee on the basis of idea\
        public DataTable SearchEmployeeDetails(int ID)
        {
            DataTable table = new DataTable();
            try
            {
                table = empOp.SearchEmployeeDetails(ID);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return table;
        }

        public bool LoginEmployee(UserMaster user)
        {
            bool empverified = false;
            if (ValidateUsermaster(user))
                empverified = empOp.LoginEmployee(user);
            return empverified;
        }

    }
}
        #endregion