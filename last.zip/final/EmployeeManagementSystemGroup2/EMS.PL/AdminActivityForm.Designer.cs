﻿namespace EMS.PL
{
    partial class AdminActivityForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminActivityForm));
            this.tabPgTimeSheet = new System.Windows.Forms.TabPage();
            this.gbAssignShift = new System.Windows.Forms.GroupBox();
            this.btnUpdateShift = new System.Windows.Forms.Button();
            this.btnAssignShift = new System.Windows.Forms.Button();
            this.txtEmpIdTymSht = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtShftIDTymShft = new System.Windows.Forms.TextBox();
            this.lbShiftidTymSheet = new System.Windows.Forms.Label();
            this.lblLogOut5 = new System.Windows.Forms.Label();
            this.btnDisplayTymSheet = new System.Windows.Forms.Button();
            this.btnShftSearch = new System.Windows.Forms.Button();
            this.txtTymEmpid = new System.Windows.Forms.TextBox();
            this.lblTymEmpId = new System.Windows.Forms.Label();
            this.dgvTymSheet = new System.Windows.Forms.DataGridView();
            this.btnlogoff5 = new System.Windows.Forms.Button();
            this.pichome5 = new System.Windows.Forms.PictureBox();
            this.llbhome5 = new System.Windows.Forms.LinkLabel();
            this.tabPgProj = new System.Windows.Forms.TabPage();
            this.gbProjAssnmnt = new System.Windows.Forms.GroupBox();
            this.btnProjAssnmnt = new System.Windows.Forms.Button();
            this.txtemprojid = new System.Windows.Forms.TextBox();
            this.lblempidproj = new System.Windows.Forms.Label();
            this.txtprojtid = new System.Windows.Forms.TextBox();
            this.lblproj = new System.Windows.Forms.Label();
            this.lblLogOut4 = new System.Windows.Forms.Label();
            this.btnAddProj = new System.Windows.Forms.Button();
            this.btnViewProj = new System.Windows.Forms.Button();
            this.dgvProjDetails = new System.Windows.Forms.DataGridView();
            this.txtMgrCode = new System.Windows.Forms.TextBox();
            this.txtClientCode = new System.Windows.Forms.TextBox();
            this.txtProjName = new System.Windows.Forms.TextBox();
            this.txtProjId = new System.Windows.Forms.TextBox();
            this.lblMgrCode = new System.Windows.Forms.Label();
            this.lblClientCode = new System.Windows.Forms.Label();
            this.lblProjName = new System.Windows.Forms.Label();
            this.lblProjId = new System.Windows.Forms.Label();
            this.btnlogoff4 = new System.Windows.Forms.Button();
            this.pichome4 = new System.Windows.Forms.PictureBox();
            this.llbhome4 = new System.Windows.Forms.LinkLabel();
            this.tabPgdept = new System.Windows.Forms.TabPage();
            this.lblLogOut3 = new System.Windows.Forms.Label();
            this.btnDeptDelete = new System.Windows.Forms.Button();
            this.btnDeptAdd = new System.Windows.Forms.Button();
            this.btnDeptDisplay = new System.Windows.Forms.Button();
            this.btnhome3 = new System.Windows.Forms.Button();
            this.pichome3 = new System.Windows.Forms.PictureBox();
            this.llbhome3 = new System.Windows.Forms.LinkLabel();
            this.dgvDeptDetails = new System.Windows.Forms.DataGridView();
            this.txtDeptName = new System.Windows.Forms.TextBox();
            this.txtDeptId = new System.Windows.Forms.TextBox();
            this.lblDeptName = new System.Windows.Forms.Label();
            this.lblDeptId = new System.Windows.Forms.Label();
            this.tabPgAddEmp = new System.Windows.Forms.TabPage();
            this.btnSearchEmpId = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdAddEmp = new System.Windows.Forms.RadioButton();
            this.rdbtnDelete = new System.Windows.Forms.RadioButton();
            this.rdbtnUpdate = new System.Windows.Forms.RadioButton();
            this.llbLogOut2 = new System.Windows.Forms.Label();
            this.btnlogout2 = new System.Windows.Forms.Button();
            this.txtEmplyId = new System.Windows.Forms.TextBox();
            this.lblEmplyID = new System.Windows.Forms.Label();
            this.btndeleteEmp = new System.Windows.Forms.Button();
            this.btnUpdateEmp = new System.Windows.Forms.Button();
            this.btnaddemp = new System.Windows.Forms.Button();
            this.cmbgrade = new System.Windows.Forms.ComboBox();
            this.cmbdept = new System.Windows.Forms.ComboBox();
            this.cmbdesg = new System.Windows.Forms.ComboBox();
            this.cmbMStuts = new System.Windows.Forms.ComboBox();
            this.cmbgender = new System.Windows.Forms.ComboBox();
            this.dtpDOJ = new System.Windows.Forms.DateTimePicker();
            this.dtpDOB = new System.Windows.Forms.DateTimePicker();
            this.txtFrstnme = new System.Windows.Forms.TextBox();
            this.txtmgr = new System.Windows.Forms.TextBox();
            this.txtPhnNumbr = new System.Windows.Forms.TextBox();
            this.txtsal = new System.Windows.Forms.TextBox();
            this.txtaddrss = new System.Windows.Forms.TextBox();
            this.txtLstnme = new System.Windows.Forms.TextBox();
            this.lblGrdCode = new System.Windows.Forms.Label();
            this.lblMgrId = new System.Windows.Forms.Label();
            this.lblDpt = new System.Windows.Forms.Label();
            this.lblDesg = new System.Windows.Forms.Label();
            this.lblPhnNo = new System.Windows.Forms.Label();
            this.lblSal = new System.Windows.Forms.Label();
            this.lblMStatus = new System.Windows.Forms.Label();
            this.lblAddrs = new System.Windows.Forms.Label();
            this.lblgender = new System.Windows.Forms.Label();
            this.lblDOJ = new System.Windows.Forms.Label();
            this.lblDOB = new System.Windows.Forms.Label();
            this.lblLstName = new System.Windows.Forms.Label();
            this.lblFrstName = new System.Windows.Forms.Label();
            this.pichome2 = new System.Windows.Forms.PictureBox();
            this.llbhome2 = new System.Windows.Forms.LinkLabel();
            this.tabPgViewEmp = new System.Windows.Forms.TabPage();
            this.lblLogOut1 = new System.Windows.Forms.Label();
            this.btnlogoff1 = new System.Windows.Forms.Button();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.pichome1 = new System.Windows.Forms.PictureBox();
            this.llbhome1 = new System.Windows.Forms.LinkLabel();
            this.dgvEmpDetails = new System.Windows.Forms.DataGridView();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtEmpId = new System.Windows.Forms.TextBox();
            this.lblEmpId = new System.Windows.Forms.Label();
            this.tbAdminActivity = new System.Windows.Forms.TabControl();
            this.tplogindetails = new System.Windows.Forms.TabPage();
            this.lbllogout6 = new System.Windows.Forms.Label();
            this.btnLogoff6 = new System.Windows.Forms.Button();
            this.pchome6 = new System.Windows.Forms.PictureBox();
            this.llbhome6 = new System.Windows.Forms.LinkLabel();
            this.txtEmplogin = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCreatelogin = new System.Windows.Forms.Button();
            this.txtusrnme = new System.Windows.Forms.TextBox();
            this.lblusrnme = new System.Windows.Forms.Label();
            this.txtpswd = new System.Windows.Forms.TextBox();
            this.lblpswd = new System.Windows.Forms.Label();
            this.tabPgTimeSheet.SuspendLayout();
            this.gbAssignShift.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTymSheet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pichome5)).BeginInit();
            this.tabPgProj.SuspendLayout();
            this.gbProjAssnmnt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProjDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pichome4)).BeginInit();
            this.tabPgdept.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pichome3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeptDetails)).BeginInit();
            this.tabPgAddEmp.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pichome2)).BeginInit();
            this.tabPgViewEmp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pichome1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpDetails)).BeginInit();
            this.tbAdminActivity.SuspendLayout();
            this.tplogindetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pchome6)).BeginInit();
            this.SuspendLayout();
            // 
            // tabPgTimeSheet
            // 
            this.tabPgTimeSheet.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPgTimeSheet.BackgroundImage")));
            this.tabPgTimeSheet.Controls.Add(this.gbAssignShift);
            this.tabPgTimeSheet.Controls.Add(this.lblLogOut5);
            this.tabPgTimeSheet.Controls.Add(this.btnDisplayTymSheet);
            this.tabPgTimeSheet.Controls.Add(this.btnShftSearch);
            this.tabPgTimeSheet.Controls.Add(this.txtTymEmpid);
            this.tabPgTimeSheet.Controls.Add(this.lblTymEmpId);
            this.tabPgTimeSheet.Controls.Add(this.dgvTymSheet);
            this.tabPgTimeSheet.Controls.Add(this.btnlogoff5);
            this.tabPgTimeSheet.Controls.Add(this.pichome5);
            this.tabPgTimeSheet.Controls.Add(this.llbhome5);
            this.tabPgTimeSheet.Location = new System.Drawing.Point(4, 24);
            this.tabPgTimeSheet.Name = "tabPgTimeSheet";
            this.tabPgTimeSheet.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgTimeSheet.Size = new System.Drawing.Size(963, 719);
            this.tabPgTimeSheet.TabIndex = 5;
            this.tabPgTimeSheet.Text = "Time Sheet Management";
            this.tabPgTimeSheet.UseVisualStyleBackColor = true;
            // 
            // gbAssignShift
            // 
            this.gbAssignShift.Controls.Add(this.btnUpdateShift);
            this.gbAssignShift.Controls.Add(this.btnAssignShift);
            this.gbAssignShift.Controls.Add(this.txtEmpIdTymSht);
            this.gbAssignShift.Controls.Add(this.label2);
            this.gbAssignShift.Controls.Add(this.txtShftIDTymShft);
            this.gbAssignShift.Controls.Add(this.lbShiftidTymSheet);
            this.gbAssignShift.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gbAssignShift.Location = new System.Drawing.Point(96, 68);
            this.gbAssignShift.Name = "gbAssignShift";
            this.gbAssignShift.Size = new System.Drawing.Size(738, 138);
            this.gbAssignShift.TabIndex = 91;
            this.gbAssignShift.TabStop = false;
            this.gbAssignShift.Text = "Shift Management";
            // 
            // btnUpdateShift
            // 
            this.btnUpdateShift.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnUpdateShift.Location = new System.Drawing.Point(365, 95);
            this.btnUpdateShift.Name = "btnUpdateShift";
            this.btnUpdateShift.Size = new System.Drawing.Size(170, 37);
            this.btnUpdateShift.TabIndex = 92;
            this.btnUpdateShift.Text = "Update Assign Shift";
            this.btnUpdateShift.UseVisualStyleBackColor = true;
            this.btnUpdateShift.Click += new System.EventHandler(this.btnUpdateShift_Click);
            // 
            // btnAssignShift
            // 
            this.btnAssignShift.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnAssignShift.Location = new System.Drawing.Point(189, 95);
            this.btnAssignShift.Name = "btnAssignShift";
            this.btnAssignShift.Size = new System.Drawing.Size(170, 37);
            this.btnAssignShift.TabIndex = 91;
            this.btnAssignShift.Text = "Assign Shift";
            this.btnAssignShift.UseVisualStyleBackColor = true;
            this.btnAssignShift.Click += new System.EventHandler(this.btnAssignShift_Click);
            // 
            // txtEmpIdTymSht
            // 
            this.txtEmpIdTymSht.Location = new System.Drawing.Point(523, 47);
            this.txtEmpIdTymSht.Name = "txtEmpIdTymSht";
            this.txtEmpIdTymSht.Size = new System.Drawing.Size(176, 26);
            this.txtEmpIdTymSht.TabIndex = 91;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(401, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 19);
            this.label2.TabIndex = 90;
            this.label2.Text = "Employee ID :";
            // 
            // txtShftIDTymShft
            // 
            this.txtShftIDTymShft.Location = new System.Drawing.Point(138, 47);
            this.txtShftIDTymShft.Name = "txtShftIDTymShft";
            this.txtShftIDTymShft.Size = new System.Drawing.Size(200, 26);
            this.txtShftIDTymShft.TabIndex = 88;
            // 
            // lbShiftidTymSheet
            // 
            this.lbShiftidTymSheet.AutoSize = true;
            this.lbShiftidTymSheet.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbShiftidTymSheet.Location = new System.Drawing.Point(34, 50);
            this.lbShiftidTymSheet.Name = "lbShiftidTymSheet";
            this.lbShiftidTymSheet.Size = new System.Drawing.Size(71, 19);
            this.lbShiftidTymSheet.TabIndex = 89;
            this.lbShiftidTymSheet.Text = "Shift ID :";
            // 
            // lblLogOut5
            // 
            this.lblLogOut5.AutoSize = true;
            this.lblLogOut5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogOut5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblLogOut5.Location = new System.Drawing.Point(889, 666);
            this.lblLogOut5.Name = "lblLogOut5";
            this.lblLogOut5.Size = new System.Drawing.Size(59, 17);
            this.lblLogOut5.TabIndex = 86;
            this.lblLogOut5.Text = "LogOut";
            // 
            // btnDisplayTymSheet
            // 
            this.btnDisplayTymSheet.Location = new System.Drawing.Point(39, 260);
            this.btnDisplayTymSheet.Name = "btnDisplayTymSheet";
            this.btnDisplayTymSheet.Size = new System.Drawing.Size(291, 26);
            this.btnDisplayTymSheet.TabIndex = 36;
            this.btnDisplayTymSheet.Text = "Display Time Sheet";
            this.btnDisplayTymSheet.UseVisualStyleBackColor = true;
            this.btnDisplayTymSheet.Click += new System.EventHandler(this.btnDisplayTymSheet_Click);
            // 
            // btnShftSearch
            // 
            this.btnShftSearch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnShftSearch.BackgroundImage")));
            this.btnShftSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnShftSearch.Location = new System.Drawing.Point(855, 256);
            this.btnShftSearch.Name = "btnShftSearch";
            this.btnShftSearch.Size = new System.Drawing.Size(34, 36);
            this.btnShftSearch.TabIndex = 35;
            this.btnShftSearch.UseVisualStyleBackColor = true;
            this.btnShftSearch.Click += new System.EventHandler(this.btnShftSearch_Click);
            // 
            // txtTymEmpid
            // 
            this.txtTymEmpid.Location = new System.Drawing.Point(633, 260);
            this.txtTymEmpid.Name = "txtTymEmpid";
            this.txtTymEmpid.Size = new System.Drawing.Size(216, 26);
            this.txtTymEmpid.TabIndex = 34;
            // 
            // lblTymEmpId
            // 
            this.lblTymEmpId.AutoSize = true;
            this.lblTymEmpId.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTymEmpId.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTymEmpId.Location = new System.Drawing.Point(521, 263);
            this.lblTymEmpId.Name = "lblTymEmpId";
            this.lblTymEmpId.Size = new System.Drawing.Size(106, 19);
            this.lblTymEmpId.TabIndex = 33;
            this.lblTymEmpId.Text = "Employee ID :";
            // 
            // dgvTymSheet
            // 
            this.dgvTymSheet.BackgroundColor = System.Drawing.Color.SaddleBrown;
            this.dgvTymSheet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTymSheet.Location = new System.Drawing.Point(39, 310);
            this.dgvTymSheet.Name = "dgvTymSheet";
            this.dgvTymSheet.Size = new System.Drawing.Size(850, 333);
            this.dgvTymSheet.TabIndex = 31;
            // 
            // btnlogoff5
            // 
            this.btnlogoff5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnlogoff5.BackgroundImage")));
            this.btnlogoff5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnlogoff5.Location = new System.Drawing.Point(854, 658);
            this.btnlogoff5.Name = "btnlogoff5";
            this.btnlogoff5.Size = new System.Drawing.Size(35, 33);
            this.btnlogoff5.TabIndex = 20;
            this.btnlogoff5.UseVisualStyleBackColor = true;
            // 
            // pichome5
            // 
            this.pichome5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pichome5.BackgroundImage")));
            this.pichome5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pichome5.Location = new System.Drawing.Point(854, 23);
            this.pichome5.Name = "pichome5";
            this.pichome5.Size = new System.Drawing.Size(35, 35);
            this.pichome5.TabIndex = 19;
            this.pichome5.TabStop = false;
            // 
            // llbhome5
            // 
            this.llbhome5.AutoSize = true;
            this.llbhome5.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbhome5.LinkColor = System.Drawing.Color.Cyan;
            this.llbhome5.Location = new System.Drawing.Point(895, 23);
            this.llbhome5.Name = "llbhome5";
            this.llbhome5.Size = new System.Drawing.Size(53, 19);
            this.llbhome5.TabIndex = 18;
            this.llbhome5.TabStop = true;
            this.llbhome5.Text = "Home";
            this.llbhome5.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbhome5_LinkClicked);
            // 
            // tabPgProj
            // 
            this.tabPgProj.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPgProj.BackgroundImage")));
            this.tabPgProj.Controls.Add(this.gbProjAssnmnt);
            this.tabPgProj.Controls.Add(this.lblLogOut4);
            this.tabPgProj.Controls.Add(this.btnAddProj);
            this.tabPgProj.Controls.Add(this.btnViewProj);
            this.tabPgProj.Controls.Add(this.dgvProjDetails);
            this.tabPgProj.Controls.Add(this.txtMgrCode);
            this.tabPgProj.Controls.Add(this.txtClientCode);
            this.tabPgProj.Controls.Add(this.txtProjName);
            this.tabPgProj.Controls.Add(this.txtProjId);
            this.tabPgProj.Controls.Add(this.lblMgrCode);
            this.tabPgProj.Controls.Add(this.lblClientCode);
            this.tabPgProj.Controls.Add(this.lblProjName);
            this.tabPgProj.Controls.Add(this.lblProjId);
            this.tabPgProj.Controls.Add(this.btnlogoff4);
            this.tabPgProj.Controls.Add(this.pichome4);
            this.tabPgProj.Controls.Add(this.llbhome4);
            this.tabPgProj.Location = new System.Drawing.Point(4, 24);
            this.tabPgProj.Name = "tabPgProj";
            this.tabPgProj.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgProj.Size = new System.Drawing.Size(963, 719);
            this.tabPgProj.TabIndex = 4;
            this.tabPgProj.Text = "Project Details";
            this.tabPgProj.UseVisualStyleBackColor = true;
            // 
            // gbProjAssnmnt
            // 
            this.gbProjAssnmnt.Controls.Add(this.btnProjAssnmnt);
            this.gbProjAssnmnt.Controls.Add(this.txtemprojid);
            this.gbProjAssnmnt.Controls.Add(this.lblempidproj);
            this.gbProjAssnmnt.Controls.Add(this.txtprojtid);
            this.gbProjAssnmnt.Controls.Add(this.lblproj);
            this.gbProjAssnmnt.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gbProjAssnmnt.Location = new System.Drawing.Point(97, 44);
            this.gbProjAssnmnt.Name = "gbProjAssnmnt";
            this.gbProjAssnmnt.Size = new System.Drawing.Size(738, 138);
            this.gbProjAssnmnt.TabIndex = 90;
            this.gbProjAssnmnt.TabStop = false;
            this.gbProjAssnmnt.Text = "Project Assignment";
            // 
            // btnProjAssnmnt
            // 
            this.btnProjAssnmnt.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnProjAssnmnt.Location = new System.Drawing.Point(273, 95);
            this.btnProjAssnmnt.Name = "btnProjAssnmnt";
            this.btnProjAssnmnt.Size = new System.Drawing.Size(234, 37);
            this.btnProjAssnmnt.TabIndex = 91;
            this.btnProjAssnmnt.Text = "Assign";
            this.btnProjAssnmnt.UseVisualStyleBackColor = true;
            this.btnProjAssnmnt.Click += new System.EventHandler(this.btnProjAssnmnt_Click);
            // 
            // txtemprojid
            // 
            this.txtemprojid.Location = new System.Drawing.Point(523, 47);
            this.txtemprojid.Name = "txtemprojid";
            this.txtemprojid.Size = new System.Drawing.Size(176, 26);
            this.txtemprojid.TabIndex = 91;
            // 
            // lblempidproj
            // 
            this.lblempidproj.AutoSize = true;
            this.lblempidproj.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblempidproj.Location = new System.Drawing.Point(401, 50);
            this.lblempidproj.Name = "lblempidproj";
            this.lblempidproj.Size = new System.Drawing.Size(106, 19);
            this.lblempidproj.TabIndex = 90;
            this.lblempidproj.Text = "Employee ID :";
            // 
            // txtprojtid
            // 
            this.txtprojtid.Location = new System.Drawing.Point(138, 47);
            this.txtprojtid.Name = "txtprojtid";
            this.txtprojtid.Size = new System.Drawing.Size(200, 26);
            this.txtprojtid.TabIndex = 88;
            // 
            // lblproj
            // 
            this.lblproj.AutoSize = true;
            this.lblproj.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblproj.Location = new System.Drawing.Point(34, 50);
            this.lblproj.Name = "lblproj";
            this.lblproj.Size = new System.Drawing.Size(87, 19);
            this.lblproj.TabIndex = 89;
            this.lblproj.Text = "Project ID :";
            // 
            // lblLogOut4
            // 
            this.lblLogOut4.AutoSize = true;
            this.lblLogOut4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogOut4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblLogOut4.Location = new System.Drawing.Point(883, 688);
            this.lblLogOut4.Name = "lblLogOut4";
            this.lblLogOut4.Size = new System.Drawing.Size(59, 17);
            this.lblLogOut4.TabIndex = 86;
            this.lblLogOut4.Text = "LogOut";
            // 
            // btnAddProj
            // 
            this.btnAddProj.Location = new System.Drawing.Point(568, 655);
            this.btnAddProj.Name = "btnAddProj";
            this.btnAddProj.Size = new System.Drawing.Size(163, 38);
            this.btnAddProj.TabIndex = 31;
            this.btnAddProj.Text = "Add Project";
            this.btnAddProj.UseVisualStyleBackColor = true;
            this.btnAddProj.Click += new System.EventHandler(this.btnAddProj_Click);
            // 
            // btnViewProj
            // 
            this.btnViewProj.Location = new System.Drawing.Point(212, 655);
            this.btnViewProj.Name = "btnViewProj";
            this.btnViewProj.Size = new System.Drawing.Size(163, 38);
            this.btnViewProj.TabIndex = 30;
            this.btnViewProj.Text = "View Project Details";
            this.btnViewProj.UseVisualStyleBackColor = true;
            this.btnViewProj.Click += new System.EventHandler(this.btnViewProj_Click);
            // 
            // dgvProjDetails
            // 
            this.dgvProjDetails.BackgroundColor = System.Drawing.Color.SaddleBrown;
            this.dgvProjDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProjDetails.Location = new System.Drawing.Point(86, 384);
            this.dgvProjDetails.Name = "dgvProjDetails";
            this.dgvProjDetails.Size = new System.Drawing.Size(796, 265);
            this.dgvProjDetails.TabIndex = 29;
            // 
            // txtMgrCode
            // 
            this.txtMgrCode.Location = new System.Drawing.Point(402, 337);
            this.txtMgrCode.Name = "txtMgrCode";
            this.txtMgrCode.Size = new System.Drawing.Size(266, 26);
            this.txtMgrCode.TabIndex = 28;
            // 
            // txtClientCode
            // 
            this.txtClientCode.Location = new System.Drawing.Point(402, 299);
            this.txtClientCode.Name = "txtClientCode";
            this.txtClientCode.Size = new System.Drawing.Size(266, 26);
            this.txtClientCode.TabIndex = 27;
            // 
            // txtProjName
            // 
            this.txtProjName.Location = new System.Drawing.Point(402, 261);
            this.txtProjName.Name = "txtProjName";
            this.txtProjName.Size = new System.Drawing.Size(266, 26);
            this.txtProjName.TabIndex = 26;
            // 
            // txtProjId
            // 
            this.txtProjId.Location = new System.Drawing.Point(402, 219);
            this.txtProjId.Name = "txtProjId";
            this.txtProjId.Size = new System.Drawing.Size(266, 26);
            this.txtProjId.TabIndex = 25;
            // 
            // lblMgrCode
            // 
            this.lblMgrCode.AutoSize = true;
            this.lblMgrCode.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblMgrCode.Location = new System.Drawing.Point(235, 337);
            this.lblMgrCode.Name = "lblMgrCode";
            this.lblMgrCode.Size = new System.Drawing.Size(119, 19);
            this.lblMgrCode.TabIndex = 24;
            this.lblMgrCode.Text = "Manager Code :";
            // 
            // lblClientCode
            // 
            this.lblClientCode.AutoSize = true;
            this.lblClientCode.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblClientCode.Location = new System.Drawing.Point(235, 299);
            this.lblClientCode.Name = "lblClientCode";
            this.lblClientCode.Size = new System.Drawing.Size(97, 19);
            this.lblClientCode.TabIndex = 23;
            this.lblClientCode.Text = "Client Code :";
            // 
            // lblProjName
            // 
            this.lblProjName.AutoSize = true;
            this.lblProjName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblProjName.Location = new System.Drawing.Point(235, 261);
            this.lblProjName.Name = "lblProjName";
            this.lblProjName.Size = new System.Drawing.Size(109, 19);
            this.lblProjName.TabIndex = 22;
            this.lblProjName.Text = "Project Name :";
            // 
            // lblProjId
            // 
            this.lblProjId.AutoSize = true;
            this.lblProjId.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblProjId.Location = new System.Drawing.Point(235, 219);
            this.lblProjId.Name = "lblProjId";
            this.lblProjId.Size = new System.Drawing.Size(87, 19);
            this.lblProjId.TabIndex = 21;
            this.lblProjId.Text = "Project ID :";
            // 
            // btnlogoff4
            // 
            this.btnlogoff4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnlogoff4.BackgroundImage")));
            this.btnlogoff4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnlogoff4.Location = new System.Drawing.Point(842, 680);
            this.btnlogoff4.Name = "btnlogoff4";
            this.btnlogoff4.Size = new System.Drawing.Size(35, 33);
            this.btnlogoff4.TabIndex = 20;
            this.btnlogoff4.UseVisualStyleBackColor = true;
            // 
            // pichome4
            // 
            this.pichome4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pichome4.BackgroundImage")));
            this.pichome4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pichome4.Location = new System.Drawing.Point(841, 23);
            this.pichome4.Name = "pichome4";
            this.pichome4.Size = new System.Drawing.Size(35, 35);
            this.pichome4.TabIndex = 19;
            this.pichome4.TabStop = false;
            // 
            // llbhome4
            // 
            this.llbhome4.AutoSize = true;
            this.llbhome4.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbhome4.LinkColor = System.Drawing.Color.Cyan;
            this.llbhome4.Location = new System.Drawing.Point(882, 23);
            this.llbhome4.Name = "llbhome4";
            this.llbhome4.Size = new System.Drawing.Size(53, 19);
            this.llbhome4.TabIndex = 18;
            this.llbhome4.TabStop = true;
            this.llbhome4.Text = "Home";
            this.llbhome4.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbhome4_LinkClicked);
            // 
            // tabPgdept
            // 
            this.tabPgdept.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPgdept.BackgroundImage")));
            this.tabPgdept.Controls.Add(this.lblLogOut3);
            this.tabPgdept.Controls.Add(this.btnDeptDelete);
            this.tabPgdept.Controls.Add(this.btnDeptAdd);
            this.tabPgdept.Controls.Add(this.btnDeptDisplay);
            this.tabPgdept.Controls.Add(this.btnhome3);
            this.tabPgdept.Controls.Add(this.pichome3);
            this.tabPgdept.Controls.Add(this.llbhome3);
            this.tabPgdept.Controls.Add(this.dgvDeptDetails);
            this.tabPgdept.Controls.Add(this.txtDeptName);
            this.tabPgdept.Controls.Add(this.txtDeptId);
            this.tabPgdept.Controls.Add(this.lblDeptName);
            this.tabPgdept.Controls.Add(this.lblDeptId);
            this.tabPgdept.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPgdept.Location = new System.Drawing.Point(4, 24);
            this.tabPgdept.Name = "tabPgdept";
            this.tabPgdept.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgdept.Size = new System.Drawing.Size(963, 719);
            this.tabPgdept.TabIndex = 2;
            this.tabPgdept.Text = "Department";
            this.tabPgdept.UseVisualStyleBackColor = true;
            // 
            // lblLogOut3
            // 
            this.lblLogOut3.AutoSize = true;
            this.lblLogOut3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogOut3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblLogOut3.Location = new System.Drawing.Point(887, 662);
            this.lblLogOut3.Name = "lblLogOut3";
            this.lblLogOut3.Size = new System.Drawing.Size(59, 17);
            this.lblLogOut3.TabIndex = 85;
            this.lblLogOut3.Text = "LogOut";
            // 
            // btnDeptDelete
            // 
            this.btnDeptDelete.Location = new System.Drawing.Point(708, 587);
            this.btnDeptDelete.Name = "btnDeptDelete";
            this.btnDeptDelete.Size = new System.Drawing.Size(163, 38);
            this.btnDeptDelete.TabIndex = 17;
            this.btnDeptDelete.Text = "Delete Department";
            this.btnDeptDelete.UseVisualStyleBackColor = true;
            this.btnDeptDelete.Click += new System.EventHandler(this.btnDeptDelete_Click);
            // 
            // btnDeptAdd
            // 
            this.btnDeptAdd.Location = new System.Drawing.Point(395, 587);
            this.btnDeptAdd.Name = "btnDeptAdd";
            this.btnDeptAdd.Size = new System.Drawing.Size(163, 38);
            this.btnDeptAdd.TabIndex = 16;
            this.btnDeptAdd.Text = "Add Department";
            this.btnDeptAdd.UseVisualStyleBackColor = true;
            this.btnDeptAdd.Click += new System.EventHandler(this.btnDeptAdd_Click);
            // 
            // btnDeptDisplay
            // 
            this.btnDeptDisplay.Location = new System.Drawing.Point(79, 587);
            this.btnDeptDisplay.Name = "btnDeptDisplay";
            this.btnDeptDisplay.Size = new System.Drawing.Size(163, 38);
            this.btnDeptDisplay.TabIndex = 15;
            this.btnDeptDisplay.Text = "View Departments";
            this.btnDeptDisplay.UseVisualStyleBackColor = true;
            this.btnDeptDisplay.Click += new System.EventHandler(this.btnDeptDisplay_Click);
            // 
            // btnhome3
            // 
            this.btnhome3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnhome3.BackgroundImage")));
            this.btnhome3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnhome3.Location = new System.Drawing.Point(846, 654);
            this.btnhome3.Name = "btnhome3";
            this.btnhome3.Size = new System.Drawing.Size(35, 32);
            this.btnhome3.TabIndex = 14;
            this.btnhome3.UseVisualStyleBackColor = true;
            // 
            // pichome3
            // 
            this.pichome3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pichome3.BackgroundImage")));
            this.pichome3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pichome3.Location = new System.Drawing.Point(852, 19);
            this.pichome3.Name = "pichome3";
            this.pichome3.Size = new System.Drawing.Size(35, 35);
            this.pichome3.TabIndex = 13;
            this.pichome3.TabStop = false;
            // 
            // llbhome3
            // 
            this.llbhome3.AutoSize = true;
            this.llbhome3.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbhome3.LinkColor = System.Drawing.Color.Cyan;
            this.llbhome3.Location = new System.Drawing.Point(893, 19);
            this.llbhome3.Name = "llbhome3";
            this.llbhome3.Size = new System.Drawing.Size(53, 19);
            this.llbhome3.TabIndex = 12;
            this.llbhome3.TabStop = true;
            this.llbhome3.Text = "Home";
            this.llbhome3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbhome3_LinkClicked);
            // 
            // dgvDeptDetails
            // 
            this.dgvDeptDetails.BackgroundColor = System.Drawing.Color.SaddleBrown;
            this.dgvDeptDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDeptDetails.Location = new System.Drawing.Point(79, 147);
            this.dgvDeptDetails.Name = "dgvDeptDetails";
            this.dgvDeptDetails.Size = new System.Drawing.Size(792, 411);
            this.dgvDeptDetails.TabIndex = 4;
            // 
            // txtDeptName
            // 
            this.txtDeptName.Location = new System.Drawing.Point(489, 101);
            this.txtDeptName.Name = "txtDeptName";
            this.txtDeptName.Size = new System.Drawing.Size(164, 26);
            this.txtDeptName.TabIndex = 3;
            // 
            // txtDeptId
            // 
            this.txtDeptId.Location = new System.Drawing.Point(489, 65);
            this.txtDeptId.Name = "txtDeptId";
            this.txtDeptId.Size = new System.Drawing.Size(164, 26);
            this.txtDeptId.TabIndex = 2;
            // 
            // lblDeptName
            // 
            this.lblDeptName.AutoSize = true;
            this.lblDeptName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDeptName.Location = new System.Drawing.Point(325, 108);
            this.lblDeptName.Name = "lblDeptName";
            this.lblDeptName.Size = new System.Drawing.Size(142, 19);
            this.lblDeptName.TabIndex = 1;
            this.lblDeptName.Text = "Department Name :";
            // 
            // lblDeptId
            // 
            this.lblDeptId.AutoSize = true;
            this.lblDeptId.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDeptId.Location = new System.Drawing.Point(325, 68);
            this.lblDeptId.Name = "lblDeptId";
            this.lblDeptId.Size = new System.Drawing.Size(120, 19);
            this.lblDeptId.TabIndex = 0;
            this.lblDeptId.Text = "Department ID :";
            // 
            // tabPgAddEmp
            // 
            this.tabPgAddEmp.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPgAddEmp.BackgroundImage")));
            this.tabPgAddEmp.Controls.Add(this.btnSearchEmpId);
            this.tabPgAddEmp.Controls.Add(this.groupBox1);
            this.tabPgAddEmp.Controls.Add(this.llbLogOut2);
            this.tabPgAddEmp.Controls.Add(this.btnlogout2);
            this.tabPgAddEmp.Controls.Add(this.txtEmplyId);
            this.tabPgAddEmp.Controls.Add(this.lblEmplyID);
            this.tabPgAddEmp.Controls.Add(this.btndeleteEmp);
            this.tabPgAddEmp.Controls.Add(this.btnUpdateEmp);
            this.tabPgAddEmp.Controls.Add(this.btnaddemp);
            this.tabPgAddEmp.Controls.Add(this.cmbgrade);
            this.tabPgAddEmp.Controls.Add(this.cmbdept);
            this.tabPgAddEmp.Controls.Add(this.cmbdesg);
            this.tabPgAddEmp.Controls.Add(this.cmbMStuts);
            this.tabPgAddEmp.Controls.Add(this.cmbgender);
            this.tabPgAddEmp.Controls.Add(this.dtpDOJ);
            this.tabPgAddEmp.Controls.Add(this.dtpDOB);
            this.tabPgAddEmp.Controls.Add(this.txtFrstnme);
            this.tabPgAddEmp.Controls.Add(this.txtmgr);
            this.tabPgAddEmp.Controls.Add(this.txtPhnNumbr);
            this.tabPgAddEmp.Controls.Add(this.txtsal);
            this.tabPgAddEmp.Controls.Add(this.txtaddrss);
            this.tabPgAddEmp.Controls.Add(this.txtLstnme);
            this.tabPgAddEmp.Controls.Add(this.lblGrdCode);
            this.tabPgAddEmp.Controls.Add(this.lblMgrId);
            this.tabPgAddEmp.Controls.Add(this.lblDpt);
            this.tabPgAddEmp.Controls.Add(this.lblDesg);
            this.tabPgAddEmp.Controls.Add(this.lblPhnNo);
            this.tabPgAddEmp.Controls.Add(this.lblSal);
            this.tabPgAddEmp.Controls.Add(this.lblMStatus);
            this.tabPgAddEmp.Controls.Add(this.lblAddrs);
            this.tabPgAddEmp.Controls.Add(this.lblgender);
            this.tabPgAddEmp.Controls.Add(this.lblDOJ);
            this.tabPgAddEmp.Controls.Add(this.lblDOB);
            this.tabPgAddEmp.Controls.Add(this.lblLstName);
            this.tabPgAddEmp.Controls.Add(this.lblFrstName);
            this.tabPgAddEmp.Controls.Add(this.pichome2);
            this.tabPgAddEmp.Controls.Add(this.llbhome2);
            this.tabPgAddEmp.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPgAddEmp.Location = new System.Drawing.Point(4, 24);
            this.tabPgAddEmp.Name = "tabPgAddEmp";
            this.tabPgAddEmp.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgAddEmp.Size = new System.Drawing.Size(963, 719);
            this.tabPgAddEmp.TabIndex = 1;
            this.tabPgAddEmp.Text = "Add Employee";
            this.tabPgAddEmp.UseVisualStyleBackColor = true;
            // 
            // btnSearchEmpId
            // 
            this.btnSearchEmpId.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSearchEmpId.BackgroundImage")));
            this.btnSearchEmpId.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSearchEmpId.Location = new System.Drawing.Point(639, 98);
            this.btnSearchEmpId.Name = "btnSearchEmpId";
            this.btnSearchEmpId.Size = new System.Drawing.Size(34, 36);
            this.btnSearchEmpId.TabIndex = 94;
            this.btnSearchEmpId.UseVisualStyleBackColor = true;
            this.btnSearchEmpId.Click += new System.EventHandler(this.btnSearchEmpId_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdAddEmp);
            this.groupBox1.Controls.Add(this.rdbtnDelete);
            this.groupBox1.Controls.Add(this.rdbtnUpdate);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox1.Location = new System.Drawing.Point(28, 20);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(473, 52);
            this.groupBox1.TabIndex = 93;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Choice";
            // 
            // rdAddEmp
            // 
            this.rdAddEmp.AutoSize = true;
            this.rdAddEmp.Location = new System.Drawing.Point(287, 21);
            this.rdAddEmp.Name = "rdAddEmp";
            this.rdAddEmp.Size = new System.Drawing.Size(122, 21);
            this.rdAddEmp.TabIndex = 3;
            this.rdAddEmp.TabStop = true;
            this.rdAddEmp.Text = "Add Employee";
            this.rdAddEmp.UseVisualStyleBackColor = true;
            this.rdAddEmp.CheckedChanged += new System.EventHandler(this.rdAddEmp_CheckedChanged);
            // 
            // rdbtnDelete
            // 
            this.rdbtnDelete.AutoSize = true;
            this.rdbtnDelete.Location = new System.Drawing.Point(144, 21);
            this.rdbtnDelete.Name = "rdbtnDelete";
            this.rdbtnDelete.Size = new System.Drawing.Size(120, 21);
            this.rdbtnDelete.TabIndex = 2;
            this.rdbtnDelete.TabStop = true;
            this.rdbtnDelete.Text = "Delete Details";
            this.rdbtnDelete.UseVisualStyleBackColor = true;
            this.rdbtnDelete.CheckedChanged += new System.EventHandler(this.rdbtnDelete_CheckedChanged);
            // 
            // rdbtnUpdate
            // 
            this.rdbtnUpdate.AutoSize = true;
            this.rdbtnUpdate.Location = new System.Drawing.Point(3, 21);
            this.rdbtnUpdate.Name = "rdbtnUpdate";
            this.rdbtnUpdate.Size = new System.Drawing.Size(123, 21);
            this.rdbtnUpdate.TabIndex = 0;
            this.rdbtnUpdate.TabStop = true;
            this.rdbtnUpdate.Text = "Update Details";
            this.rdbtnUpdate.UseVisualStyleBackColor = true;
            this.rdbtnUpdate.CheckedChanged += new System.EventHandler(this.rdbtnUpdate_CheckedChanged);
            // 
            // llbLogOut2
            // 
            this.llbLogOut2.AutoSize = true;
            this.llbLogOut2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbLogOut2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.llbLogOut2.Location = new System.Drawing.Point(875, 681);
            this.llbLogOut2.Name = "llbLogOut2";
            this.llbLogOut2.Size = new System.Drawing.Size(59, 17);
            this.llbLogOut2.TabIndex = 92;
            this.llbLogOut2.Text = "LogOut";
            // 
            // btnlogout2
            // 
            this.btnlogout2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnlogout2.BackgroundImage")));
            this.btnlogout2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnlogout2.Location = new System.Drawing.Point(835, 675);
            this.btnlogout2.Name = "btnlogout2";
            this.btnlogout2.Size = new System.Drawing.Size(34, 28);
            this.btnlogout2.TabIndex = 91;
            this.btnlogout2.UseVisualStyleBackColor = true;
            // 
            // txtEmplyId
            // 
            this.txtEmplyId.Location = new System.Drawing.Point(475, 105);
            this.txtEmplyId.Name = "txtEmplyId";
            this.txtEmplyId.Size = new System.Drawing.Size(176, 25);
            this.txtEmplyId.TabIndex = 84;
            // 
            // lblEmplyID
            // 
            this.lblEmplyID.AutoSize = true;
            this.lblEmplyID.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblEmplyID.Location = new System.Drawing.Point(353, 108);
            this.lblEmplyID.Name = "lblEmplyID";
            this.lblEmplyID.Size = new System.Drawing.Size(103, 17);
            this.lblEmplyID.TabIndex = 53;
            this.lblEmplyID.Text = "Employee ID :";
            // 
            // btndeleteEmp
            // 
            this.btndeleteEmp.Location = new System.Drawing.Point(718, 561);
            this.btndeleteEmp.Name = "btndeleteEmp";
            this.btndeleteEmp.Size = new System.Drawing.Size(170, 40);
            this.btndeleteEmp.TabIndex = 83;
            this.btndeleteEmp.Text = "Delete Employee";
            this.btndeleteEmp.UseVisualStyleBackColor = true;
            this.btndeleteEmp.Click += new System.EventHandler(this.btndeleteEmp_Click);
            // 
            // btnUpdateEmp
            // 
            this.btnUpdateEmp.Location = new System.Drawing.Point(413, 561);
            this.btnUpdateEmp.Name = "btnUpdateEmp";
            this.btnUpdateEmp.Size = new System.Drawing.Size(170, 40);
            this.btnUpdateEmp.TabIndex = 82;
            this.btnUpdateEmp.Text = "Update Employee";
            this.btnUpdateEmp.UseVisualStyleBackColor = true;
            this.btnUpdateEmp.Click += new System.EventHandler(this.btnUpdateEmp_Click);
            // 
            // btnaddemp
            // 
            this.btnaddemp.Location = new System.Drawing.Point(78, 561);
            this.btnaddemp.Name = "btnaddemp";
            this.btnaddemp.Size = new System.Drawing.Size(170, 40);
            this.btnaddemp.TabIndex = 81;
            this.btnaddemp.Text = "Add Employee";
            this.btnaddemp.UseVisualStyleBackColor = true;
            this.btnaddemp.Click += new System.EventHandler(this.btnaddemp_Click);
            // 
            // cmbgrade
            // 
            this.cmbgrade.FormattingEnabled = true;
            this.cmbgrade.Location = new System.Drawing.Point(688, 476);
            this.cmbgrade.Name = "cmbgrade";
            this.cmbgrade.Size = new System.Drawing.Size(148, 25);
            this.cmbgrade.TabIndex = 65;
            // 
            // cmbdept
            // 
            this.cmbdept.FormattingEnabled = true;
            this.cmbdept.Location = new System.Drawing.Point(215, 417);
            this.cmbdept.Name = "cmbdept";
            this.cmbdept.Size = new System.Drawing.Size(200, 25);
            this.cmbdept.TabIndex = 60;
            // 
            // cmbdesg
            // 
            this.cmbdesg.FormattingEnabled = true;
            this.cmbdesg.Location = new System.Drawing.Point(215, 358);
            this.cmbdesg.Name = "cmbdesg";
            this.cmbdesg.Size = new System.Drawing.Size(200, 25);
            this.cmbdesg.TabIndex = 58;
            // 
            // cmbMStuts
            // 
            this.cmbMStuts.FormattingEnabled = true;
            this.cmbMStuts.Location = new System.Drawing.Point(688, 335);
            this.cmbMStuts.Name = "cmbMStuts";
            this.cmbMStuts.Size = new System.Drawing.Size(148, 25);
            this.cmbMStuts.TabIndex = 59;
            // 
            // cmbgender
            // 
            this.cmbgender.FormattingEnabled = true;
            this.cmbgender.Location = new System.Drawing.Point(688, 381);
            this.cmbgender.Name = "cmbgender";
            this.cmbgender.Size = new System.Drawing.Size(148, 25);
            this.cmbgender.TabIndex = 61;
            // 
            // dtpDOJ
            // 
            this.dtpDOJ.Location = new System.Drawing.Point(688, 218);
            this.dtpDOJ.Name = "dtpDOJ";
            this.dtpDOJ.Size = new System.Drawing.Size(200, 25);
            this.dtpDOJ.TabIndex = 55;
            // 
            // dtpDOB
            // 
            this.dtpDOB.Location = new System.Drawing.Point(215, 224);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(200, 25);
            this.dtpDOB.TabIndex = 54;
            // 
            // txtFrstnme
            // 
            this.txtFrstnme.Location = new System.Drawing.Point(215, 168);
            this.txtFrstnme.Name = "txtFrstnme";
            this.txtFrstnme.Size = new System.Drawing.Size(200, 25);
            this.txtFrstnme.TabIndex = 51;
            // 
            // txtmgr
            // 
            this.txtmgr.Location = new System.Drawing.Point(215, 476);
            this.txtmgr.Name = "txtmgr";
            this.txtmgr.Size = new System.Drawing.Size(200, 25);
            this.txtmgr.TabIndex = 62;
            // 
            // txtPhnNumbr
            // 
            this.txtPhnNumbr.Location = new System.Drawing.Point(688, 270);
            this.txtPhnNumbr.Name = "txtPhnNumbr";
            this.txtPhnNumbr.Size = new System.Drawing.Size(200, 25);
            this.txtPhnNumbr.TabIndex = 57;
            // 
            // txtsal
            // 
            this.txtsal.Location = new System.Drawing.Point(688, 430);
            this.txtsal.Name = "txtsal";
            this.txtsal.Size = new System.Drawing.Size(148, 25);
            this.txtsal.TabIndex = 63;
            // 
            // txtaddrss
            // 
            this.txtaddrss.Location = new System.Drawing.Point(215, 275);
            this.txtaddrss.Multiline = true;
            this.txtaddrss.Name = "txtaddrss";
            this.txtaddrss.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtaddrss.Size = new System.Drawing.Size(200, 58);
            this.txtaddrss.TabIndex = 56;
            // 
            // txtLstnme
            // 
            this.txtLstnme.Location = new System.Drawing.Point(688, 168);
            this.txtLstnme.Name = "txtLstnme";
            this.txtLstnme.Size = new System.Drawing.Size(200, 25);
            this.txtLstnme.TabIndex = 52;
            // 
            // lblGrdCode
            // 
            this.lblGrdCode.AutoSize = true;
            this.lblGrdCode.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblGrdCode.Location = new System.Drawing.Point(536, 484);
            this.lblGrdCode.Name = "lblGrdCode";
            this.lblGrdCode.Size = new System.Drawing.Size(96, 17);
            this.lblGrdCode.TabIndex = 80;
            this.lblGrdCode.Text = "Grade Code :";
            // 
            // lblMgrId
            // 
            this.lblMgrId.AutoSize = true;
            this.lblMgrId.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblMgrId.Location = new System.Drawing.Point(74, 479);
            this.lblMgrId.Name = "lblMgrId";
            this.lblMgrId.Size = new System.Drawing.Size(115, 17);
            this.lblMgrId.TabIndex = 79;
            this.lblMgrId.Text = "Manager Code :";
            // 
            // lblDpt
            // 
            this.lblDpt.AutoSize = true;
            this.lblDpt.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDpt.Location = new System.Drawing.Point(74, 420);
            this.lblDpt.Name = "lblDpt";
            this.lblDpt.Size = new System.Drawing.Size(99, 17);
            this.lblDpt.TabIndex = 78;
            this.lblDpt.Text = "Department  :";
            // 
            // lblDesg
            // 
            this.lblDesg.AutoSize = true;
            this.lblDesg.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDesg.Location = new System.Drawing.Point(74, 361);
            this.lblDesg.Name = "lblDesg";
            this.lblDesg.Size = new System.Drawing.Size(95, 17);
            this.lblDesg.TabIndex = 77;
            this.lblDesg.Text = "Designation :";
            // 
            // lblPhnNo
            // 
            this.lblPhnNo.AutoSize = true;
            this.lblPhnNo.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblPhnNo.Location = new System.Drawing.Point(536, 278);
            this.lblPhnNo.Name = "lblPhnNo";
            this.lblPhnNo.Size = new System.Drawing.Size(115, 17);
            this.lblPhnNo.TabIndex = 76;
            this.lblPhnNo.Text = "Phone Number :";
            // 
            // lblSal
            // 
            this.lblSal.AutoSize = true;
            this.lblSal.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSal.Location = new System.Drawing.Point(537, 438);
            this.lblSal.Name = "lblSal";
            this.lblSal.Size = new System.Drawing.Size(56, 17);
            this.lblSal.TabIndex = 75;
            this.lblSal.Text = "Salary :";
            // 
            // lblMStatus
            // 
            this.lblMStatus.AutoSize = true;
            this.lblMStatus.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblMStatus.Location = new System.Drawing.Point(537, 343);
            this.lblMStatus.Name = "lblMStatus";
            this.lblMStatus.Size = new System.Drawing.Size(109, 17);
            this.lblMStatus.TabIndex = 74;
            this.lblMStatus.Text = "Marital Status :";
            // 
            // lblAddrs
            // 
            this.lblAddrs.AutoSize = true;
            this.lblAddrs.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblAddrs.Location = new System.Drawing.Point(74, 278);
            this.lblAddrs.Name = "lblAddrs";
            this.lblAddrs.Size = new System.Drawing.Size(72, 17);
            this.lblAddrs.TabIndex = 73;
            this.lblAddrs.Text = "Address :";
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblgender.Location = new System.Drawing.Point(536, 389);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(66, 17);
            this.lblgender.TabIndex = 72;
            this.lblgender.Text = "Gender :";
            // 
            // lblDOJ
            // 
            this.lblDOJ.AutoSize = true;
            this.lblDOJ.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDOJ.Location = new System.Drawing.Point(537, 224);
            this.lblDOJ.Name = "lblDOJ";
            this.lblDOJ.Size = new System.Drawing.Size(120, 17);
            this.lblDOJ.TabIndex = 71;
            this.lblDOJ.Text = "Date Of Joining :";
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDOB.Location = new System.Drawing.Point(74, 226);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(106, 17);
            this.lblDOB.TabIndex = 68;
            this.lblDOB.Text = "Date Of Birth :";
            // 
            // lblLstName
            // 
            this.lblLstName.AutoSize = true;
            this.lblLstName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblLstName.Location = new System.Drawing.Point(536, 176);
            this.lblLstName.Name = "lblLstName";
            this.lblLstName.Size = new System.Drawing.Size(88, 17);
            this.lblLstName.TabIndex = 66;
            this.lblLstName.Text = "Last Name :";
            // 
            // lblFrstName
            // 
            this.lblFrstName.AutoSize = true;
            this.lblFrstName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFrstName.Location = new System.Drawing.Point(74, 176);
            this.lblFrstName.Name = "lblFrstName";
            this.lblFrstName.Size = new System.Drawing.Size(90, 17);
            this.lblFrstName.TabIndex = 64;
            this.lblFrstName.Text = "First Name :";
            // 
            // pichome2
            // 
            this.pichome2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pichome2.BackgroundImage")));
            this.pichome2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pichome2.Location = new System.Drawing.Point(853, 17);
            this.pichome2.Name = "pichome2";
            this.pichome2.Size = new System.Drawing.Size(35, 35);
            this.pichome2.TabIndex = 9;
            this.pichome2.TabStop = false;
            // 
            // llbhome2
            // 
            this.llbhome2.AutoSize = true;
            this.llbhome2.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbhome2.LinkColor = System.Drawing.Color.Cyan;
            this.llbhome2.Location = new System.Drawing.Point(894, 17);
            this.llbhome2.Name = "llbhome2";
            this.llbhome2.Size = new System.Drawing.Size(53, 19);
            this.llbhome2.TabIndex = 8;
            this.llbhome2.TabStop = true;
            this.llbhome2.Text = "Home";
            this.llbhome2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbhome2_LinkClicked);
            // 
            // tabPgViewEmp
            // 
            this.tabPgViewEmp.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPgViewEmp.BackgroundImage")));
            this.tabPgViewEmp.Controls.Add(this.lblLogOut1);
            this.tabPgViewEmp.Controls.Add(this.btnlogoff1);
            this.tabPgViewEmp.Controls.Add(this.btnDisplay);
            this.tabPgViewEmp.Controls.Add(this.pichome1);
            this.tabPgViewEmp.Controls.Add(this.llbhome1);
            this.tabPgViewEmp.Controls.Add(this.dgvEmpDetails);
            this.tabPgViewEmp.Controls.Add(this.btnSearch);
            this.tabPgViewEmp.Controls.Add(this.txtEmpId);
            this.tabPgViewEmp.Controls.Add(this.lblEmpId);
            this.tabPgViewEmp.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPgViewEmp.Location = new System.Drawing.Point(4, 24);
            this.tabPgViewEmp.Name = "tabPgViewEmp";
            this.tabPgViewEmp.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgViewEmp.Size = new System.Drawing.Size(963, 719);
            this.tabPgViewEmp.TabIndex = 0;
            this.tabPgViewEmp.Text = "View Employee";
            this.tabPgViewEmp.UseVisualStyleBackColor = true;
            // 
            // lblLogOut1
            // 
            this.lblLogOut1.AutoSize = true;
            this.lblLogOut1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogOut1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblLogOut1.Location = new System.Drawing.Point(880, 669);
            this.lblLogOut1.Name = "lblLogOut1";
            this.lblLogOut1.Size = new System.Drawing.Size(59, 17);
            this.lblLogOut1.TabIndex = 86;
            this.lblLogOut1.Text = "LogOut";
            // 
            // btnlogoff1
            // 
            this.btnlogoff1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnlogoff1.BackgroundImage")));
            this.btnlogoff1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnlogoff1.Location = new System.Drawing.Point(840, 663);
            this.btnlogoff1.Name = "btnlogoff1";
            this.btnlogoff1.Size = new System.Drawing.Size(34, 28);
            this.btnlogoff1.TabIndex = 10;
            this.btnlogoff1.UseVisualStyleBackColor = true;
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(33, 57);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(212, 33);
            this.btnDisplay.TabIndex = 9;
            this.btnDisplay.Text = "Display Employee";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // pichome1
            // 
            this.pichome1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pichome1.BackgroundImage")));
            this.pichome1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pichome1.Location = new System.Drawing.Point(843, 16);
            this.pichome1.Name = "pichome1";
            this.pichome1.Size = new System.Drawing.Size(34, 35);
            this.pichome1.TabIndex = 7;
            this.pichome1.TabStop = false;
            // 
            // llbhome1
            // 
            this.llbhome1.AutoSize = true;
            this.llbhome1.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Bold);
            this.llbhome1.LinkColor = System.Drawing.Color.Cyan;
            this.llbhome1.Location = new System.Drawing.Point(883, 18);
            this.llbhome1.Name = "llbhome1";
            this.llbhome1.Size = new System.Drawing.Size(56, 20);
            this.llbhome1.TabIndex = 6;
            this.llbhome1.TabStop = true;
            this.llbhome1.Text = "Home";
            this.llbhome1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbhome1_LinkClicked);
            // 
            // dgvEmpDetails
            // 
            this.dgvEmpDetails.BackgroundColor = System.Drawing.Color.SaddleBrown;
            this.dgvEmpDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmpDetails.GridColor = System.Drawing.Color.DarkRed;
            this.dgvEmpDetails.Location = new System.Drawing.Point(33, 135);
            this.dgvEmpDetails.Name = "dgvEmpDetails";
            this.dgvEmpDetails.Size = new System.Drawing.Size(891, 488);
            this.dgvEmpDetails.TabIndex = 3;
            // 
            // btnSearch
            // 
            this.btnSearch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSearch.BackgroundImage")));
            this.btnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSearch.Location = new System.Drawing.Point(905, 55);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(34, 36);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtEmpId
            // 
            this.txtEmpId.Location = new System.Drawing.Point(683, 57);
            this.txtEmpId.Name = "txtEmpId";
            this.txtEmpId.Size = new System.Drawing.Size(216, 29);
            this.txtEmpId.TabIndex = 1;
            // 
            // lblEmpId
            // 
            this.lblEmpId.AutoSize = true;
            this.lblEmpId.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmpId.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblEmpId.Location = new System.Drawing.Point(571, 62);
            this.lblEmpId.Name = "lblEmpId";
            this.lblEmpId.Size = new System.Drawing.Size(106, 19);
            this.lblEmpId.TabIndex = 0;
            this.lblEmpId.Text = "Employee ID :";
            // 
            // tbAdminActivity
            // 
            this.tbAdminActivity.Controls.Add(this.tabPgViewEmp);
            this.tbAdminActivity.Controls.Add(this.tabPgAddEmp);
            this.tbAdminActivity.Controls.Add(this.tabPgdept);
            this.tbAdminActivity.Controls.Add(this.tabPgProj);
            this.tbAdminActivity.Controls.Add(this.tabPgTimeSheet);
            this.tbAdminActivity.Controls.Add(this.tplogindetails);
            this.tbAdminActivity.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbAdminActivity.ItemSize = new System.Drawing.Size(84, 20);
            this.tbAdminActivity.Location = new System.Drawing.Point(0, 0);
            this.tbAdminActivity.Name = "tbAdminActivity";
            this.tbAdminActivity.SelectedIndex = 0;
            this.tbAdminActivity.Size = new System.Drawing.Size(971, 747);
            this.tbAdminActivity.TabIndex = 0;
            // 
            // tplogindetails
            // 
            this.tplogindetails.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tplogindetails.BackgroundImage")));
            this.tplogindetails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tplogindetails.Controls.Add(this.lbllogout6);
            this.tplogindetails.Controls.Add(this.btnLogoff6);
            this.tplogindetails.Controls.Add(this.pchome6);
            this.tplogindetails.Controls.Add(this.llbhome6);
            this.tplogindetails.Controls.Add(this.txtEmplogin);
            this.tplogindetails.Controls.Add(this.label1);
            this.tplogindetails.Controls.Add(this.btnCreatelogin);
            this.tplogindetails.Controls.Add(this.txtusrnme);
            this.tplogindetails.Controls.Add(this.lblusrnme);
            this.tplogindetails.Controls.Add(this.txtpswd);
            this.tplogindetails.Controls.Add(this.lblpswd);
            this.tplogindetails.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tplogindetails.Location = new System.Drawing.Point(4, 24);
            this.tplogindetails.Name = "tplogindetails";
            this.tplogindetails.Padding = new System.Windows.Forms.Padding(3);
            this.tplogindetails.Size = new System.Drawing.Size(963, 719);
            this.tplogindetails.TabIndex = 6;
            this.tplogindetails.Text = "Create Login";
            this.tplogindetails.UseVisualStyleBackColor = true;
            // 
            // lbllogout6
            // 
            this.lbllogout6.AutoSize = true;
            this.lbllogout6.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllogout6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbllogout6.Location = new System.Drawing.Point(885, 667);
            this.lbllogout6.Name = "lbllogout6";
            this.lbllogout6.Size = new System.Drawing.Size(59, 17);
            this.lbllogout6.TabIndex = 98;
            this.lbllogout6.Text = "LogOut";
            // 
            // btnLogoff6
            // 
            this.btnLogoff6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLogoff6.BackgroundImage")));
            this.btnLogoff6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLogoff6.Location = new System.Drawing.Point(850, 659);
            this.btnLogoff6.Name = "btnLogoff6";
            this.btnLogoff6.Size = new System.Drawing.Size(35, 33);
            this.btnLogoff6.TabIndex = 97;
            this.btnLogoff6.UseVisualStyleBackColor = true;
            // 
            // pchome6
            // 
            this.pchome6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pchome6.BackgroundImage")));
            this.pchome6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pchome6.Location = new System.Drawing.Point(850, 24);
            this.pchome6.Name = "pchome6";
            this.pchome6.Size = new System.Drawing.Size(35, 35);
            this.pchome6.TabIndex = 96;
            this.pchome6.TabStop = false;
            // 
            // llbhome6
            // 
            this.llbhome6.AutoSize = true;
            this.llbhome6.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbhome6.LinkColor = System.Drawing.Color.Cyan;
            this.llbhome6.Location = new System.Drawing.Point(891, 24);
            this.llbhome6.Name = "llbhome6";
            this.llbhome6.Size = new System.Drawing.Size(53, 19);
            this.llbhome6.TabIndex = 95;
            this.llbhome6.TabStop = true;
            this.llbhome6.Text = "Home";
            // 
            // txtEmplogin
            // 
            this.txtEmplogin.Location = new System.Drawing.Point(441, 110);
            this.txtEmplogin.Name = "txtEmplogin";
            this.txtEmplogin.Size = new System.Drawing.Size(200, 26);
            this.txtEmplogin.TabIndex = 94;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(296, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 19);
            this.label1.TabIndex = 93;
            this.label1.Text = "Employee ID :";
            // 
            // btnCreatelogin
            // 
            this.btnCreatelogin.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnCreatelogin.Location = new System.Drawing.Point(369, 291);
            this.btnCreatelogin.Name = "btnCreatelogin";
            this.btnCreatelogin.Size = new System.Drawing.Size(125, 34);
            this.btnCreatelogin.TabIndex = 92;
            this.btnCreatelogin.Text = "Create";
            this.btnCreatelogin.UseVisualStyleBackColor = true;
            this.btnCreatelogin.Click += new System.EventHandler(this.btnCreatelogin_Click);
            // 
            // txtusrnme
            // 
            this.txtusrnme.Location = new System.Drawing.Point(441, 163);
            this.txtusrnme.Name = "txtusrnme";
            this.txtusrnme.Size = new System.Drawing.Size(200, 26);
            this.txtusrnme.TabIndex = 88;
            // 
            // lblusrnme
            // 
            this.lblusrnme.AutoSize = true;
            this.lblusrnme.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblusrnme.Location = new System.Drawing.Point(296, 166);
            this.lblusrnme.Name = "lblusrnme";
            this.lblusrnme.Size = new System.Drawing.Size(94, 19);
            this.lblusrnme.TabIndex = 90;
            this.lblusrnme.Text = "User Name :";
            // 
            // txtpswd
            // 
            this.txtpswd.Location = new System.Drawing.Point(441, 222);
            this.txtpswd.Name = "txtpswd";
            this.txtpswd.Size = new System.Drawing.Size(200, 26);
            this.txtpswd.TabIndex = 89;
            // 
            // lblpswd
            // 
            this.lblpswd.AutoSize = true;
            this.lblpswd.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblpswd.Location = new System.Drawing.Point(296, 225);
            this.lblpswd.Name = "lblpswd";
            this.lblpswd.Size = new System.Drawing.Size(81, 19);
            this.lblpswd.TabIndex = 91;
            this.lblpswd.Text = "Password :";
            // 
            // AdminActivityForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(994, 733);
            this.Controls.Add(this.tbAdminActivity);
            this.Name = "AdminActivityForm";
            this.Text = "AdminActivityForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.AdminActivityForm_Load);
            this.tabPgTimeSheet.ResumeLayout(false);
            this.tabPgTimeSheet.PerformLayout();
            this.gbAssignShift.ResumeLayout(false);
            this.gbAssignShift.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTymSheet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pichome5)).EndInit();
            this.tabPgProj.ResumeLayout(false);
            this.tabPgProj.PerformLayout();
            this.gbProjAssnmnt.ResumeLayout(false);
            this.gbProjAssnmnt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProjDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pichome4)).EndInit();
            this.tabPgdept.ResumeLayout(false);
            this.tabPgdept.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pichome3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeptDetails)).EndInit();
            this.tabPgAddEmp.ResumeLayout(false);
            this.tabPgAddEmp.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pichome2)).EndInit();
            this.tabPgViewEmp.ResumeLayout(false);
            this.tabPgViewEmp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pichome1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpDetails)).EndInit();
            this.tbAdminActivity.ResumeLayout(false);
            this.tplogindetails.ResumeLayout(false);
            this.tplogindetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pchome6)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPgTimeSheet;
        private System.Windows.Forms.Button btnlogoff5;
        private System.Windows.Forms.PictureBox pichome5;
        private System.Windows.Forms.LinkLabel llbhome5;
        private System.Windows.Forms.TabPage tabPgProj;
        private System.Windows.Forms.Button btnlogoff4;
        private System.Windows.Forms.PictureBox pichome4;
        private System.Windows.Forms.LinkLabel llbhome4;
        private System.Windows.Forms.TabPage tabPgdept;
        private System.Windows.Forms.Button btnhome3;
        private System.Windows.Forms.PictureBox pichome3;
        private System.Windows.Forms.LinkLabel llbhome3;
        private System.Windows.Forms.DataGridView dgvDeptDetails;
        private System.Windows.Forms.TextBox txtDeptName;
        private System.Windows.Forms.TextBox txtDeptId;
        private System.Windows.Forms.Label lblDeptName;
        private System.Windows.Forms.Label lblDeptId;
        private System.Windows.Forms.TabPage tabPgAddEmp;
        private System.Windows.Forms.PictureBox pichome2;
        private System.Windows.Forms.LinkLabel llbhome2;
        private System.Windows.Forms.TabPage tabPgViewEmp;
        private System.Windows.Forms.Button btnlogoff1;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.PictureBox pichome1;
        private System.Windows.Forms.LinkLabel llbhome1;
        private System.Windows.Forms.DataGridView dgvEmpDetails;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtEmpId;
        private System.Windows.Forms.Label lblEmpId;
        private System.Windows.Forms.TabControl tbAdminActivity;
        private System.Windows.Forms.Button btnAddProj;
        private System.Windows.Forms.Button btnViewProj;
        private System.Windows.Forms.DataGridView dgvProjDetails;
        private System.Windows.Forms.TextBox txtMgrCode;
        private System.Windows.Forms.TextBox txtClientCode;
        private System.Windows.Forms.TextBox txtProjName;
        private System.Windows.Forms.TextBox txtProjId;
        private System.Windows.Forms.Label lblMgrCode;
        private System.Windows.Forms.Label lblClientCode;
        private System.Windows.Forms.Label lblProjName;
        private System.Windows.Forms.Label lblProjId;
        private System.Windows.Forms.Button btnDeptDelete;
        private System.Windows.Forms.Button btnDeptAdd;
        private System.Windows.Forms.Button btnDeptDisplay;
        private System.Windows.Forms.Button btnDisplayTymSheet;
        private System.Windows.Forms.Button btnShftSearch;
        private System.Windows.Forms.TextBox txtTymEmpid;
        private System.Windows.Forms.Label lblTymEmpId;
        private System.Windows.Forms.DataGridView dgvTymSheet;
        private System.Windows.Forms.TextBox txtEmplyId;
        private System.Windows.Forms.Label lblEmplyID;
        private System.Windows.Forms.Button btndeleteEmp;
        private System.Windows.Forms.Button btnUpdateEmp;
        private System.Windows.Forms.Button btnaddemp;
        private System.Windows.Forms.ComboBox cmbgrade;
        private System.Windows.Forms.ComboBox cmbdept;
        private System.Windows.Forms.ComboBox cmbdesg;
        private System.Windows.Forms.ComboBox cmbMStuts;
        private System.Windows.Forms.ComboBox cmbgender;
        private System.Windows.Forms.DateTimePicker dtpDOJ;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.TextBox txtFrstnme;
        private System.Windows.Forms.TextBox txtmgr;
        private System.Windows.Forms.TextBox txtPhnNumbr;
        private System.Windows.Forms.TextBox txtsal;
        private System.Windows.Forms.TextBox txtaddrss;
        private System.Windows.Forms.TextBox txtLstnme;
        private System.Windows.Forms.Label lblGrdCode;
        private System.Windows.Forms.Label lblMgrId;
        private System.Windows.Forms.Label lblDpt;
        private System.Windows.Forms.Label lblDesg;
        private System.Windows.Forms.Label lblPhnNo;
        private System.Windows.Forms.Label lblSal;
        private System.Windows.Forms.Label lblMStatus;
        private System.Windows.Forms.Label lblAddrs;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.Label lblDOJ;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.Label lblLstName;
        private System.Windows.Forms.Label lblFrstName;
        private System.Windows.Forms.Label lblLogOut5;
        private System.Windows.Forms.Label lblLogOut4;
        private System.Windows.Forms.Label lblLogOut3;
        private System.Windows.Forms.Label llbLogOut2;
        private System.Windows.Forms.Button btnlogout2;
        private System.Windows.Forms.Label lblLogOut1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbtnDelete;
        private System.Windows.Forms.RadioButton rdbtnUpdate;
        private System.Windows.Forms.GroupBox gbProjAssnmnt;
        private System.Windows.Forms.Button btnProjAssnmnt;
        private System.Windows.Forms.TextBox txtemprojid;
        private System.Windows.Forms.Label lblempidproj;
        private System.Windows.Forms.TextBox txtprojtid;
        private System.Windows.Forms.Label lblproj;
        private System.Windows.Forms.TabPage tplogindetails;
        private System.Windows.Forms.TextBox txtEmplogin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCreatelogin;
        private System.Windows.Forms.TextBox txtusrnme;
        private System.Windows.Forms.Label lblusrnme;
        private System.Windows.Forms.TextBox txtpswd;
        private System.Windows.Forms.Label lblpswd;
        private System.Windows.Forms.Button btnSearchEmpId;
        private System.Windows.Forms.RadioButton rdAddEmp;
        private System.Windows.Forms.GroupBox gbAssignShift;
        private System.Windows.Forms.Button btnUpdateShift;
        private System.Windows.Forms.Button btnAssignShift;
        private System.Windows.Forms.TextBox txtEmpIdTymSht;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtShftIDTymShft;
        private System.Windows.Forms.Label lbShiftidTymSheet;
        private System.Windows.Forms.Label lbllogout6;
        private System.Windows.Forms.Button btnLogoff6;
        private System.Windows.Forms.PictureBox pchome6;
        private System.Windows.Forms.LinkLabel llbhome6;





    }
}