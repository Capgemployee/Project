﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;


namespace EMS.PL
{
    public partial class EmployeeActivityForm : Form
    {
        EmployeeValidation validateEmp = new EmployeeValidation();
        public EmployeeActivityForm()
        {
            InitializeComponent();
        }

        private void EmployeeActivityForm_Load(object sender, EventArgs e)
        {
            tabControl1.Height = this.Height;
            tabControl1.Width = this.Width;
        }

        private void llbEmpHome4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            WelcomePage welpg = new WelcomePage();
            welpg.Show();
        }

        private void llbEmpHome3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            WelcomePage welpg = new WelcomePage();
            welpg.Show();
        }

        private void llbEmpHome2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            WelcomePage welpg = new WelcomePage();
            welpg.Show();
        }

        private void llbhome1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            WelcomePage welpg = new WelcomePage();
            welpg.Show();
        }

        private void btnlogoff1_Click(object sender, EventArgs e)
        {
            this.Hide();
            EmployeeLogin emplgin = new EmployeeLogin();
            emplgin.Show();
        }

        private void btnLogOff2_Click(object sender, EventArgs e)
        {
            this.Hide();
            EmployeeLogin emplgin = new EmployeeLogin();
            emplgin.Show();
        }

        private void btnLogOff3_Click(object sender, EventArgs e)
        {
            this.Hide();
            EmployeeLogin emplgin = new EmployeeLogin();
            emplgin.Show();
        }

        private void btnLogOff4_Click(object sender, EventArgs e)
        {
            this.Hide();
            EmployeeLogin emplgin = new EmployeeLogin();
            emplgin.Show();
        }

        //-----------------------------Project Details------------------------------------
        //View Project details
        private void btnViewProj_Click(object sender, EventArgs e)
        {

            DataTable projTable = new DataTable();
            projTable = validateEmp.SearchProjDetails(projID);
            dgvProject.DataSource = projTable;
        }
        //------------------------------Employee Profile----------------------------------
        //View Profile
        private void btnView_Click(object sender, EventArgs e)
        {
            DataTable tbemp = new DataTable();
            int id = Convert.ToInt32(txtEID.Text);
            tbemp = validateEmp.GetEmployeeDetails(id);

            txtFrstnme.Text = tbemp.Rows[0]["FirstName"].ToString();
            txtLstnme.Text = tbemp.Rows[0]["LastName"].ToString();
            //dtpDOB.Text = tbemp.Rows[0]["DateOfBirth"].ToString();
            //dtpDOJ.Text = tbemp.Rows[0][3].ToString();
            //cmbgender.Text = tbemp.Rows[0][4].ToString();
            //txtaddrss.Text = tbemp.Rows[0][5].ToString();
            //cmbMStuts.Text = tbemp.Rows[0]["6"].ToString();
            //txtsal.Text = tbemp.Rows[0]["8"].ToString();
            //txtPhnNumbr.Text = tbemp.Rows[0]["9"].ToString();
            // cmbdesg.Text = tbemp.Rows[0][1].ToString();
            //cmbdept.Text = tbemp.Rows[0][3].ToString();
            //txtMgrCode.Text = tbemp.Rows[0]["GradeCode"].ToString();
        }

        //Update Employee Details
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Employee emp = new Employee();
                bool isNumber;
                long contactNo;

                emp.EmployeeID = Convert.ToInt32(txtemplyid.Text);
                emp.FirstName = txtFrstnme.Text;
                emp.LastName = txtLstnme.Text;
                emp.DOB = Convert.ToDateTime(textDOB.Text);
                emp.DOJ = Convert.ToDateTime(textDOJ.Text);
                emp.Gender = cmbgender.Text;
                emp.Address = txtaddrss.Text;
                emp.MaritalStatus = cmbMStuts.Text;
                emp.Salary = Convert.ToInt32(txtsal.Text);
                emp.ManagerID = Convert.ToInt32(txtmgr.Text);
                emp.DepartmentID = Convert.ToInt32(cmbdept.Text);
                emp.DesignationID = cmbdesg.Text;
                emp.GradeCode = cmbgrade.Text;

                isNumber = long.TryParse(txtphnnumbr.Text, out contactNo);
                if (isNumber)
                    emp.PhoneNo = contactNo;
                else
                {
                    MessageBox.Show("Please enter only numbers in Conatct No field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }


                bool empUpdated = validateEmp.UpdateEmployee(emp);
                if (empUpdated)
                {
                    MessageBox.Show("Employee Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtFrstnme.Clear();
                    txtLstnme.Clear();
                    txtaddrss.Clear();
                    txtsal.Clear();
                    txtmgr.Clear();
                }
                else
                    MessageBox.Show("Failed to Update Employee record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //----------------------------TimeSheet Management------------------------------------
        //View Tym Shift Details
        private void btnViewTymSheet_Click(object sender, EventArgs e)
        {
            DataTable tbemp = new DataTable();
            int id = Convert.ToInt32(txtEID.Text);
            tbemp = validateEmp.ViewEmpShift(id);

            txtShiftId.Text = tbemp.Rows[0]["ShiftID"].ToString();
            txtShftName.Text = tbemp.Rows[0]["ShiftName"].ToString();
        }

        //-------------------------------Search Employee------------------------------------
        //View Details of Other Employee
        private void btnViewEmp_Click(object sender, EventArgs e)
        {
            DataTable tbemp = new DataTable();
            int id = Convert.ToInt32(txtEID.Text);
            tbemp = validateEmp.SearchEmployeeDetails(id);

            txtEmpName.Text = tbemp.Rows[0]["FirstName"].ToString();
            textDesig.Text = tbemp.Rows[0]["DesigCode"].ToString();
            textDept.Text = tbemp.Rows[0]["DeptID"].ToString();
            
        }



    }
}
