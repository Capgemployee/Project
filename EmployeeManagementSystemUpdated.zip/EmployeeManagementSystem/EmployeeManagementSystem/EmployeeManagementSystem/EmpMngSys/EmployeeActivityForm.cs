﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpMngSys
{
    public partial class EmployeeActivityForm : Form
    {
        public EmployeeActivityForm()
        {
            InitializeComponent();
        }

        private void EmployeeActivityForm_Load(object sender, EventArgs e)
        {
            tabControl1.Height = this.Height;
            tabControl1.Width = this.Width;
        }

        private void btnView_Click(object sender, EventArgs e)
        {

        }

        private void llbEmpHome4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            WelcomePage welpg = new WelcomePage();
            welpg.Show();
        }

        private void llbEmpHome3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            WelcomePage welpg = new WelcomePage();
            welpg.Show();
        }

        private void llbEmpHome2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            WelcomePage welpg = new WelcomePage();
            welpg.Show();
        }

        private void llbhome1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            WelcomePage welpg = new WelcomePage();
            welpg.Show();
        }

        private void dtptymIn_ValueChanged(object sender, EventArgs e)
        {
            dtptymIn.ShowUpDown = true;
            dtptymIn.CustomFormat = "hh:mm";
            dtptymIn.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
        }

        private void dtptymOut_ValueChanged(object sender, EventArgs e)
        {
            dtptymOut.ShowUpDown = true;
            dtptymOut.CustomFormat = "hh:mm";
            dtptymOut.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
        }


    }
}
