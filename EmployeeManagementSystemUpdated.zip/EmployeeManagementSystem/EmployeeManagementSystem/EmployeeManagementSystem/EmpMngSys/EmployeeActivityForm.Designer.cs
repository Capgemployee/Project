﻿namespace EmpMngSys
{
    partial class EmployeeActivityForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeActivityForm));
            this.tabPgViewProfile = new System.Windows.Forms.TabPage();
            this.lblLogOut1 = new System.Windows.Forms.Label();
            this.btnlogoff1 = new System.Windows.Forms.Button();
            this.pichome1 = new System.Windows.Forms.PictureBox();
            this.llbhome1 = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtemplyid = new System.Windows.Forms.TextBox();
            this.txtFrstnme = new System.Windows.Forms.TextBox();
            this.txtmgr = new System.Windows.Forms.TextBox();
            this.txtphnnumbr = new System.Windows.Forms.TextBox();
            this.txtsal = new System.Windows.Forms.TextBox();
            this.txtaddrss = new System.Windows.Forms.TextBox();
            this.txtLstnme = new System.Windows.Forms.TextBox();
            this.lblEmplyID = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnView = new System.Windows.Forms.Button();
            this.cmbgrade = new System.Windows.Forms.ComboBox();
            this.cmbdept = new System.Windows.Forms.ComboBox();
            this.cmbdesg = new System.Windows.Forms.ComboBox();
            this.cmbMStuts = new System.Windows.Forms.ComboBox();
            this.cmbgender = new System.Windows.Forms.ComboBox();
            this.dtpDOJ = new System.Windows.Forms.DateTimePicker();
            this.dtpDOB = new System.Windows.Forms.DateTimePicker();
            this.lblGrdCode = new System.Windows.Forms.Label();
            this.lblMgrId = new System.Windows.Forms.Label();
            this.lblDpt = new System.Windows.Forms.Label();
            this.lblDesg = new System.Windows.Forms.Label();
            this.lblPhnNo = new System.Windows.Forms.Label();
            this.lblSal = new System.Windows.Forms.Label();
            this.lblMStatus = new System.Windows.Forms.Label();
            this.lblAddrs = new System.Windows.Forms.Label();
            this.lblgender = new System.Windows.Forms.Label();
            this.lblDOJ = new System.Windows.Forms.Label();
            this.lblDOB = new System.Windows.Forms.Label();
            this.lblLstName = new System.Windows.Forms.Label();
            this.lblFrstName = new System.Windows.Forms.Label();
            this.llbhome2 = new System.Windows.Forms.LinkLabel();
            this.btnViewEmp = new System.Windows.Forms.Button();
            this.cmbDep = new System.Windows.Forms.ComboBox();
            this.cmbDesig = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lblDesig = new System.Windows.Forms.Label();
            this.txtEmpName = new System.Windows.Forms.TextBox();
            this.lblEmpname = new System.Windows.Forms.Label();
            this.txtEID = new System.Windows.Forms.TextBox();
            this.tabPgSearchEmp = new System.Windows.Forms.TabPage();
            this.lblLogOut4 = new System.Windows.Forms.Label();
            this.btnLogOff4 = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.llbEmpHome4 = new System.Windows.Forms.LinkLabel();
            this.lbEId = new System.Windows.Forms.Label();
            this.lblProjId = new System.Windows.Forms.Label();
            this.btnViewTymSheet = new System.Windows.Forms.Button();
            this.txtShiftId = new System.Windows.Forms.TextBox();
            this.tabPgTimeSheet = new System.Windows.Forms.TabPage();
            this.lblLogOut3 = new System.Windows.Forms.Label();
            this.btnLogOff3 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.llbEmpHome3 = new System.Windows.Forms.LinkLabel();
            this.lblShiftName = new System.Windows.Forms.Label();
            this.lblShiftId = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPgProject = new System.Windows.Forms.TabPage();
            this.lblLogOut2 = new System.Windows.Forms.Label();
            this.btnLogOff2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.llbEmpHome2 = new System.Windows.Forms.LinkLabel();
            this.btnViewProj = new System.Windows.Forms.Button();
            this.dgvProject = new System.Windows.Forms.DataGridView();
            this.txtEmployId = new System.Windows.Forms.TextBox();
            this.txtProjId = new System.Windows.Forms.TextBox();
            this.lblEmpld = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbShftname = new System.Windows.Forms.ComboBox();
            this.tabPgViewProfile.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pichome1)).BeginInit();
            this.tabPgSearchEmp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.tabPgTimeSheet.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPgProject.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProject)).BeginInit();
            this.SuspendLayout();
            // 
            // tabPgViewProfile
            // 
            this.tabPgViewProfile.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPgViewProfile.BackgroundImage")));
            this.tabPgViewProfile.Controls.Add(this.lblLogOut1);
            this.tabPgViewProfile.Controls.Add(this.btnlogoff1);
            this.tabPgViewProfile.Controls.Add(this.pichome1);
            this.tabPgViewProfile.Controls.Add(this.llbhome1);
            this.tabPgViewProfile.Controls.Add(this.label1);
            this.tabPgViewProfile.Controls.Add(this.txtemplyid);
            this.tabPgViewProfile.Controls.Add(this.txtFrstnme);
            this.tabPgViewProfile.Controls.Add(this.txtmgr);
            this.tabPgViewProfile.Controls.Add(this.txtphnnumbr);
            this.tabPgViewProfile.Controls.Add(this.txtsal);
            this.tabPgViewProfile.Controls.Add(this.txtaddrss);
            this.tabPgViewProfile.Controls.Add(this.txtLstnme);
            this.tabPgViewProfile.Controls.Add(this.lblEmplyID);
            this.tabPgViewProfile.Controls.Add(this.btnUpdate);
            this.tabPgViewProfile.Controls.Add(this.btnView);
            this.tabPgViewProfile.Controls.Add(this.cmbgrade);
            this.tabPgViewProfile.Controls.Add(this.cmbdept);
            this.tabPgViewProfile.Controls.Add(this.cmbdesg);
            this.tabPgViewProfile.Controls.Add(this.cmbMStuts);
            this.tabPgViewProfile.Controls.Add(this.cmbgender);
            this.tabPgViewProfile.Controls.Add(this.dtpDOJ);
            this.tabPgViewProfile.Controls.Add(this.dtpDOB);
            this.tabPgViewProfile.Controls.Add(this.lblGrdCode);
            this.tabPgViewProfile.Controls.Add(this.lblMgrId);
            this.tabPgViewProfile.Controls.Add(this.lblDpt);
            this.tabPgViewProfile.Controls.Add(this.lblDesg);
            this.tabPgViewProfile.Controls.Add(this.lblPhnNo);
            this.tabPgViewProfile.Controls.Add(this.lblSal);
            this.tabPgViewProfile.Controls.Add(this.lblMStatus);
            this.tabPgViewProfile.Controls.Add(this.lblAddrs);
            this.tabPgViewProfile.Controls.Add(this.lblgender);
            this.tabPgViewProfile.Controls.Add(this.lblDOJ);
            this.tabPgViewProfile.Controls.Add(this.lblDOB);
            this.tabPgViewProfile.Controls.Add(this.lblLstName);
            this.tabPgViewProfile.Controls.Add(this.lblFrstName);
            this.tabPgViewProfile.Controls.Add(this.llbhome2);
            this.tabPgViewProfile.Location = new System.Drawing.Point(4, 24);
            this.tabPgViewProfile.Name = "tabPgViewProfile";
            this.tabPgViewProfile.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgViewProfile.Size = new System.Drawing.Size(944, 703);
            this.tabPgViewProfile.TabIndex = 0;
            this.tabPgViewProfile.Text = "My Profile";
            this.tabPgViewProfile.UseVisualStyleBackColor = true;
            // 
            // lblLogOut1
            // 
            this.lblLogOut1.AutoSize = true;
            this.lblLogOut1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogOut1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblLogOut1.Location = new System.Drawing.Point(883, 653);
            this.lblLogOut1.Name = "lblLogOut1";
            this.lblLogOut1.Size = new System.Drawing.Size(59, 17);
            this.lblLogOut1.TabIndex = 90;
            this.lblLogOut1.Text = "LogOut";
            // 
            // btnlogoff1
            // 
            this.btnlogoff1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnlogoff1.BackgroundImage")));
            this.btnlogoff1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnlogoff1.Location = new System.Drawing.Point(843, 647);
            this.btnlogoff1.Name = "btnlogoff1";
            this.btnlogoff1.Size = new System.Drawing.Size(34, 28);
            this.btnlogoff1.TabIndex = 89;
            this.btnlogoff1.UseVisualStyleBackColor = true;
            // 
            // pichome1
            // 
            this.pichome1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pichome1.BackgroundImage")));
            this.pichome1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pichome1.Location = new System.Drawing.Point(846, 0);
            this.pichome1.Name = "pichome1";
            this.pichome1.Size = new System.Drawing.Size(34, 35);
            this.pichome1.TabIndex = 88;
            this.pichome1.TabStop = false;
            // 
            // llbhome1
            // 
            this.llbhome1.AutoSize = true;
            this.llbhome1.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Bold);
            this.llbhome1.LinkColor = System.Drawing.Color.Cyan;
            this.llbhome1.Location = new System.Drawing.Point(886, 2);
            this.llbhome1.Name = "llbhome1";
            this.llbhome1.Size = new System.Drawing.Size(56, 20);
            this.llbhome1.TabIndex = 87;
            this.llbhome1.TabStop = true;
            this.llbhome1.Text = "Home";
            this.llbhome1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbhome1_LinkClicked);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(645, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 19);
            this.label1.TabIndex = 80;
            // 
            // txtemplyid
            // 
            this.txtemplyid.Location = new System.Drawing.Point(482, 135);
            this.txtemplyid.Name = "txtemplyid";
            this.txtemplyid.Size = new System.Drawing.Size(176, 26);
            this.txtemplyid.TabIndex = 0;
            // 
            // txtFrstnme
            // 
            this.txtFrstnme.Location = new System.Drawing.Point(222, 196);
            this.txtFrstnme.Name = "txtFrstnme";
            this.txtFrstnme.Size = new System.Drawing.Size(200, 26);
            this.txtFrstnme.TabIndex = 1;
            // 
            // txtmgr
            // 
            this.txtmgr.Location = new System.Drawing.Point(222, 504);
            this.txtmgr.Name = "txtmgr";
            this.txtmgr.Size = new System.Drawing.Size(200, 26);
            this.txtmgr.TabIndex = 11;
            // 
            // txtphnnumbr
            // 
            this.txtphnnumbr.Location = new System.Drawing.Point(695, 298);
            this.txtphnnumbr.Name = "txtphnnumbr";
            this.txtphnnumbr.Size = new System.Drawing.Size(200, 26);
            this.txtphnnumbr.TabIndex = 6;
            // 
            // txtsal
            // 
            this.txtsal.Location = new System.Drawing.Point(695, 458);
            this.txtsal.Name = "txtsal";
            this.txtsal.Size = new System.Drawing.Size(148, 26);
            this.txtsal.TabIndex = 12;
            // 
            // txtaddrss
            // 
            this.txtaddrss.Location = new System.Drawing.Point(222, 298);
            this.txtaddrss.Multiline = true;
            this.txtaddrss.Name = "txtaddrss";
            this.txtaddrss.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtaddrss.Size = new System.Drawing.Size(200, 58);
            this.txtaddrss.TabIndex = 5;
            // 
            // txtLstnme
            // 
            this.txtLstnme.Location = new System.Drawing.Point(695, 196);
            this.txtLstnme.Name = "txtLstnme";
            this.txtLstnme.Size = new System.Drawing.Size(200, 26);
            this.txtLstnme.TabIndex = 2;
            // 
            // lblEmplyID
            // 
            this.lblEmplyID.AutoSize = true;
            this.lblEmplyID.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblEmplyID.Location = new System.Drawing.Point(360, 138);
            this.lblEmplyID.Name = "lblEmplyID";
            this.lblEmplyID.Size = new System.Drawing.Size(106, 19);
            this.lblEmplyID.TabIndex = 48;
            this.lblEmplyID.Text = "Employee ID :";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(510, 589);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(170, 40);
            this.btnUpdate.TabIndex = 15;
            this.btnUpdate.Text = "Update Details";
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnView
            // 
            this.btnView.Location = new System.Drawing.Point(224, 589);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(170, 40);
            this.btnView.TabIndex = 14;
            this.btnView.Text = "View Details";
            this.btnView.UseVisualStyleBackColor = true;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // cmbgrade
            // 
            this.cmbgrade.FormattingEnabled = true;
            this.cmbgrade.Location = new System.Drawing.Point(695, 504);
            this.cmbgrade.Name = "cmbgrade";
            this.cmbgrade.Size = new System.Drawing.Size(148, 27);
            this.cmbgrade.TabIndex = 13;
            // 
            // cmbdept
            // 
            this.cmbdept.FormattingEnabled = true;
            this.cmbdept.Location = new System.Drawing.Point(222, 445);
            this.cmbdept.Name = "cmbdept";
            this.cmbdept.Size = new System.Drawing.Size(200, 27);
            this.cmbdept.TabIndex = 9;
            // 
            // cmbdesg
            // 
            this.cmbdesg.FormattingEnabled = true;
            this.cmbdesg.Location = new System.Drawing.Point(222, 386);
            this.cmbdesg.Name = "cmbdesg";
            this.cmbdesg.Size = new System.Drawing.Size(200, 27);
            this.cmbdesg.TabIndex = 7;
            // 
            // cmbMStuts
            // 
            this.cmbMStuts.FormattingEnabled = true;
            this.cmbMStuts.Location = new System.Drawing.Point(695, 363);
            this.cmbMStuts.Name = "cmbMStuts";
            this.cmbMStuts.Size = new System.Drawing.Size(148, 27);
            this.cmbMStuts.TabIndex = 8;
            // 
            // cmbgender
            // 
            this.cmbgender.FormattingEnabled = true;
            this.cmbgender.Location = new System.Drawing.Point(695, 409);
            this.cmbgender.Name = "cmbgender";
            this.cmbgender.Size = new System.Drawing.Size(148, 27);
            this.cmbgender.TabIndex = 10;
            // 
            // dtpDOJ
            // 
            this.dtpDOJ.Location = new System.Drawing.Point(695, 246);
            this.dtpDOJ.Name = "dtpDOJ";
            this.dtpDOJ.Size = new System.Drawing.Size(200, 26);
            this.dtpDOJ.TabIndex = 4;
            // 
            // dtpDOB
            // 
            this.dtpDOB.Location = new System.Drawing.Point(222, 252);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(200, 26);
            this.dtpDOB.TabIndex = 3;
            // 
            // lblGrdCode
            // 
            this.lblGrdCode.AutoSize = true;
            this.lblGrdCode.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblGrdCode.Location = new System.Drawing.Point(543, 512);
            this.lblGrdCode.Name = "lblGrdCode";
            this.lblGrdCode.Size = new System.Drawing.Size(99, 19);
            this.lblGrdCode.TabIndex = 75;
            this.lblGrdCode.Text = "Grade Code :";
            // 
            // lblMgrId
            // 
            this.lblMgrId.AutoSize = true;
            this.lblMgrId.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblMgrId.Location = new System.Drawing.Point(81, 512);
            this.lblMgrId.Name = "lblMgrId";
            this.lblMgrId.Size = new System.Drawing.Size(119, 19);
            this.lblMgrId.TabIndex = 74;
            this.lblMgrId.Text = "Manager Code :";
            // 
            // lblDpt
            // 
            this.lblDpt.AutoSize = true;
            this.lblDpt.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDpt.Location = new System.Drawing.Point(81, 448);
            this.lblDpt.Name = "lblDpt";
            this.lblDpt.Size = new System.Drawing.Size(102, 19);
            this.lblDpt.TabIndex = 73;
            this.lblDpt.Text = "Department  :";
            // 
            // lblDesg
            // 
            this.lblDesg.AutoSize = true;
            this.lblDesg.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDesg.Location = new System.Drawing.Point(81, 397);
            this.lblDesg.Name = "lblDesg";
            this.lblDesg.Size = new System.Drawing.Size(98, 19);
            this.lblDesg.TabIndex = 72;
            this.lblDesg.Text = "Designation :";
            // 
            // lblPhnNo
            // 
            this.lblPhnNo.AutoSize = true;
            this.lblPhnNo.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblPhnNo.Location = new System.Drawing.Point(543, 306);
            this.lblPhnNo.Name = "lblPhnNo";
            this.lblPhnNo.Size = new System.Drawing.Size(117, 19);
            this.lblPhnNo.TabIndex = 71;
            this.lblPhnNo.Text = "Phone Number :";
            // 
            // lblSal
            // 
            this.lblSal.AutoSize = true;
            this.lblSal.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSal.Location = new System.Drawing.Point(544, 466);
            this.lblSal.Name = "lblSal";
            this.lblSal.Size = new System.Drawing.Size(61, 19);
            this.lblSal.TabIndex = 70;
            this.lblSal.Text = "Salary :";
            // 
            // lblMStatus
            // 
            this.lblMStatus.AutoSize = true;
            this.lblMStatus.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblMStatus.Location = new System.Drawing.Point(544, 371);
            this.lblMStatus.Name = "lblMStatus";
            this.lblMStatus.Size = new System.Drawing.Size(115, 19);
            this.lblMStatus.TabIndex = 69;
            this.lblMStatus.Text = "Marital Status :";
            // 
            // lblAddrs
            // 
            this.lblAddrs.AutoSize = true;
            this.lblAddrs.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblAddrs.Location = new System.Drawing.Point(81, 318);
            this.lblAddrs.Name = "lblAddrs";
            this.lblAddrs.Size = new System.Drawing.Size(73, 19);
            this.lblAddrs.TabIndex = 68;
            this.lblAddrs.Text = "Address :";
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblgender.Location = new System.Drawing.Point(543, 417);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(68, 19);
            this.lblgender.TabIndex = 67;
            this.lblgender.Text = "Gender :";
            // 
            // lblDOJ
            // 
            this.lblDOJ.AutoSize = true;
            this.lblDOJ.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDOJ.Location = new System.Drawing.Point(544, 252);
            this.lblDOJ.Name = "lblDOJ";
            this.lblDOJ.Size = new System.Drawing.Size(124, 19);
            this.lblDOJ.TabIndex = 66;
            this.lblDOJ.Text = "Date Of Joining :";
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDOB.Location = new System.Drawing.Point(81, 254);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(110, 19);
            this.lblDOB.TabIndex = 65;
            this.lblDOB.Text = "Date Of Birth :";
            // 
            // lblLstName
            // 
            this.lblLstName.AutoSize = true;
            this.lblLstName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblLstName.Location = new System.Drawing.Point(543, 204);
            this.lblLstName.Name = "lblLstName";
            this.lblLstName.Size = new System.Drawing.Size(92, 19);
            this.lblLstName.TabIndex = 64;
            this.lblLstName.Text = "Last Name :";
            // 
            // lblFrstName
            // 
            this.lblFrstName.AutoSize = true;
            this.lblFrstName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFrstName.Location = new System.Drawing.Point(81, 204);
            this.lblFrstName.Name = "lblFrstName";
            this.lblFrstName.Size = new System.Drawing.Size(93, 19);
            this.lblFrstName.TabIndex = 63;
            this.lblFrstName.Text = "First Name :";
            // 
            // llbhome2
            // 
            this.llbhome2.AutoSize = true;
            this.llbhome2.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbhome2.Location = new System.Drawing.Point(827, -20);
            this.llbhome2.Name = "llbhome2";
            this.llbhome2.Size = new System.Drawing.Size(53, 19);
            this.llbhome2.TabIndex = 56;
            this.llbhome2.TabStop = true;
            this.llbhome2.Text = "Home";
            // 
            // btnViewEmp
            // 
            this.btnViewEmp.Location = new System.Drawing.Point(356, 181);
            this.btnViewEmp.Name = "btnViewEmp";
            this.btnViewEmp.Size = new System.Drawing.Size(197, 38);
            this.btnViewEmp.TabIndex = 88;
            this.btnViewEmp.Text = "View Employee Details";
            this.btnViewEmp.UseVisualStyleBackColor = true;
            // 
            // cmbDep
            // 
            this.cmbDep.FormattingEnabled = true;
            this.cmbDep.Location = new System.Drawing.Point(411, 344);
            this.cmbDep.Name = "cmbDep";
            this.cmbDep.Size = new System.Drawing.Size(200, 27);
            this.cmbDep.TabIndex = 85;
            // 
            // cmbDesig
            // 
            this.cmbDesig.FormattingEnabled = true;
            this.cmbDesig.Location = new System.Drawing.Point(411, 294);
            this.cmbDesig.Name = "cmbDesig";
            this.cmbDesig.Size = new System.Drawing.Size(200, 27);
            this.cmbDesig.TabIndex = 84;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(261, 347);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 19);
            this.label6.TabIndex = 87;
            this.label6.Text = "Department  :";
            // 
            // lblDesig
            // 
            this.lblDesig.AutoSize = true;
            this.lblDesig.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDesig.Location = new System.Drawing.Point(261, 294);
            this.lblDesig.Name = "lblDesig";
            this.lblDesig.Size = new System.Drawing.Size(98, 19);
            this.lblDesig.TabIndex = 86;
            this.lblDesig.Text = "Designation :";
            // 
            // txtEmpName
            // 
            this.txtEmpName.Location = new System.Drawing.Point(411, 244);
            this.txtEmpName.Name = "txtEmpName";
            this.txtEmpName.Size = new System.Drawing.Size(200, 26);
            this.txtEmpName.TabIndex = 83;
            // 
            // lblEmpname
            // 
            this.lblEmpname.AutoSize = true;
            this.lblEmpname.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblEmpname.Location = new System.Drawing.Point(261, 247);
            this.lblEmpname.Name = "lblEmpname";
            this.lblEmpname.Size = new System.Drawing.Size(128, 19);
            this.lblEmpname.TabIndex = 82;
            this.lblEmpname.Text = "Employee Name :";
            // 
            // txtEID
            // 
            this.txtEID.Location = new System.Drawing.Point(411, 127);
            this.txtEID.Name = "txtEID";
            this.txtEID.Size = new System.Drawing.Size(200, 26);
            this.txtEID.TabIndex = 81;
            // 
            // tabPgSearchEmp
            // 
            this.tabPgSearchEmp.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPgSearchEmp.BackgroundImage")));
            this.tabPgSearchEmp.Controls.Add(this.lblLogOut4);
            this.tabPgSearchEmp.Controls.Add(this.btnLogOff4);
            this.tabPgSearchEmp.Controls.Add(this.pictureBox3);
            this.tabPgSearchEmp.Controls.Add(this.llbEmpHome4);
            this.tabPgSearchEmp.Controls.Add(this.btnViewEmp);
            this.tabPgSearchEmp.Controls.Add(this.cmbDep);
            this.tabPgSearchEmp.Controls.Add(this.cmbDesig);
            this.tabPgSearchEmp.Controls.Add(this.label6);
            this.tabPgSearchEmp.Controls.Add(this.lblDesig);
            this.tabPgSearchEmp.Controls.Add(this.txtEmpName);
            this.tabPgSearchEmp.Controls.Add(this.lblEmpname);
            this.tabPgSearchEmp.Controls.Add(this.txtEID);
            this.tabPgSearchEmp.Controls.Add(this.lbEId);
            this.tabPgSearchEmp.Location = new System.Drawing.Point(4, 24);
            this.tabPgSearchEmp.Name = "tabPgSearchEmp";
            this.tabPgSearchEmp.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgSearchEmp.Size = new System.Drawing.Size(944, 703);
            this.tabPgSearchEmp.TabIndex = 5;
            this.tabPgSearchEmp.Text = "Search  Employee";
            this.tabPgSearchEmp.UseVisualStyleBackColor = true;
            // 
            // lblLogOut4
            // 
            this.lblLogOut4.AutoSize = true;
            this.lblLogOut4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogOut4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblLogOut4.Location = new System.Drawing.Point(875, 673);
            this.lblLogOut4.Name = "lblLogOut4";
            this.lblLogOut4.Size = new System.Drawing.Size(59, 17);
            this.lblLogOut4.TabIndex = 92;
            this.lblLogOut4.Text = "LogOut";
            // 
            // btnLogOff4
            // 
            this.btnLogOff4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLogOff4.BackgroundImage")));
            this.btnLogOff4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLogOff4.Location = new System.Drawing.Point(835, 667);
            this.btnLogOff4.Name = "btnLogOff4";
            this.btnLogOff4.Size = new System.Drawing.Size(34, 28);
            this.btnLogOff4.TabIndex = 91;
            this.btnLogOff4.UseVisualStyleBackColor = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(838, 20);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(34, 35);
            this.pictureBox3.TabIndex = 90;
            this.pictureBox3.TabStop = false;
            // 
            // llbEmpHome4
            // 
            this.llbEmpHome4.AutoSize = true;
            this.llbEmpHome4.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Bold);
            this.llbEmpHome4.LinkColor = System.Drawing.Color.Cyan;
            this.llbEmpHome4.Location = new System.Drawing.Point(878, 22);
            this.llbEmpHome4.Name = "llbEmpHome4";
            this.llbEmpHome4.Size = new System.Drawing.Size(56, 20);
            this.llbEmpHome4.TabIndex = 89;
            this.llbEmpHome4.TabStop = true;
            this.llbEmpHome4.Text = "Home";
            this.llbEmpHome4.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbEmpHome4_LinkClicked);
            // 
            // lbEId
            // 
            this.lbEId.AutoSize = true;
            this.lbEId.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbEId.Location = new System.Drawing.Point(261, 130);
            this.lbEId.Name = "lbEId";
            this.lbEId.Size = new System.Drawing.Size(106, 19);
            this.lbEId.TabIndex = 80;
            this.lbEId.Text = "Employee ID :";
            // 
            // lblProjId
            // 
            this.lblProjId.AutoSize = true;
            this.lblProjId.Location = new System.Drawing.Point(234, 80);
            this.lblProjId.Name = "lblProjId";
            this.lblProjId.Size = new System.Drawing.Size(87, 19);
            this.lblProjId.TabIndex = 26;
            this.lblProjId.Text = "Project ID :";
            // 
            // btnViewTymSheet
            // 
            this.btnViewTymSheet.Location = new System.Drawing.Point(294, 180);
            this.btnViewTymSheet.Name = "btnViewTymSheet";
            this.btnViewTymSheet.Size = new System.Drawing.Size(163, 38);
            this.btnViewTymSheet.TabIndex = 39;
            this.btnViewTymSheet.Text = "View";
            this.btnViewTymSheet.UseVisualStyleBackColor = true;
            // 
            // txtShiftId
            // 
            this.txtShiftId.Location = new System.Drawing.Point(380, 266);
            this.txtShiftId.Name = "txtShiftId";
            this.txtShiftId.Size = new System.Drawing.Size(200, 26);
            this.txtShiftId.TabIndex = 33;
            // 
            // tabPgTimeSheet
            // 
            this.tabPgTimeSheet.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPgTimeSheet.BackgroundImage")));
            this.tabPgTimeSheet.Controls.Add(this.cmbShftname);
            this.tabPgTimeSheet.Controls.Add(this.textBox1);
            this.tabPgTimeSheet.Controls.Add(this.label2);
            this.tabPgTimeSheet.Controls.Add(this.lblLogOut3);
            this.tabPgTimeSheet.Controls.Add(this.btnLogOff3);
            this.tabPgTimeSheet.Controls.Add(this.pictureBox2);
            this.tabPgTimeSheet.Controls.Add(this.llbEmpHome3);
            this.tabPgTimeSheet.Controls.Add(this.btnViewTymSheet);
            this.tabPgTimeSheet.Controls.Add(this.txtShiftId);
            this.tabPgTimeSheet.Controls.Add(this.lblShiftName);
            this.tabPgTimeSheet.Controls.Add(this.lblShiftId);
            this.tabPgTimeSheet.Location = new System.Drawing.Point(4, 24);
            this.tabPgTimeSheet.Name = "tabPgTimeSheet";
            this.tabPgTimeSheet.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgTimeSheet.Size = new System.Drawing.Size(944, 703);
            this.tabPgTimeSheet.TabIndex = 4;
            this.tabPgTimeSheet.Text = "Time Sheet Management";
            this.tabPgTimeSheet.UseVisualStyleBackColor = true;
            // 
            // lblLogOut3
            // 
            this.lblLogOut3.AutoSize = true;
            this.lblLogOut3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogOut3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblLogOut3.Location = new System.Drawing.Point(875, 674);
            this.lblLogOut3.Name = "lblLogOut3";
            this.lblLogOut3.Size = new System.Drawing.Size(59, 17);
            this.lblLogOut3.TabIndex = 90;
            this.lblLogOut3.Text = "LogOut";
            // 
            // btnLogOff3
            // 
            this.btnLogOff3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLogOff3.BackgroundImage")));
            this.btnLogOff3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLogOff3.Location = new System.Drawing.Point(835, 668);
            this.btnLogOff3.Name = "btnLogOff3";
            this.btnLogOff3.Size = new System.Drawing.Size(34, 28);
            this.btnLogOff3.TabIndex = 89;
            this.btnLogOff3.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(838, 21);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(34, 35);
            this.pictureBox2.TabIndex = 88;
            this.pictureBox2.TabStop = false;
            // 
            // llbEmpHome3
            // 
            this.llbEmpHome3.AutoSize = true;
            this.llbEmpHome3.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Bold);
            this.llbEmpHome3.LinkColor = System.Drawing.Color.Cyan;
            this.llbEmpHome3.Location = new System.Drawing.Point(878, 23);
            this.llbEmpHome3.Name = "llbEmpHome3";
            this.llbEmpHome3.Size = new System.Drawing.Size(56, 20);
            this.llbEmpHome3.TabIndex = 87;
            this.llbEmpHome3.TabStop = true;
            this.llbEmpHome3.Text = "Home";
            this.llbEmpHome3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbEmpHome3_LinkClicked);
            // 
            // lblShiftName
            // 
            this.lblShiftName.AutoSize = true;
            this.lblShiftName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblShiftName.Location = new System.Drawing.Point(213, 308);
            this.lblShiftName.Name = "lblShiftName";
            this.lblShiftName.Size = new System.Drawing.Size(93, 19);
            this.lblShiftName.TabIndex = 30;
            this.lblShiftName.Text = "Shift Name :";
            // 
            // lblShiftId
            // 
            this.lblShiftId.AutoSize = true;
            this.lblShiftId.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblShiftId.Location = new System.Drawing.Point(213, 266);
            this.lblShiftId.Name = "lblShiftId";
            this.lblShiftId.Size = new System.Drawing.Size(71, 19);
            this.lblShiftId.TabIndex = 29;
            this.lblShiftId.Text = "Shift ID :";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPgViewProfile);
            this.tabControl1.Controls.Add(this.tabPgProject);
            this.tabControl1.Controls.Add(this.tabPgTimeSheet);
            this.tabControl1.Controls.Add(this.tabPgSearchEmp);
            this.tabControl1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ItemSize = new System.Drawing.Size(84, 20);
            this.tabControl1.Location = new System.Drawing.Point(3, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(952, 731);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPgProject
            // 
            this.tabPgProject.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPgProject.BackgroundImage")));
            this.tabPgProject.Controls.Add(this.lblLogOut2);
            this.tabPgProject.Controls.Add(this.btnLogOff2);
            this.tabPgProject.Controls.Add(this.pictureBox1);
            this.tabPgProject.Controls.Add(this.llbEmpHome2);
            this.tabPgProject.Controls.Add(this.btnViewProj);
            this.tabPgProject.Controls.Add(this.dgvProject);
            this.tabPgProject.Controls.Add(this.txtEmployId);
            this.tabPgProject.Controls.Add(this.txtProjId);
            this.tabPgProject.Controls.Add(this.lblEmpld);
            this.tabPgProject.Controls.Add(this.lblProjId);
            this.tabPgProject.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.tabPgProject.Location = new System.Drawing.Point(4, 24);
            this.tabPgProject.Name = "tabPgProject";
            this.tabPgProject.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgProject.Size = new System.Drawing.Size(944, 703);
            this.tabPgProject.TabIndex = 2;
            this.tabPgProject.Text = "Project Details";
            this.tabPgProject.UseVisualStyleBackColor = true;
            // 
            // lblLogOut2
            // 
            this.lblLogOut2.AutoSize = true;
            this.lblLogOut2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogOut2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblLogOut2.Location = new System.Drawing.Point(875, 667);
            this.lblLogOut2.Name = "lblLogOut2";
            this.lblLogOut2.Size = new System.Drawing.Size(59, 17);
            this.lblLogOut2.TabIndex = 90;
            this.lblLogOut2.Text = "LogOut";
            // 
            // btnLogOff2
            // 
            this.btnLogOff2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLogOff2.BackgroundImage")));
            this.btnLogOff2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLogOff2.Location = new System.Drawing.Point(835, 661);
            this.btnLogOff2.Name = "btnLogOff2";
            this.btnLogOff2.Size = new System.Drawing.Size(34, 28);
            this.btnLogOff2.TabIndex = 89;
            this.btnLogOff2.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(838, 14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(34, 35);
            this.pictureBox1.TabIndex = 88;
            this.pictureBox1.TabStop = false;
            // 
            // llbEmpHome2
            // 
            this.llbEmpHome2.AutoSize = true;
            this.llbEmpHome2.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Bold);
            this.llbEmpHome2.LinkColor = System.Drawing.Color.Cyan;
            this.llbEmpHome2.Location = new System.Drawing.Point(878, 16);
            this.llbEmpHome2.Name = "llbEmpHome2";
            this.llbEmpHome2.Size = new System.Drawing.Size(56, 20);
            this.llbEmpHome2.TabIndex = 87;
            this.llbEmpHome2.TabStop = true;
            this.llbEmpHome2.Text = "Home";
            this.llbEmpHome2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbEmpHome2_LinkClicked);
            // 
            // btnViewProj
            // 
            this.btnViewProj.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnViewProj.Location = new System.Drawing.Point(285, 571);
            this.btnViewProj.Name = "btnViewProj";
            this.btnViewProj.Size = new System.Drawing.Size(163, 38);
            this.btnViewProj.TabIndex = 32;
            this.btnViewProj.Text = "View Project Details";
            this.btnViewProj.UseVisualStyleBackColor = true;
            // 
            // dgvProject
            // 
            this.dgvProject.BackgroundColor = System.Drawing.Color.SaddleBrown;
            this.dgvProject.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProject.Location = new System.Drawing.Point(91, 174);
            this.dgvProject.Name = "dgvProject";
            this.dgvProject.Size = new System.Drawing.Size(781, 364);
            this.dgvProject.TabIndex = 31;
            // 
            // txtEmployId
            // 
            this.txtEmployId.Location = new System.Drawing.Point(401, 123);
            this.txtEmployId.Name = "txtEmployId";
            this.txtEmployId.Size = new System.Drawing.Size(266, 26);
            this.txtEmployId.TabIndex = 28;
            // 
            // txtProjId
            // 
            this.txtProjId.Location = new System.Drawing.Point(401, 73);
            this.txtProjId.Name = "txtProjId";
            this.txtProjId.Size = new System.Drawing.Size(266, 26);
            this.txtProjId.TabIndex = 27;
            // 
            // lblEmpld
            // 
            this.lblEmpld.AutoSize = true;
            this.lblEmpld.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmpld.Location = new System.Drawing.Point(233, 130);
            this.lblEmpld.Name = "lblEmpld";
            this.lblEmpld.Size = new System.Drawing.Size(106, 19);
            this.lblEmpld.TabIndex = 28;
            this.lblEmpld.Text = "Employee ID :";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(380, 103);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(200, 26);
            this.textBox1.TabIndex = 94;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(213, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 19);
            this.label2.TabIndex = 93;
            this.label2.Text = "Employee ID :";
            // 
            // cmbShftname
            // 
            this.cmbShftname.FormattingEnabled = true;
            this.cmbShftname.Location = new System.Drawing.Point(380, 305);
            this.cmbShftname.Name = "cmbShftname";
            this.cmbShftname.Size = new System.Drawing.Size(200, 27);
            this.cmbShftname.TabIndex = 95;
            // 
            // EmployeeActivityForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(953, 741);
            this.Controls.Add(this.tabControl1);
            this.Name = "EmployeeActivityForm";
            this.Text = "EmployeeActivityForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.EmployeeActivityForm_Load);
            this.tabPgViewProfile.ResumeLayout(false);
            this.tabPgViewProfile.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pichome1)).EndInit();
            this.tabPgSearchEmp.ResumeLayout(false);
            this.tabPgSearchEmp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.tabPgTimeSheet.ResumeLayout(false);
            this.tabPgTimeSheet.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPgProject.ResumeLayout(false);
            this.tabPgProject.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProject)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPgViewProfile;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtemplyid;
        private System.Windows.Forms.TextBox txtFrstnme;
        private System.Windows.Forms.TextBox txtmgr;
        private System.Windows.Forms.TextBox txtphnnumbr;
        private System.Windows.Forms.TextBox txtsal;
        private System.Windows.Forms.TextBox txtaddrss;
        private System.Windows.Forms.TextBox txtLstnme;
        private System.Windows.Forms.Label lblEmplyID;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.ComboBox cmbgrade;
        private System.Windows.Forms.ComboBox cmbdept;
        private System.Windows.Forms.ComboBox cmbdesg;
        private System.Windows.Forms.ComboBox cmbMStuts;
        private System.Windows.Forms.ComboBox cmbgender;
        private System.Windows.Forms.DateTimePicker dtpDOJ;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.Label lblGrdCode;
        private System.Windows.Forms.Label lblMgrId;
        private System.Windows.Forms.Label lblDpt;
        private System.Windows.Forms.Label lblDesg;
        private System.Windows.Forms.Label lblPhnNo;
        private System.Windows.Forms.Label lblSal;
        private System.Windows.Forms.Label lblMStatus;
        private System.Windows.Forms.Label lblAddrs;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.Label lblDOJ;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.Label lblLstName;
        private System.Windows.Forms.Label lblFrstName;
        private System.Windows.Forms.LinkLabel llbhome2;
        private System.Windows.Forms.Button btnViewEmp;
        private System.Windows.Forms.ComboBox cmbDep;
        private System.Windows.Forms.ComboBox cmbDesig;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblDesig;
        private System.Windows.Forms.TextBox txtEmpName;
        private System.Windows.Forms.Label lblEmpname;
        private System.Windows.Forms.TextBox txtEID;
        private System.Windows.Forms.TabPage tabPgSearchEmp;
        private System.Windows.Forms.Label lbEId;
        private System.Windows.Forms.Label lblProjId;
        private System.Windows.Forms.Button btnViewTymSheet;
        private System.Windows.Forms.TextBox txtShiftId;
        private System.Windows.Forms.TabPage tabPgTimeSheet;
        private System.Windows.Forms.Label lblShiftName;
        private System.Windows.Forms.Label lblShiftId;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPgProject;
        private System.Windows.Forms.Button btnViewProj;
        private System.Windows.Forms.DataGridView dgvProject;
        private System.Windows.Forms.TextBox txtEmployId;
        private System.Windows.Forms.TextBox txtProjId;
        private System.Windows.Forms.Label lblEmpld;
        private System.Windows.Forms.Label lblLogOut1;
        private System.Windows.Forms.Button btnlogoff1;
        private System.Windows.Forms.PictureBox pichome1;
        private System.Windows.Forms.LinkLabel llbhome1;
        private System.Windows.Forms.Label lblLogOut4;
        private System.Windows.Forms.Button btnLogOff4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.LinkLabel llbEmpHome4;
        private System.Windows.Forms.Label lblLogOut3;
        private System.Windows.Forms.Button btnLogOff3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.LinkLabel llbEmpHome3;
        private System.Windows.Forms.Label lblLogOut2;
        private System.Windows.Forms.Button btnLogOff2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.LinkLabel llbEmpHome2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbShftname;
    }
}