﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    /// <summary>
    /// Author : 
    /// Modification Date :
    /// Change Description : 
    /// </summary>
    public class EmployeeProject
    {
        #region Properties

            //Get or Set Project ID
            public string ProjectID { get; set; }

            //Get or Set Employee ID
            public int EmployeeID { get; set; }

        #endregion
    }
}
