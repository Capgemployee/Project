﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    /// <summary>
    /// Author : 
    /// Modification Date :
    /// Change Description : 
    /// </summary>
    public class Department
    {
        #region Properties

        //To Get or set DepartmentID
        public int DepartmentID { get; set; }

        //To Get or Set DepartmentName
        public string DepartmentName { get; set; }

        #endregion
    }

}
